# Lab Monitoring Dashboard — steady

Green, normal operation. All three signals stay within bounds, the readouts drift inside narrow bands and no alarms fire.

| | |
| --- | --- |
| Composition id | `LabDashGreen` |
| Resolution | **3840 × 2160** (4K UHD) |
| Duration | **600 frames** |
| Frame rate | **30 fps** (20.0 s) |
| Loops | **Yes** |

Frame 0 and frame 600 are pixel-identical — verified as a byte-identical
PNG at full 4K. Every waveform's scroll covers exactly one signal period, and
every reroll and blink derives from `frame % 600`, so the piece can be looped
without a visible seam.

## Install

```
npm install
```

## Render at 4K

```
npx remotion render LabDashGreen out/labdash-steady.mp4 --codec=h264 --crf=12 --concurrency=8
```

A faster 1080p preview of the same composition:

```
npx remotion render LabDashGreen out/labdash-steady-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

`npx remotion studio` opens the composition for scrubbing.

## How it is put together

- `src/config.ts` is the only file holding a colour or a piece of display copy.
  Palette, waveform character, readout behaviour and event schedule all hang off
  the one exported `CONFIG` object.
- `src/LabDashboard.tsx` composes the frame on one offscreen 3840 × 2160 canvas
  and blits it to the single visible canvas. Each component draws into that
  shared context in JSX order, so the tree reads bottom-of-stack first.
- Static panel chrome — background, fills, borders, corner ticks, grids and
  fixed labels — is rasterised once in a `useMemo` and copied in with a single
  `drawImage` per frame. Only traces, changing values and blinking elements are
  redrawn.
- The three centre signals are generated once, seeded, each as exactly one
  period, and each translates by exactly one of its own periods across the 600
  frames. Panel 2's period is three times panel 1's, which is where the speed
  difference comes from.
- Every value is a pure function of `useCurrentFrame()`. No clock, no
  `requestAnimationFrame`, no CSS animation, and all randomness goes through
  Remotion's `random()` with stable string seeds, so `npx remotion render` is
  deterministic.
- Fonts load through `@remotion/google-fonts`, gated with
  `delayRender()`/`continueRender()`; the readouts draw their digits on a fixed
  advance so they do not jitter as digits change.
