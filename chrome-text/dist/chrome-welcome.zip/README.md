# ChromeWelcome — 4K neon chrome text

A 4K, seamlessly looping "neon chrome text" animation, drawn entirely on a 2D
canvas. No 3D, no Three.js, no WebGL.

| | |
|---|---|
| Composition id | `ChromeWelcome` |
| Word | **WELCOME** |
| Resolution | 3840 x 2160 (4K UHD) |
| Duration | 300 frames |
| Frame rate | 30 fps (10.0 s) |
| Loops | Yes — frame 0 and frame 300 are pixel-identical |
| Palette | blue and magenta |
| Cap height | 16% of frame height |

## Render at 4K

```bash
npm install
npx remotion render ChromeWelcome out/chrome-welcome.mp4 --codec=h264 --crf=12 --concurrency=8
```

Lower `--concurrency` if the machine has fewer cores than that; Remotion
refuses a value above the available core count.

For a quick 1080p check:

```bash
npx remotion render ChromeWelcome out/chrome-welcome-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

## Preview in the studio

```bash
npm run dev
```

## How it is built

Every layer draws to its own `<canvas>` once per React render, and every
quantity is a pure function of `useCurrentFrame()` — no `Date.now()`, no
`requestAnimationFrame`, no CSS animation, no component state. Randomness comes
from Remotion's seeded `random()`. Renders are therefore deterministic and
frames can be produced out of order across worker processes.

- `src/variants.ts` — the only place the word and the palette are defined.
- `src/lib/ChromeText.tsx` — the reflective letterform engine: a five-band
  vertical gradient with one hard horizontal boundary at the optical centre
  (the "horizon" that makes metal read as metal), a travelling highlight
  clipped to the glyphs, and directional rims.
- `src/lib/glowField.ts` — the drifting pools of coloured light, computed at
  1/8 resolution and upscaled.
- `src/lib/passes.ts` — bloom, vignette, seeded film grain, low-res upscale.
- `src/components/` — the glow pool, reflection bed, spark field and finish
  layers.

The loop period is 300 frames: the highlight makes exactly 2 traversals, the
glow breathes exactly 2 times, and every drift path is a closed Lissajous
figure with integer frequencies.

Fonts are vendored into `public/fonts`, so rendering never touches the network.
