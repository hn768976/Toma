# Neon Corridor

A seamlessly looping corridor of concentric neon rectangles receding to a
vanishing point over a wet, reflective floor. Real 3D — `@remotion/three` /
react-three-fiber — with a mirrored-camera floor reflection and a bloom / DOF /
grain post chain.

Two versions, identical geometry:

| Composition id           | Look                                     |
| ------------------------ | ---------------------------------------- |
| `V1-NeonCorridorMagenta` | magenta `#e026c0` → violet `#7a3ce8`     |
| `V2-NeonCorridorCyan`    | cyan `#22d3ee` → teal-blue `#1e6fd9`     |

Both are defined at **3840×2160, 30fps, 300 frames (10s)**.

## Render

Install once:

```bash
npm install
```

### 4K masters

```bash
npx remotion render V1-NeonCorridorMagenta out/V1_NeonCorridorMagenta.mp4 --scale=1 --crf=16
npx remotion render V2-NeonCorridorCyan    out/V2_NeonCorridorCyan.mp4    --scale=1 --crf=16
```

### 1080p previews

```bash
npx remotion render V1-NeonCorridorMagenta out/V1_NeonCorridorMagenta.mp4 --scale=0.5 --crf=16
npx remotion render V2-NeonCorridorCyan    out/V2_NeonCorridorCyan.mp4    --scale=0.5 --crf=16
```

### Stills

```bash
npx remotion still V1-NeonCorridorMagenta out/V1_NeonCorridorMagenta.png --frame=0 --scale=0.5
npx remotion still V2-NeonCorridorCyan    out/V2_NeonCorridorCyan.png    --frame=0 --scale=0.5
```

`npm run render:v1` / `render:v2` (4K) and `preview:v1` / `preview:v2` (1080p)
wrap the same commands.

Codec settings — H.264, `yuv420p`, CRF 16 — are pinned in `remotion.config.ts`,
so they do not need to be passed on the command line. Frames are handed to the
encoder as PNG rather than JPEG: JPEG intermediates are full-range and make
x264 tag the result `yuvj420p`, and JPEG chroma subsampling mangles the dark
smooth gradients before H.264 ever sees them.

### Chromium GL flag

The scene is WebGL, so headless Chromium needs a GL backend:

```
--gl=angle
```

This is already set as the default in `remotion.config.ts`; pass it explicitly
only if you override the config. On a machine with **no GPU**, ANGLE falls back
to SwiftShader on its own — you can also ask for it directly:

```
--gl=swiftshader
```

On the reference machine below the two produced byte-identical output, ANGLE
having fallen back to the same software rasteriser.

## Measured render time

Measured on this project, **1080p (`--scale=0.5`), 300 frames**, 4 vCPU / 15 GB,
**no GPU** (software rasterisation), Chrome Headless Shell 149:

| Composition              | Wall clock | Per frame |
| ------------------------ | ---------- | --------- |
| `V1-NeonCorridorMagenta` | 835 s      | **2.78 s** |
| `V2-NeonCorridorCyan`    | 819 s      | **2.73 s** |

Wall clock is the whole `npx remotion render` invocation at Remotion's default
concurrency, so it includes bundling and browser startup (~15 s); net of that
the steady-state cost is ~2.73 s/frame. The corridor runs 46 rectangles deep to
hide its far end in fog, which is what makes this dearer than a shallower
tunnel would be.

Expect 4K (`--scale=1`) to cost roughly 4× that per frame at the same
concurrency, and far less on a machine with a real GPU — nearly all of the cost
here is fragment work (bloom mip chain, 9-tap reflection blur, 4× MSAA) that a
GPU eats for breakfast.

## Verification

Checked against the encoded 1080p files, not the studio preview:

- **Loop.** The frame 299 → 0 wrap is 1.13× (V1) and 1.11× (V2) the mean
  frame-to-frame difference, against a worst ordinary step of 1.29× and 1.27× —
  so the wrap is an unremarkable step and there is no seam.
- **Travel.** Frames 0, 50, 100 and 150 are identical bar the camera float,
  which is the signature of the camera covering exactly one frame-spacing every
  50 frames — six over the loop, as intended.
- **Format.** 1920×1080, H.264, `yuv420p`, 30 fps, exactly 300 frames.
- **Flicker.** Because the corridor repeats every 50 frames, diffing each frame
  against its periodic twin cancels the travel and leaves the flicker. That
  isolates all three scheduled events — frames 49–55, 132–135 and 238–246
  (scheduled 46, 128, 237) — each a dip of 3–6% in mid-corridor luminance.
- **Banding.** A vertical scan of the dark upper gradient moves in 1–2 level
  increments with no staircase (20 distinct values over 166 pixels spanning 23
  levels, 7 steps of 3 or more).

## How it works

### The loop

`src/loop.ts` is the whole mechanism, and it is worth reading before changing
anything visual.

The camera travels forward a **whole number of frame-spacings**
(`TRAVEL_SPACINGS`, currently 6) over the 300 frames, with tubes recycled from
the back to the front. That is modelled with the camera pinned at the origin
and the corridor sliding past it — equivalent, and it keeps the reflection and
DOF maths in a fixed frame.

Tube `k` sits at slot `m = (k − TRAVEL_SPACINGS · t) mod FRAME_COUNT`, `t`
running 0 → 1 across the loop, and slot `m` sits at `z = Z_SLOT0 − m · SPACING`.
At `t = 1` every tube has advanced a whole number of slots, so the *set* of
occupied positions is identical to `t = 0`. The whole-number part is the
constraint: a fractional travel would leave the tubes between slots at the wrap
and produce a visible jump. Hence the invariant everything else obeys:

> Any visual property that is a pure function of a tube's camera-relative
> position loops perfectly.

So colour, brightness and the bottom-bar fade are keyed off depth or slot,
never off a tube's identity `k`. Keying colour off `k` would break the loop,
because at `t = 1` a *different* tube stands where tube `k` stood at `t = 0`.

**Flicker is the one deliberate exception**, and it has to be. Keyed to a slot
it sits at a fixed distance from the camera, which only passes for
tube-anchored while the corridor is barely moving; at six spacings per loop the
corridor advances a quarter of a spacing during an event and the flicker
visibly slides off its tube onto the next one. So it is keyed to `k` and
travels with the tube. That stays exact because every event opens and closes
strictly inside the loop behind a `sin(π·τ)` envelope — both boundary frames
are unflickered whichever tube stands where, so the wrap is untouched.

The same rule drives the floor: its mottling scrolls with the corridor, and
every noise octave tiles with a period of exactly one frame-spacing in world z,
so the texture lands back on itself at the end of the loop.

Everything is a pure function of `useCurrentFrame()`. There is no `useFrame`
clock and no delta accumulation anywhere, because Remotion renders frames out
of order across threads. The one `useFrame` callback that does exist (the
reflection pass) reads only the camera's current transform, and the grain seed
comes from the frame number.

### The reflection

`src/scene/ReflectiveFloor.tsx`. A real mirrored-camera pass into a half-float
render target, sampled back projectively on the floor plane and blurred there —
cheaper and far more controllable than screen-space reflections at this scale.
Because the target is half-float, reflected neon stays above 1.0 and blooms
too.

The pass runs on `useFrame(…, -1)`. Negative priority runs before every other
subscriber and before the render, and — unlike a positive priority — does not
take over the render loop, so it slots in ahead of the post chain without
disturbing it.

The blur is vertical-biased and world-constant, so it is wide underfoot and
tight down the corridor — that axis dissolves horizontal features while leaving
the vertical streaks that make the floor read as wet. The noise warp matters
more than it looks: reflected top bars arrive as clean horizontal lines, and a
vertical displacement that varies along x is what breaks them into the
interrupted banding a wet slab actually gives.

The blur kernel is also **jittered by up to half a tap per pixel**, and that is
load-bearing. Down the corridor the reflected rectangles stack up only a few
pixels apart — the same order as the tap spacing — so a fixed kernel samples
the same phase of that stack on every scanline and the floor ribs up like
corduroy. Taking more taps does not fix it (a denser 15-tap kernel brings the
ribbing straight back); breaking the phase lock per pixel does, turning the
moiré into fine noise the grain absorbs.

Reflection strength is 0.24, not the ~0.4 the brief suggested. Damp concrete
scatters most of the light, and the slab reads better when its brightness comes
from the diffuse spill than from a legible second copy of the corridor.

### The post chain

`src/scene/Effects.tsx` drives `postprocessing` directly rather than going
through `<EffectComposer>` from `@react-three/postprocessing`. That wrapper
builds its composer inside a passive effect, so on the very first `advance()`
there is no composer yet and nothing reaches the canvas — which, under
Remotion, is exactly the frame each render thread starts on, and the result is
a black frame. Building it in `useMemo` means it exists before any render runs.

Half-float buffers throughout, so neon above 1.0 survives to the bloom and
clips only in the final 8-bit write; that clipping is where the white-hot tube
cores come from. Grain is applied in the display domain, where H.264 banding
actually lives — a flat linear-space dither would swamp the blacks and vanish
in the highlights.

### Departures from the reference

- **No haze at the vanishing point.** The reference ends its corridor in a
  bright blown-out core; this build has none, so the tunnel converges into fog
  instead. That is why `FRAME_COUNT` is 46 and `FOG_DENSITY` is low: with
  nothing bright to hide the end, the rectangles have to dim gradually over a
  long tail, or the corridor terminates in a hard-edged black rectangle.
- **Travel speed.** The reference loops every **30** frames — one frame-spacing
  per second. This build covers six frame-spacings per 300-frame loop, so a
  rectangle passes roughly every 1.7 s.
- The rectangles' bottom bars fade out over the last few metres
  (`baseBarGain` in `src/scene/Corridor.tsx`). Down the corridor they give the
  faint floor ladder the reference has; up close the same bar is seen almost
  edge-on and lays a solid stripe across the lower third, which the reference
  does not have.

## Layout

```
src/
  config.ts                  corridor geometry, timing, camera
  loop.ts                    the loop mechanism and its invariant
  palette.ts                 the two colour ramps
  flicker.ts                 seeded failing-tube events
  Root.tsx                   composition registration
  NeonCorridor.tsx           canvas, camera rig, scene assembly
  scene/
    Corridor.tsx             neon rectangles + wall strips
    geometry.ts              shared merged tube geometry
    Shell.tsx                walls and ceiling, with light spill
    ReflectiveFloor.tsx      mirrored-camera reflection + wet floor shader
    Effects.tsx              bloom / DOF / grain / vignette
    GrainVignetteEffect.ts   custom final-pass effect
```

## Development

```bash
npm run studio   # Remotion Studio
npm run lint     # tsc --noEmit
```
