/**
 * mulberry32 - a small, fast, fully deterministic PRNG.
 *
 * Every random value in this project comes from here, seeded at module level
 * and drawn once at build time. There is no `Math.random()` at render time, so
 * a frame rendered on its own is identical to the same frame from a full
 * sequential render.
 */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
