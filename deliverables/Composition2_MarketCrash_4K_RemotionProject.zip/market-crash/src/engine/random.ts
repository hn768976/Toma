// Deterministic PRNG so every render (and every render worker) builds the
// exact same scene. Never use Math.random() in a Remotion composition.
export const mulberry32 = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

export type Rng = ReturnType<typeof mulberry32>;

export const range = (rng: Rng, min: number, max: number) =>
  min + (max - min) * rng();

export const pick = <T,>(rng: Rng, items: readonly T[]): T =>
  items[Math.floor(rng() * items.length) % items.length];

/** Approximately normal-distributed value (sum of uniforms). */
export const gauss = (rng: Rng) => (rng() + rng() + rng() + rng() - 2) / 0.58;
