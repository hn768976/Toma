/**
 * Camera paths for the golden-bokeh plate. All positions are in frame
 * heights on the virtual plate; time is in seconds.
 */

export type CameraState = {
  x: number;
  y: number;
  zoom: number;
  roll: number;
  parallax: number;
};

// Tilt of the reference, in plate travel (frame heights) every 2 s. Measured
// by tracking the gold/sky boundary in the reference footage: eases in,
// keeps a steady pace through the middle (no surges), then settles on
// open sky.
const TILT_KEYS: ReadonlyArray<readonly [number, number]> = [
  [0, 0],
  [2, 0.05],
  [4, 0.12],
  [6, 0.215],
  [8, 0.315],
  [10, 0.41],
  [12, 0.505],
  [14, 0.6],
  [16, 0.695],
  [18, 0.795],
  [20, 0.895],
  [22, 0.99],
  [24, 1.08],
  [26, 1.15],
  [28, 1.18],
];

// Monotone cubic (Fritsch-Carlson) interpolation: smooth, no overshoot.
const tangents = (() => {
  const n = TILT_KEYS.length;
  const d = TILT_KEYS.slice(0, -1).map(
    ([t0, v0], i) => (TILT_KEYS[i + 1][1] - v0) / (TILT_KEYS[i + 1][0] - t0),
  );
  const m = TILT_KEYS.map((_, i) =>
    i === 0 ? d[0] : i === n - 1 ? d[n - 2] : d[i - 1] * d[i] <= 0 ? 0 : (d[i - 1] + d[i]) / 2,
  );
  for (let i = 0; i < n - 1; i++) {
    if (d[i] === 0) {
      m[i] = 0;
      m[i + 1] = 0;
      continue;
    }
    const a = m[i] / d[i];
    const b = m[i + 1] / d[i];
    const h = a * a + b * b;
    if (h > 9) {
      const k = 3 / Math.sqrt(h);
      m[i] = k * a * d[i];
      m[i + 1] = k * b * d[i];
    }
  }
  return m;
})();

const tiltAt = (t: number) => {
  const last = TILT_KEYS.length - 1;
  if (t <= TILT_KEYS[0][0]) return TILT_KEYS[0][1];
  if (t >= TILT_KEYS[last][0]) return TILT_KEYS[last][1];
  let i = 0;
  while (t > TILT_KEYS[i + 1][0]) i++;
  const [t0, v0] = TILT_KEYS[i];
  const [t1, v1] = TILT_KEYS[i + 1];
  const h = t1 - t0;
  const s = (t - t0) / h;
  const s2 = s * s;
  const s3 = s2 * s;
  return (
    (2 * s3 - 3 * s2 + 1) * v0 +
    (s3 - 2 * s2 + s) * h * tangents[i] +
    (-2 * s3 + 3 * s2) * v1 +
    (s3 - s2) * h * tangents[i + 1]
  );
};

/** Plate height where the tilt comes to rest (the sky is laid out from it). */
export const TILT_END = TILT_KEYS[TILT_KEYS.length - 1][1];

/** Version 1: vertical tilt-up, as in the reference (no parallax: rotation). */
export const tiltUp = (t: number): CameraState => {
  const y = tiltAt(t);
  return {
    x: -0.05 * (y / TILT_END),
    y,
    zoom: 1,
    roll: 0,
    parallax: 0,
  };
};

const smootherstep = (x: number) => {
  const c = Math.min(Math.max(x, 0), 1);
  return c * c * c * (c * (c * 6 - 15) + 10);
};

const easeOutQuad = (x: number) => {
  const c = Math.min(Math.max(x, 0), 1);
  return 1 - (1 - c) ** 2;
};

/**
 * Version 2: a crane pull-back. It opens tight (1.4x) inside the warm bokeh
 * on a strong dutch angle, rises fast early and then glides (a different
 * vertical profile from V1's eased tilt), while pulling back to a wide
 * frame and rolling level. The camera translates, so the bokeh depth layers
 * parallax past each other. It settles on a framing close to V1's sky.
 */
export const craneRise = (t: number): CameraState => {
  const rise = easeOutQuad(t / 26);
  const settle = smootherstep(t / 22);
  return {
    x: -0.22 + 0.3 * smootherstep(t / 24),
    y: -0.25 + (TILT_END + 0.25) * rise,
    zoom: 1.4 - 0.4 * settle,
    roll: -0.14 * (1 - smootherstep(t / 16)) + 0.01 * Math.sin(t * 0.35),
    parallax: 0.9,
  };
};
