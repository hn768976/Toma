Put the reference clips here as refs/<referenceID>.mp4 (not included).
