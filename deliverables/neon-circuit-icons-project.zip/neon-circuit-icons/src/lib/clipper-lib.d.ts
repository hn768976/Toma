declare module 'clipper-lib';
