import { continueRender, delayRender, staticFile } from "remotion";

// Self-hosted so rendering never depends on a network fetch at render
// time. Registers a delayRender() so Remotion waits for the font before
// it captures any frame.
export const MONO_FONT_FAMILY = "JetBrains Mono";

const monoHandle = delayRender("Loading JetBrains Mono font");

new FontFace(
  MONO_FONT_FAMILY,
  `url(${staticFile("fonts/JetBrainsMono-Regular.woff2")}) format("woff2")`,
  { weight: "400", style: "normal" },
)
  .load()
  .then((loaded) => {
    document.fonts.add(loaded);
    continueRender(monoHandle);
  })
  .catch((err) => {
    console.error("Failed to load JetBrains Mono font", err);
    continueRender(monoHandle);
  });
