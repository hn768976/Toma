import "./index.css";
import "./load-fonts";
import { Composition } from "remotion";
import { DataSphereHud, dataSphereHudSchema } from "./data-sphere/DataSphereHud";
import { DESIGN_HEIGHT, DESIGN_WIDTH, DURATION_IN_FRAMES, FPS } from "./data-sphere/constants";

// Two palettes x two resolutions. The 4K compositions are the masters;
// the 1080p ones render the identical frame at half size.
const variants = [
  { id: "DataSphereHUD-Mono", palette: "mono" },
  { id: "DataSphereHUD-Ember", palette: "ember" },
] as const;

export const RemotionRoot: React.FC = () => {
  return (
    <>
      {variants.flatMap((v) => [
        <Composition
          key={`${v.id}-4K`}
          id={`${v.id}-4K`}
          component={DataSphereHud}
          durationInFrames={DURATION_IN_FRAMES}
          fps={FPS}
          width={DESIGN_WIDTH * 2}
          height={DESIGN_HEIGHT * 2}
          schema={dataSphereHudSchema}
          defaultProps={{ palette: v.palette }}
        />,
        <Composition
          key={`${v.id}-1080p`}
          id={`${v.id}-1080p`}
          component={DataSphereHud}
          durationInFrames={DURATION_IN_FRAMES}
          fps={FPS}
          width={DESIGN_WIDTH}
          height={DESIGN_HEIGHT}
          schema={dataSphereHudSchema}
          defaultProps={{ palette: v.palette }}
        />,
      ])}
    </>
  );
};
