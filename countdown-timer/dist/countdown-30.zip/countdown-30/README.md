# Neon Countdown Timer — 30 seconds

A 4K neon radial-bar countdown timer. A ring of 76 thin, glowing bars
radiates from a faint circular track, their lengths flowing around the
ring like an audio visualiser while a cyan -> blue -> violet -> magenta
gradient drifts with the ring's single slow rotation. In the centre, the
time remaining in MM:SS as seven-segment numerals with the unlit
segments faintly visible.

## This composition

| | |
| --- | --- |
| Composition id | `Countdown30` |
| Resolution | **4K — 3840 x 2160** |
| Timer duration | **30 seconds** (starts at 00:30, ends at 00:00) |
| Composition length | **930 frames** (30 s of timer + 30-frame hold on 00:00) |
| Frame rate | **30 fps** |
| Loops? | **No** — the timer runs down and stops. Do not loop it. |
| Audio | None |

## Render at full 4K

```
npx remotion render Countdown30 out/countdown-30.mp4 --codec=h264 --crf=14 --concurrency=8
```

Lower `--concurrency` if you have fewer than 8 CPU cores; Remotion
rejects a value above your core count.

A faster 1080p check render:

```
npx remotion render Countdown30 out/countdown-30-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

## Getting started

```
npm install
npm run dev      # opens Remotion Studio
```

`npm run lint` typechecks the project.

## What is in here

```
src/
  index.ts                     registerRoot entry point
  Root.tsx                     the three <Composition> registrations
  countdown/
    CountdownTimer.tsx         the composition itself
    RadialBarRing.tsx          the ring of bars
    RingTrack.tsx              the faint circle the bars stand on
    SevenSegmentDigits.tsx     the MM:SS readout, drawn from segments
    UnitLabels.tsx             the MINS / SECS captions
    variants.ts                the ONLY per-version values
    theme.ts                   palette and construction values (shared)
    count.ts                   frame -> time remaining
    noise.ts                   the smooth field driving bar lengths
    cyclicGradient.ts          a gradient that closes back on itself
    color.ts                   the sweep, built from the palette
    segments.ts                seven-segment geometry
    effects.ts                 bloom and film grain
    stage.ts                   the shared canvas the components paint on
    fonts.ts                   Inter, for the two captions only
```

All three timer lengths ship in this project. `Root.tsx` registers
`Countdown60`, `Countdown30` and `Countdown90`; render whichever id you
need. They differ **only** in duration — palette, bar count, digit
construction, glow and drift are identical by design.

## Notes

- Every value on screen is a pure function of the frame number: the
  count, the bar lengths, the rotation, the ambient drift and the grain.
  Nothing reads a clock, so the rendered file cannot drift out of step
  with its own timer.
- The digits are drawn as segment geometry, not set in a font. The only
  real type is the MINS / SECS pair, in Inter via
  `@remotion/google-fonts` — which fetches over HTTPS on first render.
- The ring completes exactly one rotation over the composition's length,
  so this 30-second version turns at its own rate. That is
  intentional: the rotation is tied to the timer, not to real time.
- `remotion.config.ts` contains a block that reuses a Playwright
  Chromium if one is present on the machine. On a normal machine those
  paths do not exist and Remotion uses its own managed browser; you can
  delete the block if you prefer.
