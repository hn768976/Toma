import { Composition } from "remotion";
import { GeoHud } from "./geo-hud/GeoHud";
import {
  DURATION_IN_FRAMES,
  FPS,
  HEIGHT,
  WIDTH,
} from "./geo-hud/constants";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="GeoHudGreen"
      component={GeoHud}
      durationInFrames={DURATION_IN_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={{ variant: "green" as const }}
    />
  );
};
