/**
 * Note: when using the Node.JS APIs, this config file does not apply. Pass the
 * options directly to the APIs instead.
 *
 * All configuration options: https://remotion.dev/docs/config
 */
import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
// This composition carries no audio; without this Remotion muxes a silent AAC
// track that also stretches the file past an exact 30.000s.
Config.setEnforceAudioTrack(false);
