# geo-hud-green — Green "network" offset dashboard

The same dashboard system in a different arrangement and domain: the map sits in the left 45% of the frame with a connector mesh between the highlighted nodes, the right side is a dense three-column stack of small panels, and one full-width line trace runs along the bottom.

## The composition

| | |
| --- | --- |
| Composition id | `GeoHudGreen` |
| Resolution | **3840 × 2160 (4K UHD)** |
| Duration | 900 frames |
| Frame rate | 30 fps (30.0 seconds) |
| Loops | **Yes** — frame 900 is pixel-identical to frame 0, so the clip can be looped without a cut |
| Audio | None |

Every value on screen is a pure function of `useCurrentFrame()`, and all
randomness comes from Remotion's `random()` with stable string seeds — no
`Math.random()`, no `Date.now()`, no `requestAnimationFrame`, no component
state. Renders are therefore deterministic and safe at any `--concurrency`.

## Map data

The world map is **Natural Earth 110m country polygons**, shipped in
`public/geo/countries-110m.json` (the `world-atlas` build of the Natural Earth
data), projected at load time with `d3-geo`.

**Natural Earth is in the public domain.** From the Natural Earth terms of use:
"All versions of Natural Earth raster + vector map data found on this website
are in the public domain. You may use the maps in any manner, including
modifying the content and design, electronic dissemination, and offset
printing." No permission is needed and no attribution is required.

`public/geo/WORLD-ATLAS-LICENSE.txt` carries the ISC licence of the world-atlas
packaging of that data.

All other text in the piece — log lines, labels, station codes, coordinates — is
invented. Nothing reproduces real source code, real telemetry, or coordinates
tied to a real facility. There are no logos and no watermark.

## Install and run

```bash
npm install
npm run dev        # opens Remotion Studio
```

### Render the full 4K composition

```bash
npx remotion render GeoHudGreen out/geohud-green.mp4 --codec=h264 --crf=12 --concurrency=8
```

### Render a 1080p preview

```bash
npx remotion render GeoHudGreen out/geohud-green-preview.mp4 --codec=h264 --crf=18 --scale=0.5 --concurrency=8
```

`--scale` only changes the size of the captured frame; the dashboard is always
drawn into a 3840 × 2160 backing store, so a preview is a downsampled 4K frame
rather than a smaller drawing.

> `--concurrency` must not exceed your CPU core count, and each worker holds a
> full 4K canvas. Lower it if a render runs out of
> memory or times out.

## Dependencies

Beyond `remotion`, `react` and `react-dom`:

- `d3-geo` — projects the country polygons (once, at load).
- `topojson-client` — decodes the TopoJSON into GeoJSON features.
- `@remotion/google-fonts` — loads Barlow Condensed (condensed technical sans)
  and Roboto Mono (monospaced, so the numeric readouts do not jitter as values
  reroll), gated with `delayRender()` / `continueRender()`.

## Layout of the source

```
src/
  index.ts                    registerRoot
  Root.tsx                    the single <Composition />
  geo-hud/
    variants.ts               THE palette / layout / domain / render-mode table
    constants.ts              3840 x 2160, 30fps, 900 frames
    layout.ts                 panel rectangles for both arrangements
    dashboard.ts              the self-contained renderer (draws a whole frame
                              into any 2D context)
    paint.ts                  canvas helpers and the bloom painter
    finish.ts                 bloom, vignette, scanlines, grain
    rand.ts                   seeded, loop-safe cycles
    vocab.ts                  the invented label / log vocabulary
    fonts.ts                  gated web font loading
    map/geo.ts                Natural Earth loading and one-time projection
    map/markers.ts            fixed marker positions
    panels/*.ts               PanelChrome, WorldMapPanel, ReadoutBlock,
                              BarChart, LineTrace, RingGauge, TargetRing,
                              TextPanel, ProgressStrip, ToggleRow, TitlePlate
    GeoHud.tsx                the composition component
```

A few shared modules (`layout.ts`, `vocab.ts`) still carry the definitions for
both arrangements and both readout domains, because they are one module in the
system rather than per-variant copies; only the one this project registers is
ever reached.

`variants.ts` is the only place a colour is defined. Panel chrome, the projected
map and all static text are drawn **once** into an offscreen layer and blitted
each frame; only values, traces, gauges, highlights and the finishing pass are
redrawn.
