import { Composition } from "remotion";
import { GeoHudTilted } from "./geo-hud/GeoHudTilted";
import {
  DURATION_IN_FRAMES,
  FPS,
  HEIGHT,
  WIDTH,
} from "./geo-hud/constants";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="GeoHudTilted"
      component={GeoHudTilted}
      durationInFrames={DURATION_IN_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={{ variant: "tilted" as const }}
    />
  );
};
