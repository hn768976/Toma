/**
 * Every colour and every per-version parameter of the piece lives here.
 * No hex literal appears anywhere else in the wave-field source.
 */

export const VARIANT_NAMES = ["blue"] as const;

export type VariantName = (typeof VARIANT_NAMES)[number];

export type MeshMode = "sparse" | "dense" | "none";

export interface ParticleTone {
  /** Hex colour, taken from the variant palette. */
  color: string;
  /** Relative share of the particle field. Weights need not sum to 1. */
  weight: number;
}

export interface Palette {
  backgroundDeep: string;
  backgroundWash: string;
  meshLine: string;
  /** The leading-edge dots. */
  edgeAccent: string;
  /** The hot cores of the leading-edge dots, and their outer glow. */
  edgeCore: string;
  /** Tint of the faint surface strands that make a band read as a surface. */
  strand: string;
  /** Mixed particle hues: accent dominant, cooler and warmer variants through it. */
  particleTones: ParticleTone[];
}

export interface Harmonic {
  /**
   * Whole number of crests across BAND_LENGTH. Integer so the surface is
   * periodic along the band and drifting particles wrap seamlessly.
   */
  spatial: number;
  /**
   * Whole number of cycles the wave travels in 450 frames. Integer so the
   * phase returns exactly to its start at frame 450.
   */
  temporal: number;
  /** Amplitude at the band's lower fringe, in 4K pixels. */
  amp: number;
  /** Fixed phase offset, in turns. */
  phase: number;
}

export interface VariantConfig {
  palette: Palette;
  /** How strongly the background wash lifts off the deep tone, 0 to 1. */
  washStrength: number;

  /** Number of parallel bands stacked across the frame. */
  bandCount: number;
  /** Perpendicular distance between one band's leading edge and the next. */
  bandPitch: number;
  /** How far a band's surface hangs below its leading edge. */
  bandThickness: number;
  /** Iso-depth strands drawn per band to render the surface. */
  strandRows: number;
  strandAlpha: number;

  /** Total particles across all bands. */
  particleCount: number;
  particleLength: [number, number];
  particleWidth: [number, number];
  particleAlpha: [number, number];

  /** Leading-edge dots: uniform size and uniform spacing within a band. */
  dotSpacing: number;
  dotRadius: number;
  /** Crests of the travelling brightness pulse present along a band at once. */
  pulseCrests: number;
  /** Whole cycles the pulse travels in 450 frames, so its period divides 450. */
  pulseTravel: number;
  /** Higher values make the pulse a tighter, more pronounced bright wave. */
  pulseSharpness: number;

  meshMode: MeshMode;
  meshCount: number;
  meshAlpha: number;

  harmonics: Harmonic[];
  /** Per-band extra whole cycles per 450 frames, so bands never move in lockstep. */
  bandRateOffsets: number[];
  /** Nearest and farthest band scale, driving particle size and dot size. */
  depthScale: [number, number];
}

// --- the "blue" palette: warm particles, cool ground ---

const BLUE_BACKGROUND_DEEP = "#060E33";
const BLUE_BACKGROUND_WASH = "#10205C";
const BLUE_MESH_LINE = "#1A2E6B";
const BLUE_EDGE_CYAN = "#4FD4F5";
const BLUE_EDGE_WHITE = "#E8FAFF";
const BLUE_PARTICLE_AMBER = "#F5A03F";
const BLUE_PARTICLE_ORANGE = "#E8763F";
const BLUE_PARTICLE_VIOLET = "#7B5FE8";
const BLUE_PARTICLE_PALE = "#F5D8A8";

export const VARIANTS: Record<VariantName, VariantConfig> = {
  blue: {
    palette: {
      backgroundDeep: BLUE_BACKGROUND_DEEP,
      backgroundWash: BLUE_BACKGROUND_WASH,
      meshLine: BLUE_MESH_LINE,
      edgeAccent: BLUE_EDGE_CYAN,
      edgeCore: BLUE_EDGE_WHITE,
      strand: BLUE_EDGE_CYAN,
      particleTones: [
        { color: BLUE_PARTICLE_AMBER, weight: 0.46 },
        { color: BLUE_PARTICLE_ORANGE, weight: 0.22 },
        { color: BLUE_PARTICLE_VIOLET, weight: 0.16 },
        { color: BLUE_PARTICLE_PALE, weight: 0.16 },
      ],
    },
    washStrength: 1,
    bandCount: 4,
    bandPitch: 565,
    bandThickness: 285,
    strandRows: 34,
    strandAlpha: 0.34,
    particleCount: 9000,
    particleLength: [26, 78],
    particleWidth: [3.6, 6.5],
    particleAlpha: [0.18, 0.95],
    dotSpacing: 66,
    dotRadius: 16,
    pulseCrests: 2,
    pulseTravel: 3,
    pulseSharpness: 6,
    meshMode: "sparse",
    meshCount: 14,
    meshAlpha: 0.5,
    harmonics: [
      { spatial: 6, temporal: 3, amp: 88, phase: 0 },
      { spatial: 11, temporal: -2, amp: 32, phase: 0.31 },
      { spatial: 17, temporal: 4, amp: 14, phase: 0.67 },
    ],
    bandRateOffsets: [0, 1, -1, 2],
    depthScale: [0.62, 1.18],
  },
};
