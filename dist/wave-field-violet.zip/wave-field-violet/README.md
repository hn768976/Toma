# wave-field-violet

Cool mint particles over a warm violet ground, with magenta leading edges.

Seven narrower bands at tighter spacing, so the frame reads busier
and more layered. Shorter wavelength and higher frequency give a
much finer texture than a broad swell. ~15000 particles at smaller
scale and lower opacity, and a dense mesh of 28 curves.

## The composition

| | |
| --- | --- |
| Composition id | `WaveFieldViolet` |
| Resolution | 3840 x 2160 (4K UHD) |
| Duration | 450 frames |
| Frame rate | 30 fps |
| Length | 15.0 seconds |
| Loops | Yes, seamlessly |
| Audio | None |

The loop is exact, not a crossfade. Frame 450 is pixel-identical to frame 0:
every spatial harmonic is a whole number of crests along a band, every temporal
frequency is a whole number of cycles per 450 frames, every particle completes a
whole number of traversals of its band, and every pulse and flash period divides
450. Verified by rendering both frames at full 4K and comparing the files.

## Running it

```sh
npm install
```

Render at full 4K:

```sh
npx remotion render WaveFieldViolet out/wavefield-violet.mp4 --codec=h264 --crf=12 --concurrency=8
```

Lower `--concurrency` if the machine has fewer cores than that; Remotion
rejects a value above the core count.

A faster 1080p preview of the same 4K composition:

```sh
npx remotion render WaveFieldViolet out/wavefield-violet-preview.mp4 --codec=h264 --crf=18 --scale=0.5 --concurrency=8
```

Open the studio to scrub the timeline:

```sh
npm run dev
```

## How it is built

2D canvas only. No 3D and no Three.js.

Every visible quantity is a pure function of `useCurrentFrame()`. There is no
`Date.now()`, no `requestAnimationFrame`, no CSS animation and no component
state, so a render is deterministic and repeatable. All randomness comes from
Remotion's `random()` with stable string seeds.

- `src/wave-field/variants.ts` holds the one exported `VARIANTS` object: the
  palette, band count, particle density, mesh mode and wave parameters. Every
  hex literal in the project lives there and nowhere else.
- The layers are separate components: `BackgroundWash`, `MeshLayer`,
  `WaveBand`, `ParticleLayer` and `LeadingEdge`. Each draws into an offscreen
  buffer that `WaveField` clears first, so a repeated render redraws
  identically; `WaveField` composites the buffers onto the visible canvas in a
  layout effect once every layer has drawn.
- Depth is three offscreen buffers (far, mid, near) bucketed by band and
  blurred once each, up to 22px on the nearest band. Blurring per particle
  would be unusably slow at 4K. Large radii are applied at reduced resolution,
  which is visually equivalent once the image is that soft.
- The particle set is generated once with `useMemo` and pre-sorted by stroke
  style, so a frame is a few hundred batched canvas paths rather than thousands
  of individual strokes. Per frame only each particle's wave offset and drift
  are recomputed; regenerating the field would make it boil.

## Layout

```
src/
  index.ts               registerRoot
  Root.tsx               the composition
  wave-field/
    variants.ts          VARIANTS: the palette and every tunable parameter
    constants.ts         fixed geometry, depth and finishing constants
    field.ts             seeded generation of bands, particles, dots, mesh
    buffers.ts           offscreen buffers, depth blur and bloom compositing
    color.ts             palette hex to rgba
    finish.ts            vignette and grain
    WaveField.tsx        orchestration and compositing
    BackgroundWash.tsx   the ground
    MeshLayer.tsx        the deeper wireframe surface
    WaveBand.tsx         one band's wave surface
    ParticleLayer.tsx    the surface fill
    LeadingEdge.tsx      the bright sampling dots along each band's crest
```
