/**
 * The ONLY place in the project that holds palettes, silhouette path data,
 * density-map rules, subject animation modes and panel labels.
 *
 * Swapping the scanned subject is a data change: nothing downstream knows what
 * a car, a jet or a brain is.
 */

export type VariantKey = 'car';

export type Palette = {
  bg: string;
  line: string;
  fill: string;
  text: string;
  particle: string;
  particleHot: string;
  sweep: string;
  accent: string;
};

/** scale/translate applied to a path so one path string can serve twice. */
export type Xform = [sx: number, sy: number, tx: number, ty: number];

export type PathRef = {d: string; t?: Xform};

export type Cluster = {
  x: number;
  y: number;
  r: number;
  boost: number;
  /** particles in this cluster respond to the motion's clusterPulse */
  pulse?: boolean;
};

export type Silhouette = {
  /** path-space viewBox that the silhouette is rasterised in */
  vb: [number, number];
  /** the region of path space that is fitted to the stage; defaults to vb */
  fit?: [x: number, y: number, w: number, h: number];
  /** filled to build the mask - the union of these is the silhouette */
  fills: PathRef[];
  /** stroked to build the distance field: outer edges + interior creases */
  lines: PathRef[];
  /** stroke width, in path units, used when building the distance field */
  creaseW: number;
  clusters: Cluster[];
  /** brightness gradient direction across the subject */
  light: [number, number];
  /** direction the scan sweep travels */
  axis: [number, number];
  /** subset of `lines` that pulses travel along in "propagate" mode */
  sulci?: PathRef[];
};

export type DensityRule = {
  target: number;
  /** exponential falloff (raster px) from the nearest edge or crease */
  falloff: number;
  /** baseline acceptance across flat interior areas */
  flat: number;
  /** grid the particles snap to, in 4K px */
  grid: number;
  sizeMin: number;
  sizeMax: number;
  gradLo: number;
  gradHi: number;
};

export type Motion =
  | {
      mode: 'sweep';
      /** frames per pass; must divide 600 */
      period: number;
      /** band half-width as a fraction of the subject's span */
      band: number;
      /** trail length as a fraction of the subject's span */
      trail: number;
      gain: number;
      /** optional independent pulse on the bright clusters */
      clusterPulse?: {period: number; amount: number};
    }
  | {
      mode: 'propagate';
      pulses: number;
      lifeMin: number;
      lifeMax: number;
      /** frames a particle takes to decay after a pulse passes */
      decay: number;
      /** how far a pulse spreads along the graph, in path units */
      spread: number;
      gain: number;
    };

export type ValueSpec = {
  label: string;
  unit: string;
  lo: number;
  hi: number;
  dp: number;
};

export type Readouts = {
  top: ValueSpec[];
  wave: {label: string; sub: string; energy: number};
  table: {label: string; tags: string[]};
  numA: ValueSpec;
  numB: ValueSpec;
  grid: {label: string; tags: string[]};
  meters: {label: string; tags: string[]};
  radar: {label: string; sub: string; turns: number}[];
  scroll: {label: string; tokens: string[]};
  strips: ValueSpec[];
  hist: {label: string};
  numerals: {label: string};
  status: {label: string; states: string[]};
};

export type Variant = {
  palette: Palette;
  silhouette: Silhouette;
  density: DensityRule;
  motion: Motion;
  readouts: Readouts;
};

/* ══════════════════════════════════════════════════════════════════════
   #region variant:car
   ══════════════════════════════════════════════════════════════════════ */

/**
 * Generic crossover, three-quarter front view, nose to the left.
 *
 * Built the way an illustrator would: a near-side profile (with the wheel
 * arches cut out of it), plus three narrow "far side" slivers - the front
 * fascia, the bonnet top and the roof top - each pushed up and to the left.
 * Filling all of them unions into a three-quarter silhouette, and the near
 * profile survives inside it as a crease, which is what sells the perspective.
 * No badge, no grille detail, no brand cues.
 */
/**
 * Sleek modern sedan/fastback in side profile, nose to the left: a low nose
 * with a slim headlight brow, a long bonnet rising into a fast-raked
 * windshield, a short roof sweeping down in one fastback line to a ducktail
 * kick, and a rising beltline. Generic - no badge, no grille, no brand cues.
 */
const CAR_PROFILE =
  'M 190 520 L 150 500 L 138 462 L 142 430 Q 146 416 168 408 ' +
  'C 260 392 360 382 470 372 L 500 368 L 640 268 ' +
  'Q 660 252 700 250 L 810 252 ' +
  'C 890 260 960 286 1020 322 L 1052 340 Q 1070 350 1072 372 ' +
  'L 1078 400 Q 1080 420 1074 444 L 1052 500 ' +
  'L 1000 516 C 1000 436 976 394 916 394 C 856 394 832 436 832 516 ' +
  'L 460 522 C 460 440 434 396 372 396 C 310 396 286 440 286 522 Z';

const CAR_FASCIA =
  'M 168 408 L 142 430 L 138 462 L 150 500 L 190 520 ' +
  'L 160 502 L 128 470 L 122 436 L 142 390 Z';

const CAR_BONNET_TOP =
  'M 168 408 L 142 390 C 250 374 360 362 474 352 L 500 368 ' +
  'C 380 378 260 392 168 408 Z';

const CAR_ROOF_TOP =
  'M 500 368 L 474 352 L 614 252 Q 634 236 674 234 L 790 236 ' +
  'L 810 252 L 700 250 Q 660 252 640 268 Z';

const CAR_REAR_TOP =
  'M 810 252 L 790 236 C 872 244 944 270 1004 306 L 1020 322 ' +
  'C 960 286 890 260 810 252 Z';

const CAR_WHEEL_F =
  'M 372 500 m -82 0 a 82 82 0 1 0 164 0 a 82 82 0 1 0 -164 0';
const CAR_WHEEL_R =
  'M 916 496 m -80 0 a 80 80 0 1 0 160 0 a 80 80 0 1 0 -160 0';

const CAR: Variant = {
  palette: {
    bg: '#01100E',
    line: '#1A5C52',
    fill: '#04211D',
    text: '#7FD4C4',
    particle: '#4FF5E0',
    particleHot: '#E8FFFA',
    sweep: '#A8FFF0',
    accent: '#2E9F8F',
  },
  silhouette: {
    vb: [1200, 660],
    fit: [116, 228, 968, 356],
    fills: [
      {d: CAR_PROFILE},
      {d: CAR_FASCIA},
      {d: CAR_BONNET_TOP},
      {d: CAR_ROOF_TOP},
      {d: CAR_REAR_TOP},
      // the arch cutouts are wider than the wheels, so a crescent of empty
      // space is left inside each arch and the wheels read as wheels
      {d: CAR_WHEEL_F},
      {d: CAR_WHEEL_R},
    ],
    lines: [
      // outer silhouette, which doubles as the near-side body edge
      {d: CAR_PROFILE},
      {d: CAR_FASCIA},
      {d: CAR_BONNET_TOP},
      {d: CAR_ROOF_TOP},
      {d: CAR_REAR_TOP},
      // beltline, rising toward the tail
      {d: 'M 500 368 C 640 358 780 350 890 346 C 950 344 1000 340 1042 340'},
      // window frames: B-pillar, raked rear-quarter pillar
      {d: 'M 736 356 L 726 250'},
      {d: 'M 890 346 L 866 254'},
      // door shut lines
      {d: 'M 545 370 L 552 516'},
      {d: 'M 752 356 L 758 514'},
      // bonnet shut line + bonnet centre crease
      {d: 'M 150 442 C 172 424 198 412 230 404'},
      {d: 'M 192 400 C 292 388 400 378 490 370'},
      // roof centre crease
      {d: 'M 686 242 L 796 244'},
      // strong mid-body character line, nose to tail lamp
      {d: 'M 250 428 C 520 416 800 408 1050 396'},
      // wheel arches
      {d: 'M 286 522 C 286 440 310 396 372 396 C 434 396 460 440 460 522'},
      {d: 'M 832 516 C 832 436 856 394 916 394 C 976 394 1000 436 1000 516'},
      // rocker + lower door crease
      {d: 'M 296 508 L 646 516 L 996 508'},
      {d: 'M 310 476 C 550 484 790 482 1020 468'},
      // headlight wrap
      {d: 'M 144 434 C 168 420 196 412 230 406'},
      {d: 'M 124 444 C 128 424 134 406 142 390'},
      // tail lamp, decklid shut and rear bumper shut
      {d: 'M 1020 322 C 1042 336 1058 352 1066 370'},
      {d: 'M 1052 340 C 1064 356 1070 372 1072 390'},
      {d: 'M 1036 470 C 1058 462 1070 452 1075 440'},
      // tyre walls and hubs, so the wheels are not flat discs
      {d: 'M 372 500 m -56 0 a 56 56 0 1 0 112 0 a 56 56 0 1 0 -112 0'},
      {d: 'M 372 500 m -27 0 a 27 27 0 1 0 54 0 a 27 27 0 1 0 -54 0'},
      {d: 'M 916 496 m -55 0 a 55 55 0 1 0 110 0 a 55 55 0 1 0 -110 0'},
      {d: 'M 916 496 m -26 0 a 26 26 0 1 0 52 0 a 26 26 0 1 0 -52 0'},
    ],
    creaseW: 2.4,
    clusters: [
      {x: 372, y: 500, r: 86, boost: 0.5},
      {x: 916, y: 496, r: 84, boost: 0.45},
      {x: 176, y: 416, r: 46, boost: 0.8},
      {x: 142, y: 400, r: 32, boost: 0.6},
    ],
    light: [-1, -0.45],
    axis: [1, 0],
  },
  density: {
    target: 5200,
    falloff: 6,
    flat: 0.028,
    grid: 8,
    sizeMin: 3,
    sizeMax: 9,
    gradLo: 0.52,
    gradHi: 1,
  },
  motion: {
    mode: 'sweep',
    period: 120,
    band: 0.07,
    trail: 0.3,
    gain: 1.15,
  },
  readouts: {
    top: [
      {label: 'EXTRACT.COORD', unit: 'X', lo: 10, hi: 99, dp: 0},
      {label: 'EXTRACT.COORD', unit: 'Y', lo: 10, hi: 99, dp: 0},
      {label: 'EXTRACT.COORD', unit: 'Z', lo: 10, hi: 99, dp: 0},
      {label: 'SCAN.DEPTH', unit: 'MM', lo: 120, hi: 480, dp: 0},
      {label: 'SURF.GAIN', unit: 'DB', lo: 4, hi: 26, dp: 1},
      {label: 'MESH.RES', unit: 'PT', lo: 2000, hi: 9800, dp: 0},
      {label: 'CHAN.LOCK', unit: '%', lo: 78, hi: 100, dp: 0},
      {label: 'PASS.IDX', unit: '', lo: 1, hi: 48, dp: 0},
    ],
    wave: {label: 'SURFACE TRACE', sub: 'DATA_KD2503', energy: 0.55},
    table: {
      label: 'SCANNING DATA',
      tags: [
        'RS7', 'RB2', 'RA4', 'R31', 'RD9', 'RC5', 'RF8', 'R12',
        'RG3', 'RH6', 'RJ1', 'RK7', 'RL4', 'RM9', 'RN2', 'RP5',
        'RQ8', 'RT3', 'RU6', 'RV1', 'RW7', 'RX4', 'RY9', 'RZ2',
      ],
    },
    numA: {label: 'PROFILE CHANNEL', unit: '', lo: 100, hi: 199, dp: 0},
    numB: {label: 'INDEXED CHANNEL', unit: '', lo: 100, hi: 199, dp: 0},
    grid: {
      label: 'LEVEL INDICATORS',
      tags: ['LOW LVL', 'MEDIUM LVL', 'HIGH LVL'],
    },
    meters: {
      label: 'CHANNEL DATA',
      tags: ['C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9', 'CA', 'CB', 'CC'],
    },
    radar: [
      {label: 'SECTOR SCAN', sub: 'ARR-A', turns: 3},
      {label: 'SECTOR SCAN', sub: 'ARR-B', turns: 5},
    ],
    scroll: {
      label: 'SEARCH ID CODES',
      tokens: ['SC', 'KD', 'LM', 'TR', 'QX', 'ZP', 'VN', 'HB', 'WG', 'FY'],
    },
    strips: [
      {label: 'X9', unit: '', lo: 0, hi: 100, dp: 0},
      {label: 'Y6', unit: '', lo: 0, hi: 100, dp: 0},
      {label: 'Z5', unit: '', lo: 0, hi: 100, dp: 0},
    ],
    hist: {label: 'CHANNEL SPECTRUM'},
    numerals: {label: 'RAW DATA STREAM'},
    status: {
      label: 'ONGOING TARGET SCAN',
      states: ['ACQUIRING', 'LOCKED', 'SAMPLING', 'INDEXING'],
    },
  },
};

/* #endregion variant:car */





export const VARIANTS: Record<VariantKey, Variant> = {
  /* #region register:car */
  car: CAR,
  /* #endregion register:car */
} as Record<VariantKey, Variant>;
