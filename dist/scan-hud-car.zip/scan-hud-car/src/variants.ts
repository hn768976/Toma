/**
 * The ONLY place in the project that holds palettes, silhouette path data,
 * density-map rules, subject animation modes and panel labels.
 *
 * Swapping the scanned subject is a data change: nothing downstream knows what
 * a car, a jet or a brain is.
 */

export type VariantKey = 'car';

export type Palette = {
  bg: string;
  line: string;
  fill: string;
  text: string;
  particle: string;
  particleHot: string;
  sweep: string;
  accent: string;
};

/** scale/translate applied to a path so one path string can serve twice. */
export type Xform = [sx: number, sy: number, tx: number, ty: number];

export type PathRef = {d: string; t?: Xform};

export type Cluster = {
  x: number;
  y: number;
  r: number;
  boost: number;
  /** particles in this cluster respond to the motion's clusterPulse */
  pulse?: boolean;
};

export type Silhouette = {
  /** path-space viewBox that the silhouette is rasterised in */
  vb: [number, number];
  /** the region of path space that is fitted to the stage; defaults to vb */
  fit?: [x: number, y: number, w: number, h: number];
  /** filled to build the mask - the union of these is the silhouette */
  fills: PathRef[];
  /** stroked to build the distance field: outer edges + interior creases */
  lines: PathRef[];
  /** stroke width, in path units, used when building the distance field */
  creaseW: number;
  clusters: Cluster[];
  /** brightness gradient direction across the subject */
  light: [number, number];
  /** direction the scan sweep travels */
  axis: [number, number];
  /** subset of `lines` that pulses travel along in "propagate" mode */
  sulci?: PathRef[];
};

export type DensityRule = {
  target: number;
  /** exponential falloff (raster px) from the nearest edge or crease */
  falloff: number;
  /** baseline acceptance across flat interior areas */
  flat: number;
  /** grid the particles snap to, in 4K px */
  grid: number;
  sizeMin: number;
  sizeMax: number;
  gradLo: number;
  gradHi: number;
};

export type Motion =
  | {
      mode: 'sweep';
      /** frames per pass; must divide 600 */
      period: number;
      /** band half-width as a fraction of the subject's span */
      band: number;
      /** trail length as a fraction of the subject's span */
      trail: number;
      gain: number;
      /** optional independent pulse on the bright clusters */
      clusterPulse?: {period: number; amount: number};
    }
  | {
      mode: 'propagate';
      pulses: number;
      lifeMin: number;
      lifeMax: number;
      /** frames a particle takes to decay after a pulse passes */
      decay: number;
      /** how far a pulse spreads along the graph, in path units */
      spread: number;
      gain: number;
    };

export type ValueSpec = {
  label: string;
  unit: string;
  lo: number;
  hi: number;
  dp: number;
};

export type Readouts = {
  top: ValueSpec[];
  wave: {label: string; sub: string; energy: number};
  table: {label: string; tags: string[]};
  numA: ValueSpec;
  numB: ValueSpec;
  grid: {label: string; tags: string[]};
  meters: {label: string; tags: string[]};
  radar: {label: string; sub: string; turns: number}[];
  scroll: {label: string; tokens: string[]};
  strips: ValueSpec[];
  hist: {label: string};
  numerals: {label: string};
  status: {label: string; states: string[]};
};

export type Variant = {
  palette: Palette;
  silhouette: Silhouette;
  density: DensityRule;
  motion: Motion;
  readouts: Readouts;
};

/* ══════════════════════════════════════════════════════════════════════
   #region variant:car
   ══════════════════════════════════════════════════════════════════════ */

/**
 * Generic crossover, three-quarter front view, nose to the left.
 *
 * Built the way an illustrator would: a near-side profile (with the wheel
 * arches cut out of it), plus three narrow "far side" slivers - the front
 * fascia, the bonnet top and the roof top - each pushed up and to the left.
 * Filling all of them unions into a three-quarter silhouette, and the near
 * profile survives inside it as a crease, which is what sells the perspective.
 * No badge, no grille detail, no brand cues.
 */
const CAR_PROFILE =
  'M 176 512 L 148 474 L 144 428 Q 146 390 166 360 ' +
  'C 250 348 356 340 470 334 L 496 330 L 604 232 ' +
  'Q 620 218 654 216 L 900 218 L 962 228 L 1024 302 ' +
  'L 1044 316 L 1072 388 Q 1078 410 1076 436 L 1064 504 ' +
  'L 1006 524 C 1006 440 982 396 918 396 C 854 396 828 440 828 524 ' +
  'L 470 528 C 470 442 444 398 380 398 C 316 398 290 442 290 528 Z';

const CAR_FASCIA =
  'M 166 360 L 144 428 L 148 474 L 176 512 ' +
  'L 148 490 L 124 452 L 120 408 L 138 338 Z';

const CAR_BONNET_TOP =
  'M 166 360 L 138 338 C 240 328 360 320 468 312 L 496 330 ' +
  'C 380 340 260 350 166 360 Z';

const CAR_ROOF_TOP =
  'M 496 330 L 468 312 L 578 214 Q 592 202 626 200 L 878 202 ' +
  'L 938 212 L 962 228 L 900 218 L 654 216 Q 620 218 604 232 Z';

const CAR_REAR_TOP =
  'M 962 228 L 938 212 L 1002 286 L 1024 304 L 1044 316 L 1024 302 Z';

const CAR_WHEEL_F =
  'M 380 508 m -84 0 a 84 84 0 1 0 168 0 a 84 84 0 1 0 -168 0';
const CAR_WHEEL_R =
  'M 918 504 m -82 0 a 82 82 0 1 0 164 0 a 82 82 0 1 0 -164 0';

const CAR: Variant = {
  palette: {
    bg: '#01100E',
    line: '#1A5C52',
    fill: '#04211D',
    text: '#7FD4C4',
    particle: '#4FF5E0',
    particleHot: '#E8FFFA',
    sweep: '#A8FFF0',
    accent: '#2E9F8F',
  },
  silhouette: {
    vb: [1200, 660],
    fit: [112, 188, 976, 406],
    fills: [
      {d: CAR_PROFILE},
      {d: CAR_FASCIA},
      {d: CAR_BONNET_TOP},
      {d: CAR_ROOF_TOP},
      {d: CAR_REAR_TOP},
      // the arch cutouts are wider than the wheels, so a crescent of empty
      // space is left inside each arch and the wheels read as wheels
      {d: CAR_WHEEL_F},
      {d: CAR_WHEEL_R},
    ],
    lines: [
      // outer silhouette, which doubles as the near-side body edge
      {d: CAR_PROFILE},
      {d: CAR_FASCIA},
      {d: CAR_BONNET_TOP},
      {d: CAR_ROOF_TOP},
      {d: CAR_REAR_TOP},
      // beltline, kicking up slightly at the rear quarter
      {d: 'M 496 330 C 630 322 770 316 880 314 C 950 313 1000 318 1032 326'},
      // window frames: B-pillar, C-pillar (upright, with quarter glass behind)
      {d: 'M 744 322 L 736 214'},
      {d: 'M 906 316 L 902 218'},
      // door shut lines
      {d: 'M 540 332 L 546 522'},
      {d: 'M 758 322 L 764 522'},
      // bonnet shut line + bonnet centre crease
      {d: 'M 148 410 C 168 390 194 376 226 368'},
      {d: 'M 190 354 C 290 344 400 336 486 330'},
      // roof centre crease
      {d: 'M 650 206 L 926 210'},
      // wheel arches
      {d: 'M 290 528 C 290 442 316 398 380 398 C 444 398 470 442 470 528'},
      {d: 'M 828 524 C 828 440 854 396 918 396 C 982 396 1006 440 1006 524'},
      // rocker + lower door crease
      {d: 'M 300 514 L 650 522 L 1000 514'},
      {d: 'M 310 462 C 540 470 780 470 1020 458'},
      // headlight wrap
      {d: 'M 146 434 C 170 418 198 408 232 402'},
      {d: 'M 122 428 C 128 400 132 372 138 338'},
      // tail lamp, tailgate shut and rear bumper shut
      {d: 'M 1024 302 C 1044 326 1056 354 1062 386'},
      {d: 'M 1048 330 C 1060 352 1068 374 1072 398'},
      {d: 'M 1044 478 C 1064 470 1074 460 1077 448'},
      // tyre walls and hubs, so the wheels are not flat discs
      {d: 'M 380 508 m -58 0 a 58 58 0 1 0 116 0 a 58 58 0 1 0 -116 0'},
      {d: 'M 380 508 m -28 0 a 28 28 0 1 0 56 0 a 28 28 0 1 0 -56 0'},
      {d: 'M 918 504 m -56 0 a 56 56 0 1 0 112 0 a 56 56 0 1 0 -112 0'},
      {d: 'M 918 504 m -27 0 a 27 27 0 1 0 54 0 a 27 27 0 1 0 -54 0'},
    ],
    creaseW: 2.4,
    clusters: [
      {x: 380, y: 508, r: 88, boost: 0.5},
      {x: 918, y: 504, r: 86, boost: 0.45},
      {x: 172, y: 400, r: 44, boost: 0.8},
      {x: 140, y: 378, r: 32, boost: 0.6},
    ],
    light: [-1, -0.45],
    axis: [1, 0],
  },
  density: {
    target: 5200,
    falloff: 6,
    flat: 0.028,
    grid: 8,
    sizeMin: 3,
    sizeMax: 9,
    gradLo: 0.52,
    gradHi: 1,
  },
  motion: {
    mode: 'sweep',
    period: 120,
    band: 0.07,
    trail: 0.3,
    gain: 1.15,
  },
  readouts: {
    top: [
      {label: 'EXTRACT.COORD', unit: 'X', lo: 10, hi: 99, dp: 0},
      {label: 'EXTRACT.COORD', unit: 'Y', lo: 10, hi: 99, dp: 0},
      {label: 'EXTRACT.COORD', unit: 'Z', lo: 10, hi: 99, dp: 0},
      {label: 'SCAN.DEPTH', unit: 'MM', lo: 120, hi: 480, dp: 0},
      {label: 'SURF.GAIN', unit: 'DB', lo: 4, hi: 26, dp: 1},
      {label: 'MESH.RES', unit: 'PT', lo: 2000, hi: 9800, dp: 0},
      {label: 'CHAN.LOCK', unit: '%', lo: 78, hi: 100, dp: 0},
      {label: 'PASS.IDX', unit: '', lo: 1, hi: 48, dp: 0},
    ],
    wave: {label: 'SURFACE TRACE', sub: 'DATA_KD2503', energy: 0.55},
    table: {
      label: 'SCANNING DATA',
      tags: [
        'RS7', 'RB2', 'RA4', 'R31', 'RD9', 'RC5', 'RF8', 'R12',
        'RG3', 'RH6', 'RJ1', 'RK7', 'RL4', 'RM9', 'RN2', 'RP5',
        'RQ8', 'RT3', 'RU6', 'RV1', 'RW7', 'RX4', 'RY9', 'RZ2',
      ],
    },
    numA: {label: 'PROFILE CHANNEL', unit: '', lo: 100, hi: 199, dp: 0},
    numB: {label: 'INDEXED CHANNEL', unit: '', lo: 100, hi: 199, dp: 0},
    grid: {
      label: 'LEVEL INDICATORS',
      tags: ['LOW LVL', 'MEDIUM LVL', 'HIGH LVL'],
    },
    meters: {
      label: 'CHANNEL DATA',
      tags: ['C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9', 'CA', 'CB', 'CC'],
    },
    radar: [
      {label: 'SECTOR SCAN', sub: 'ARR-A', turns: 3},
      {label: 'SECTOR SCAN', sub: 'ARR-B', turns: 5},
    ],
    scroll: {
      label: 'SEARCH ID CODES',
      tokens: ['SC', 'KD', 'LM', 'TR', 'QX', 'ZP', 'VN', 'HB', 'WG', 'FY'],
    },
    strips: [
      {label: 'X9', unit: '', lo: 0, hi: 100, dp: 0},
      {label: 'Y6', unit: '', lo: 0, hi: 100, dp: 0},
      {label: 'Z5', unit: '', lo: 0, hi: 100, dp: 0},
    ],
    hist: {label: 'CHANNEL SPECTRUM'},
    numerals: {label: 'RAW DATA STREAM'},
    status: {
      label: 'ONGOING TARGET SCAN',
      states: ['ACQUIRING', 'LOCKED', 'SAMPLING', 'INDEXING'],
    },
  },
};

/* #endregion variant:car */





export const VARIANTS: Record<VariantKey, Variant> = {
  /* #region register:car */
  car: CAR,
  /* #endregion register:car */
} as Record<VariantKey, Variant>;
