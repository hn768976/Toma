/**
 * The ONLY place in the project that holds palettes, silhouette path data,
 * density-map rules, subject animation modes and panel labels.
 *
 * Swapping the scanned subject is a data change: nothing downstream knows what
 * a car, a jet or a brain is.
 */

export type VariantKey = 'car';

export type Palette = {
  bg: string;
  line: string;
  fill: string;
  text: string;
  particle: string;
  particleHot: string;
  sweep: string;
  accent: string;
};

/** scale/translate applied to a path so one path string can serve twice. */
export type Xform = [sx: number, sy: number, tx: number, ty: number];

export type PathRef = {d: string; t?: Xform};

export type Cluster = {
  x: number;
  y: number;
  r: number;
  boost: number;
  /** particles in this cluster respond to the motion's clusterPulse */
  pulse?: boolean;
};

export type Silhouette = {
  /** path-space viewBox that the silhouette is rasterised in */
  vb: [number, number];
  /** the region of path space that is fitted to the stage; defaults to vb */
  fit?: [x: number, y: number, w: number, h: number];
  /** filled to build the mask - the union of these is the silhouette */
  fills: PathRef[];
  /** stroked to build the distance field: outer edges + interior creases */
  lines: PathRef[];
  /** stroke width, in path units, used when building the distance field */
  creaseW: number;
  clusters: Cluster[];
  /** brightness gradient direction across the subject */
  light: [number, number];
  /** direction the scan sweep travels */
  axis: [number, number];
  /** subset of `lines` that pulses travel along in "propagate" mode */
  sulci?: PathRef[];
};

export type DensityRule = {
  target: number;
  /** exponential falloff (raster px) from the nearest edge or crease */
  falloff: number;
  /** baseline acceptance across flat interior areas */
  flat: number;
  /** grid the particles snap to, in 4K px */
  grid: number;
  sizeMin: number;
  sizeMax: number;
  gradLo: number;
  gradHi: number;
};

export type Motion =
  | {
      mode: 'sweep';
      /** frames per pass; must divide 600 */
      period: number;
      /** band half-width as a fraction of the subject's span */
      band: number;
      /** trail length as a fraction of the subject's span */
      trail: number;
      gain: number;
      /** optional independent pulse on the bright clusters */
      clusterPulse?: {period: number; amount: number};
    }
  | {
      mode: 'propagate';
      pulses: number;
      lifeMin: number;
      lifeMax: number;
      /** frames a particle takes to decay after a pulse passes */
      decay: number;
      /** how far a pulse spreads along the graph, in path units */
      spread: number;
      gain: number;
    };

export type ValueSpec = {
  label: string;
  unit: string;
  lo: number;
  hi: number;
  dp: number;
};

export type Readouts = {
  top: ValueSpec[];
  wave: {label: string; sub: string; energy: number};
  table: {label: string; tags: string[]};
  numA: ValueSpec;
  numB: ValueSpec;
  grid: {label: string; tags: string[]};
  meters: {label: string; tags: string[]};
  radar: {label: string; sub: string; turns: number}[];
  scroll: {label: string; tokens: string[]};
  strips: ValueSpec[];
  hist: {label: string};
  numerals: {label: string};
  status: {label: string; states: string[]};
};

export type Variant = {
  palette: Palette;
  silhouette: Silhouette;
  density: DensityRule;
  motion: Motion;
  readouts: Readouts;
};

/* ══════════════════════════════════════════════════════════════════════
   #region variant:car
   ══════════════════════════════════════════════════════════════════════ */

/**
 * Generic crossover, three-quarter front view, nose to the left.
 *
 * Built the way an illustrator would: a near-side profile (with the wheel
 * arches cut out of it), plus three narrow "far side" slivers - the front
 * fascia, the bonnet top and the roof top - each pushed up and to the left.
 * Filling all of them unions into a three-quarter silhouette, and the near
 * profile survives inside it as a crease, which is what sells the perspective.
 * No badge, no grille detail, no brand cues.
 */
/**
 * Sleek modern car in side profile, nose to the left.
 *
 * Every line of the upper body is a curve, not a ramp: the nose is rounded,
 * the bonnet is a domed arc that rises fast off the nose and flattens into the
 * cowl, and windshield, roof and rear glass run into one another as a single
 * continuous sweep down to a ducktail kick. Generic - no badge, no grille, no
 * brand cues.
 */
const CAR_PROFILE =
  'M 196 520 C 168 514 148 500 138 476 C 130 458 130 442 136 426 ' +
  'C 142 412 148 406 158 402 C 240 372 350 352 470 344 L 506 340 ' +
  'C 556 298 600 268 656 250 C 706 236 762 232 818 238 ' +
  'C 890 248 962 280 1024 322 L 1054 342 Q 1074 354 1076 378 ' +
  'L 1080 404 Q 1082 426 1074 450 L 1052 504 ' +
  'L 1000 518 C 1000 438 976 396 916 396 C 856 396 832 438 832 518 ' +
  'L 460 524 C 460 442 434 398 372 398 C 310 398 286 442 286 524 Z';

const CAR_FASCIA =
  'M 158 402 C 148 406 142 412 136 426 C 130 442 130 458 138 476 ' +
  'C 148 500 168 514 196 520 L 180 508 C 154 494 140 472 138 448 ' +
  'C 136 424 142 406 152 388 Z';

const CAR_BONNET_TOP =
  'M 158 402 C 240 372 350 352 470 344 L 506 340 L 490 326 ' +
  'C 370 334 250 354 152 388 Z';

const CAR_ROOF_TOP =
  'M 506 340 L 490 326 C 546 286 592 256 650 238 ' +
  'C 704 224 762 220 820 226 L 818 238 ' +
  'C 762 232 706 236 656 250 C 600 268 556 298 506 340 Z';

const CAR_REAR_TOP =
  'M 820 226 C 892 236 966 268 1030 310 L 1024 322 ' +
  'C 962 280 890 248 818 238 Z';

const CAR_WHEEL_F =
  'M 372 500 m -82 0 a 82 82 0 1 0 164 0 a 82 82 0 1 0 -164 0';
const CAR_WHEEL_R =
  'M 916 496 m -80 0 a 80 80 0 1 0 160 0 a 80 80 0 1 0 -160 0';

const CAR: Variant = {
  palette: {
    bg: '#01100E',
    line: '#1A5C52',
    fill: '#04211D',
    text: '#7FD4C4',
    particle: '#4FF5E0',
    particleHot: '#E8FFFA',
    sweep: '#A8FFF0',
    accent: '#2E9F8F',
  },
  silhouette: {
    vb: [1200, 660],
    fit: [118, 214, 974, 382],
    fills: [
      {d: CAR_PROFILE},
      {d: CAR_FASCIA},
      {d: CAR_BONNET_TOP},
      {d: CAR_ROOF_TOP},
      {d: CAR_REAR_TOP},
      // the arch cutouts are wider than the wheels, so a crescent of empty
      // space is left inside each arch and the wheels read as wheels
      {d: CAR_WHEEL_F},
      {d: CAR_WHEEL_R},
    ],
    lines: [
      // outer silhouette, which doubles as the near-side body edge
      {d: CAR_PROFILE},
      {d: CAR_FASCIA},
      {d: CAR_BONNET_TOP},
      {d: CAR_ROOF_TOP},
      {d: CAR_REAR_TOP},
      // beltline, rising gently toward the tail
      {d: 'M 506 340 C 640 334 780 328 890 326 C 950 325 1000 328 1046 336'},
      // window frames: B-pillar, raked rear-quarter pillar
      {d: 'M 740 330 L 730 234'},
      {d: 'M 890 326 L 858 236'},
      // door shut lines
      {d: 'M 548 344 L 554 518'},
      {d: 'M 754 330 L 760 516'},
      // bonnet shut line at the nose + the bonnet's own crown crease
      {d: 'M 146 430 C 162 412 180 402 206 394'},
      {d: 'M 180 412 C 258 386 360 368 476 360'},
      // roof crown crease
      {d: 'M 668 244 C 720 234 764 232 806 236'},
      // long character line down the flank
      {d: 'M 250 430 C 520 418 800 410 1052 398'},
      // wheel arches
      {d: 'M 286 524 C 286 442 310 398 372 398 C 434 398 460 442 460 524'},
      {d: 'M 832 518 C 832 438 856 396 916 396 C 976 396 1000 438 1000 518'},
      // rocker + lower door crease
      {d: 'M 296 510 L 646 518 L 996 510'},
      {d: 'M 310 478 C 550 486 790 484 1020 470'},
      // headlight wrap and the fascia's lower edge
      {d: 'M 140 440 C 158 420 182 408 214 400'},
      {d: 'M 138 476 C 152 492 172 506 196 520'},
      // tail lamp, decklid shut and rear bumper shut
      {d: 'M 1024 322 C 1046 336 1062 352 1070 372'},
      {d: 'M 1054 342 C 1066 358 1072 374 1074 392'},
      {d: 'M 1038 472 C 1058 464 1070 454 1075 442'},
      // tyre walls and hubs, so the wheels are not flat discs
      {d: 'M 372 500 m -56 0 a 56 56 0 1 0 112 0 a 56 56 0 1 0 -112 0'},
      {d: 'M 372 500 m -27 0 a 27 27 0 1 0 54 0 a 27 27 0 1 0 -54 0'},
      {d: 'M 916 496 m -55 0 a 55 55 0 1 0 110 0 a 55 55 0 1 0 -110 0'},
      {d: 'M 916 496 m -26 0 a 26 26 0 1 0 52 0 a 26 26 0 1 0 -52 0'},
    ],
    creaseW: 2.4,
    clusters: [
      {x: 372, y: 500, r: 86, boost: 0.5},
      {x: 916, y: 496, r: 84, boost: 0.45},
      {x: 168, y: 420, r: 46, boost: 0.8},
      {x: 140, y: 444, r: 30, boost: 0.6},
    ],
    light: [-1, -0.45],
    axis: [1, 0],
  },
  density: {
    target: 5200,
    falloff: 6,
    flat: 0.028,
    grid: 8,
    sizeMin: 3,
    sizeMax: 9,
    gradLo: 0.52,
    gradHi: 1,
  },
  motion: {
    mode: 'sweep',
    period: 120,
    band: 0.07,
    trail: 0.3,
    gain: 1.15,
  },
  readouts: {
    top: [
      {label: 'EXTRACT.COORD', unit: 'X', lo: 10, hi: 99, dp: 0},
      {label: 'EXTRACT.COORD', unit: 'Y', lo: 10, hi: 99, dp: 0},
      {label: 'EXTRACT.COORD', unit: 'Z', lo: 10, hi: 99, dp: 0},
      {label: 'SCAN.DEPTH', unit: 'MM', lo: 120, hi: 480, dp: 0},
      {label: 'SURF.GAIN', unit: 'DB', lo: 4, hi: 26, dp: 1},
      {label: 'MESH.RES', unit: 'PT', lo: 2000, hi: 9800, dp: 0},
      {label: 'CHAN.LOCK', unit: '%', lo: 78, hi: 100, dp: 0},
      {label: 'PASS.IDX', unit: '', lo: 1, hi: 48, dp: 0},
    ],
    wave: {label: 'SURFACE TRACE', sub: 'DATA_KD2503', energy: 0.55},
    table: {
      label: 'SCANNING DATA',
      tags: [
        'RS7', 'RB2', 'RA4', 'R31', 'RD9', 'RC5', 'RF8', 'R12',
        'RG3', 'RH6', 'RJ1', 'RK7', 'RL4', 'RM9', 'RN2', 'RP5',
        'RQ8', 'RT3', 'RU6', 'RV1', 'RW7', 'RX4', 'RY9', 'RZ2',
      ],
    },
    numA: {label: 'PROFILE CHANNEL', unit: '', lo: 100, hi: 199, dp: 0},
    numB: {label: 'INDEXED CHANNEL', unit: '', lo: 100, hi: 199, dp: 0},
    grid: {
      label: 'LEVEL INDICATORS',
      tags: ['LOW LVL', 'MEDIUM LVL', 'HIGH LVL'],
    },
    meters: {
      label: 'CHANNEL DATA',
      tags: ['C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9', 'CA', 'CB', 'CC'],
    },
    radar: [
      {label: 'SECTOR SCAN', sub: 'ARR-A', turns: 3},
      {label: 'SECTOR SCAN', sub: 'ARR-B', turns: 5},
    ],
    scroll: {
      label: 'SEARCH ID CODES',
      tokens: ['SC', 'KD', 'LM', 'TR', 'QX', 'ZP', 'VN', 'HB', 'WG', 'FY'],
    },
    strips: [
      {label: 'X9', unit: '', lo: 0, hi: 100, dp: 0},
      {label: 'Y6', unit: '', lo: 0, hi: 100, dp: 0},
      {label: 'Z5', unit: '', lo: 0, hi: 100, dp: 0},
    ],
    hist: {label: 'CHANNEL SPECTRUM'},
    numerals: {label: 'RAW DATA STREAM'},
    status: {
      label: 'ONGOING TARGET SCAN',
      states: ['ACQUIRING', 'LOCKED', 'SAMPLING', 'INDEXING'],
    },
  },
};

/* #endregion variant:car */





export const VARIANTS: Record<VariantKey, Variant> = {
  /* #region register:car */
  car: CAR,
  /* #endregion register:car */
} as Record<VariantKey, Variant>;
