import React, {useLayoutEffect, useMemo} from 'react';
import {rgba} from '../lib/color';
import {rnd, rndInt, rndRange} from '../lib/rng';
import {CANVAS_H, CANVAS_W} from '../lib/space';
import {LOOP, useLoopFrame} from '../lib/timing';
import type {BackgroundMode, Palette} from '../variants';

type Props = {
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  palette: Palette;
  mode: BackgroundMode;
  seed: string;
};


/** Illegible "data": digits and hex-ish symbols in a font that always resolves. */
const GLYPHS = '0123456789ABCDEF/\\|<>{}[]#$%&*+=~:;.-_^';
const TEXT_ROWS = 30;
// One tile spans the whole frame, so a row never visibly repeats within it.
const TEXT_TILE_W = CANVAS_W;
const TEXT_TILE_H = 44;
const TEXT_CHAR = 26;

type TextRow = {
  tile: HTMLCanvasElement;
  y: number;
  /** Whole tile-widths travelled per loop, so the scroll wraps seamlessly. */
  laps: number;
  alpha: number;
  offset: number;
};

const buildText = (seed: string, color: string): TextRow[] => {
  const rows: TextRow[] = [];
  for (let i = 0; i < TEXT_ROWS; i++) {
    const s = `${seed}:text:${i}`;
    const cv = document.createElement('canvas');
    cv.width = TEXT_TILE_W;
    cv.height = TEXT_TILE_H;
    const tctx = cv.getContext('2d');
    if (!tctx) continue;
    tctx.font = `${TEXT_CHAR}px monospace`;
    tctx.textBaseline = 'middle';
    tctx.fillStyle = color;
    const step = TEXT_CHAR * 0.78;
    for (let c = 0; c * step < TEXT_TILE_W; c++) {
      if (rnd(`${s}:gap${c}`) < 0.18) continue;
      const g = GLYPHS[rndInt(`${s}:g${c}`, GLYPHS.length)];
      tctx.globalAlpha = rndRange(`${s}:a${c}`, 0.35, 1);
      tctx.fillText(g, c * step, TEXT_TILE_H / 2);
    }
    rows.push({
      tile: cv,
      y: (i + rnd(`${s}:jy`) * 0.6) * (CANVAS_H / TEXT_ROWS),
      laps: rnd(`${s}:lap`) < 0.75 ? 1 : 2,
      alpha: rndRange(`${s}:al`, 0.07, 0.21),
      offset: rnd(`${s}:of`) * TEXT_TILE_W,
    });
  }
  return rows;
};

/** Rows of characters flowing right, the same way the data streams run. */
const drawText = (
  ctx: CanvasRenderingContext2D,
  rows: TextRow[],
  frame: number,
) => {
  ctx.save();
  for (const row of rows) {
    const shift =
      (row.offset + (frame / LOOP) * row.laps * TEXT_TILE_W) % TEXT_TILE_W;
    ctx.globalAlpha = row.alpha;
    for (let x = shift - TEXT_TILE_W; x < CANVAS_W; x += TEXT_TILE_W) {
      ctx.drawImage(row.tile, x, row.y);
    }
  }
  ctx.restore();
};


/** Whatever the chosen background mode needs to have prepared once. */
type BackgroundData =
  | {kind: 'text'; rows: TextRow[]}
  ;

/**
 * Takes the whole prop bag rather than the individual pieces so that pruning a
 * mode out never leaves an unused parameter behind.
 */
const buildBackground = (props: Props): BackgroundData => {
  if (props.mode === 'text') {
    return {kind: 'text', rows: buildText(props.seed, props.palette.accent)};
  }
  throw new Error(`unknown background mode: ${String(props.mode)}`);
};

export const BackgroundLayer: React.FC<Props> = (props) => {
  const {canvasRef, palette} = props;
  const frame = useLoopFrame();
  // Keyed on the fields rather than on `props` itself: the prop object is a
  // fresh identity every frame, and rebuilding 30 text tiles per frame is not.
  const data = useMemo(
    () => buildBackground(props),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [props.mode, props.seed, props.palette],
  );

  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    ctx.fillStyle = palette.bgDeep;
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    // Two soft glows: upper-left and centre. Both breathe over the full loop.
    const pulse = 1 + 0.05 * Math.sin((2 * Math.PI * frame) / LOOP);
    const glows: [number, number, number, number][] = [
      [CANVAS_W * 0.16, CANVAS_H * 0.2, CANVAS_W * 0.46 * pulse, 0.55],
      [CANVAS_W * 0.5, CANVAS_H * 0.56, CANVAS_W * 0.4 * (2 - pulse), 0.4],
    ];
    ctx.globalCompositeOperation = 'lighter';
    for (const [gx, gy, gr, ga] of glows) {
      const g = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr);
      g.addColorStop(0, rgba(palette.bgGlow, ga));
      g.addColorStop(0.5, rgba(palette.bgGlow, ga * 0.28));
      g.addColorStop(1, rgba(palette.bgGlow, 0));
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    }
    ctx.globalCompositeOperation = 'source-over';

    if (data.kind === 'text') drawText(ctx, data.rows, frame);
  }, [canvasRef, palette, data, frame]);

  return null;
};
