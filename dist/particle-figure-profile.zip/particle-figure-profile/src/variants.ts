import type {Silhouette, StrokeSpec} from './lib/mask';

export type Palette = {
  bgDeep: string;
  bgGlow: string;
  primary: string;
  white: string;
  secondary: string;
  accent: string;
};

export type BackgroundMode = 'text';
export type SubjectMode = 'shimmer';

export type VariantSpec = {
  palette: Palette;
  /** Authored in the 1920x1080 design space (see lib/space.ts). */
  silhouette: Silhouette;
  /** Interior lines that add particle density without widening the mask. */
  creases: StrokeSpec[];
  background: BackgroundMode;
  subject: SubjectMode;
};

export type VariantName = 'profile';

/**
 * The single source of truth for every colour and every shape in the piece.
 * Nothing outside this file may contain a hex literal or a path string.
 */
export const VARIANTS: Record<VariantName, VariantSpec> = {
  profile: {
    palette: {
      bgDeep: '#0B0A2E',
      bgGlow: '#241F6B',
      primary: '#6F5FE8',
      white: '#EDEAFF',
      secondary: '#4F3FC4',
      accent: '#A89FF5',
    },
    // The subject is the word AI, outlined from Roboto Black (weight 900) by
    // tools/extract-word-path.mjs and pasted here: 934 x 700 design units,
    // centred in the frame. Baking the outlines means nothing has to load a
    // font at render time. The A arrives as three contours — two strokes and a
    // crossbar — that share a winding direction, so the nonzero fill unions
    // them and leaves the counter open.
    silhouette: {
      fill: [
        'M 865 190 L 844.9 337.1 L 674.2 890 L 492.9 890 L 750.1 190 L 865 190',
        'M 1167.9 890 L 986.2 890 L 815 337.1 L 792.9 190 L 909.3 190 L 1167.9 890',
        'M 620.3 628.9 L 979.5 628.9 L 979.5 759.2 L 620.3 759.2 L 620.3 628.9',
        'M 1258.8 190 L 1427.1 190 L 1427.1 890 L 1258.8 890 L 1258.8 190',
      ].join(' '),
      strokes: [],
    },
    // Letterforms have no creases; the edge weighting alone cuts them out.
    creases: [],
    background: 'text',
    subject: 'shimmer',
  },
};
