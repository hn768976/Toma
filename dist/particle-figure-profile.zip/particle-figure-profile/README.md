# Particle Figure — Profile

The same head and shoulders in full left profile, indigo, with ribbons of particles streaming out of the back of the skull over drifting rows of illegible characters.

A single Remotion composition rendered entirely into one 2D `<canvas>`. No 3D,
no WebGL, no `requestAnimationFrame`: every value on screen is a pure function
of `useCurrentFrame()`.

| | |
| --- | --- |
| Composition id | `ParticleFigureProfile` |
| Resolution | **4K — 3840 × 2160** |
| Duration | **480 frames** (16.0 s) |
| Frame rate | **30 fps** |
| Loop | seamless — frame 0 and frame 480 are pixel-identical |
| Audio | none |

## Install

```bash
npm install
```

## Render at 4K

```bash
npx remotion render ParticleFigureProfile out/profile-4k.mp4 --codec=h264 --crf=18
```

The canvas backing store is always 3840 × 2160, so `--scale=0.5` gives a true
1080p downsample of the same 4K image rather than a smaller render:

```bash
npx remotion render ParticleFigureProfile out/profile-1080p.mp4 --codec=h264 --crf=18 --scale=0.5
```

`--concurrency=N` may be added; Remotion caps N at the machine's core count.

## Preview

```bash
npm run dev
```

## How it is put together

- `src/variants.ts` — the only file containing a hex literal or a path string:
  palette, silhouette, background mode and subject animation mode.
- `src/lib/mask.ts` — rasterises the silhouette to a mask and derives an
  edge-distance field, a crease field, and per-row/per-column span bounds.
- `src/lib/grid.ts` — the distorted grid. Vertical lines are spaced evenly in a
  surface *angle*, and `sin` of that angle is where they land on screen, so
  spacing compresses toward the silhouette boundary exactly the way a cylinder's
  surface does. This is what makes a flat mask read as a body with volume.
- `src/lib/particles.ts` — samples ~7000 particles **once** against the mask,
  weighted toward the boundary so the interior stays sparse and dark, then snaps
  them onto that same grid.
- `src/components/` — `BackgroundLayer`, `GridOverlay` and
  `SubjectParticles` each paint into one shared canvas from a layout effect;
  React flushes those in tree order, which fixes the compositing order.

## Timeline

| Frames | |
| --- | --- |
| 0 – 30 | background only |
| 30 – 120 | the figure assembles out of a wide scatter |
| 120 – 420 | idle: it never rotates or translates, it breathes (±0.8% scale, 4 s period) |
| 420 – 480 | it dissolves back to the scatter it came from |

The last phase is what makes the loop seamless. A loop whose first frame is
"empty background only" can only return to that state if the figure leaves, so
the dissolve mirrors the assembly and frame 480 lands exactly on frame 0.
