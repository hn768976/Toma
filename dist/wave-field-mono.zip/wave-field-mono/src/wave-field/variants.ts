/**
 * Every colour and every per-version parameter of the piece lives here.
 * No hex literal appears anywhere else in the wave-field source.
 */

export const VARIANT_NAMES = ["mono"] as const;

export type VariantName = (typeof VARIANT_NAMES)[number];

export type MeshMode = "sparse" | "dense" | "none";

export interface ParticleTone {
  /** Hex colour, taken from the variant palette. */
  color: string;
  /** Relative share of the particle field. Weights need not sum to 1. */
  weight: number;
}

export interface Palette {
  backgroundDeep: string;
  backgroundWash: string;
  meshLine: string;
  /** The leading-edge dots. */
  edgeAccent: string;
  /** The hot cores of the leading-edge dots, and their outer glow. */
  edgeCore: string;
  /** Tint of the faint surface strands that make a band read as a surface. */
  strand: string;
  /** Mixed particle hues: accent dominant, cooler and warmer variants through it. */
  particleTones: ParticleTone[];
}

export interface Harmonic {
  /**
   * Whole number of crests across BAND_LENGTH. Integer so the surface is
   * periodic along the band and drifting particles wrap seamlessly.
   */
  spatial: number;
  /**
   * Whole number of cycles the wave travels in 450 frames. Integer so the
   * phase returns exactly to its start at frame 450.
   */
  temporal: number;
  /** Amplitude at the band's lower fringe, in 4K pixels. */
  amp: number;
  /** Fixed phase offset, in turns. */
  phase: number;
}

export interface VariantConfig {
  palette: Palette;
  /** How strongly the background wash lifts off the deep tone, 0 to 1. */
  washStrength: number;

  /** Number of parallel bands stacked across the frame. */
  bandCount: number;
  /** Perpendicular distance between one band's leading edge and the next. */
  bandPitch: number;
  /** How far a band's surface hangs below its leading edge. */
  bandThickness: number;
  /** Iso-depth strands drawn per band to render the surface. */
  strandRows: number;
  strandAlpha: number;

  /** Total particles across all bands. */
  particleCount: number;
  particleLength: [number, number];
  particleWidth: [number, number];
  particleAlpha: [number, number];

  /** Leading-edge dots: uniform size and uniform spacing within a band. */
  dotSpacing: number;
  dotRadius: number;
  /** Crests of the travelling brightness pulse present along a band at once. */
  pulseCrests: number;
  /** Whole cycles the pulse travels in 450 frames, so its period divides 450. */
  pulseTravel: number;
  /** Higher values make the pulse a tighter, more pronounced bright wave. */
  pulseSharpness: number;

  meshMode: MeshMode;
  meshCount: number;
  meshAlpha: number;

  harmonics: Harmonic[];
  /** Per-band extra whole cycles per 450 frames, so bands never move in lockstep. */
  bandRateOffsets: number[];
  /** Nearest and farthest band scale, driving particle size and dot size. */
  depthScale: [number, number];
}

// --- the "mono" palette: no colour at all ---

const MONO_BACKGROUND_DEEP = "#050508";
const MONO_BACKGROUND_WASH = "#12141A";
const MONO_MESH_LINE = "#1E2028";
const MONO_EDGE_WHITE = "#FFFFFF";
const MONO_EDGE_PALE = "#E0E4EA";
const MONO_PARTICLE_PALE = "#B0B8C4";
const MONO_PARTICLE_MID = "#6A7280";
const MONO_PARTICLE_BRIGHT = "#F0F4F8";
const MONO_PARTICLE_DIM = "#3A4048";

export const VARIANTS: Record<VariantName, VariantConfig> = {

  mono: {
    palette: {
      backgroundDeep: MONO_BACKGROUND_DEEP,
      backgroundWash: MONO_BACKGROUND_WASH,
      meshLine: MONO_MESH_LINE,
      edgeAccent: MONO_EDGE_WHITE,
      edgeCore: MONO_EDGE_PALE,
      strand: MONO_PARTICLE_PALE,
      particleTones: [
        { color: MONO_PARTICLE_PALE, weight: 0.44 },
        { color: MONO_PARTICLE_MID, weight: 0.26 },
        { color: MONO_PARTICLE_BRIGHT, weight: 0.14 },
        { color: MONO_PARTICLE_DIM, weight: 0.16 },
      ],
    },
    washStrength: 1,
    // Two bands instead of seven, each roughly 40% of frame height. The
    // negative space between and around them is a major element here.
    bandCount: 2,
    bandPitch: 1250,
    bandThickness: 900,
    strandRows: 40,
    strandAlpha: 0.28,
    // Fewer particles at roughly double v1's size and far more varied in
    // length, so each one is individually visible. With no colour to carry
    // variety, size and length have to.
    particleCount: 4000,
    particleLength: [55, 230],
    particleWidth: [7.2, 13],
    particleAlpha: [0.2, 1],
    // Larger and more widely spaced than v1, with a far more pronounced
    // travelling pulse. With no colour and few elements, this is the main event.
    dotSpacing: 130,
    dotRadius: 30,
    pulseCrests: 1,
    pulseTravel: 2,
    pulseSharpness: 11,
    meshMode: "none",
    meshCount: 0,
    meshAlpha: 0,
    // Much higher amplitude and much longer wavelength than v1: one or two
    // large sweeping swells across the frame rather than many small ones, so
    // the wave is the frame's dominant shape rather than a texture within it.
    harmonics: [
      { spatial: 2, temporal: 2, amp: 330, phase: 0 },
      { spatial: 3, temporal: -1, amp: 120, phase: 0.37 },
      { spatial: 5, temporal: 3, amp: 52, phase: 0.8 },
    ],
    bandRateOffsets: [0, 1],
    depthScale: [0.8, 1.05],
  },
};
