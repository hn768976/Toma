import { Composition } from "remotion";
import { WaveField, waveFieldSchema } from "./wave-field/WaveField";
import {
  DURATION_IN_FRAMES,
  FPS,
  HEIGHT,
  WIDTH,
} from "./wave-field/constants";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="WaveFieldMono"
      component={WaveField}
      durationInFrames={DURATION_IN_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      schema={waveFieldSchema}
      defaultProps={{ variant: "mono" as const }}
    />
  );
};
