import React from 'react';
import {Composition} from 'remotion';
import {Lightning} from './Lightning';
import {VARIANT, VARIANT_NAME} from './variant';

export const RemotionRoot: React.FC = () => {
	const {durationInFrames, fps, width, height} = VARIANT.timing;

	return (
		<Composition
			id="LightningBlue"
			component={Lightning}
			durationInFrames={durationInFrames}
			fps={fps}
			width={width}
			height={height}
			defaultProps={{variant: VARIANT_NAME}}
		/>
	);
};
