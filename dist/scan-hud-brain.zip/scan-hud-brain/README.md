# Scan HUD — Brain

A 4K "HUD scan" animation built with [Remotion](https://remotion.dev): a full
screen heads-up display with a human brain in side view, facing left rendered as a field of ~5000
particles in the central viewport.

## The composition

| | |
| --- | --- |
| Composition id | `ScanHudBrain` |
| Resolution | **3840 × 2160 (4K)** |
| Duration | 600 frames |
| Frame rate | 30 fps — 20.0 seconds |
| Loop | seamless: frame 600 is pixel-identical to frame 0 |
| Palette | green on near-black green |

## Fonts

Roboto Mono and Barlow Condensed are loaded through `@remotion/google-fonts`
and **fetched from `fonts.gstatic.com` on the first run**, gated with
`delayRender()` / `continueRender()` so no frame is captured before they land.
Identical copies of both faces are vendored in `public/fonts` and registered
under the same family names automatically if that host cannot be reached, so a
render never blocks on the network.

## Install

```sh
npm install
```

## Preview

```sh
npx remotion studio
```

## Render

Full 4K:

```sh
npx remotion render ScanHudBrain out/scan-hud-brain.mp4 --codec=h264 --crf=12 --concurrency=8
```

1080p preview (half scale):

```sh
npx remotion render ScanHudBrain out/scan-hud-brain-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

Lower `--concurrency` if the machine has fewer than 8 cores.

## How it works

**Everything is a pure function of `useCurrentFrame()`.** No `Date.now()`, no
`requestAnimationFrame`, no CSS animation, no component state driving motion.
Every random value comes from Remotion's `random()` with a stable string seed,
and every cadence — twinkle periods, panel re-rolls, radar rotations, the sweep
— divides 600 exactly, which is what makes the loop close.

**`src/variants.ts` is the only place** that holds a palette, a silhouette path,
a density rule, an animation mode or a panel label. Nothing downstream knows
what the subject is.

**The particle field** (`src/lib/silhouette.ts`) is built once per render:

1. the silhouette is filled into an offscreen canvas;
2. its outer edges and its interior crease lines are stroked into a second one;
3. a chamfer distance transform turns that into a distance field — for every
   pixel, how far to the nearest edge or crease;
4. the cells of a coarse 8px grid are then accepted with a probability that
   falls off exponentially with that distance, so particles crowd the edges and
   creases and thin out across flat interior areas. Nothing is placed by hand.

A brightness gradient across the subject supplies the sense of volume, and each
particle twinkles on its own seeded sine whose period divides 600.

**The motion.** No sweep. Bright pulses originate at random points and travel ALONG the sulci, branching into two or three continuing fronts wherever folds meet and fading as they spread. Three to five pulses are alive at any moment, each lasting 40-70 frames, and the EEG trace spikes in sync with them.

**Performance.** The particle set is sampled once. The HUD frame and every
panel's chrome are rasterised once into offscreen canvases and blitted; only
values, the sweep and particle brightness are redrawn per frame.

## Layout

```
src/
  index.ts                    registerRoot
  Root.tsx                    the ScanHudBrain composition
  ScanHud.tsx                 layout, timeline, ambient drift
  variants.ts                 palette, paths, density, motion, labels
  components/
    HudFrame.tsx              brackets, dividers, viewport window
    SidePanel.tsx             a region of the HUD
    ReadoutBlock.tsx          the twelve panel kinds
    SubjectParticles.tsx      the particle field
    ScanSweep.tsx             the sweep band and its maths
    Overlay.tsx               vignette, scanlines, grain
  lib/
    layout.ts                 4K geometry
    silhouette.ts             mask, distance field, sampling
    propagate.ts              pulse graph and wavefronts
    chrome.ts                 panel shell drawing
    color.ts  fonts.ts  rand.ts
public/fonts/                 vendored webfont fallbacks
```
