import React from 'react';
import {Composition} from 'remotion';
import {ScanHud} from './ScanHud';
import {DURATION, FPS, H, W} from './lib/layout';

export const RemotionRoot: React.FC = () => {
  return (
    <>
      {/* #region register:brain */}
      <Composition
        id="ScanHudBrain"
        component={ScanHud}
        durationInFrames={DURATION}
        fps={FPS}
        width={W}
        height={H}
        defaultProps={{variant: 'brain' as const}}
      />
      {/* #endregion register:brain */}
    </>
  );
};
