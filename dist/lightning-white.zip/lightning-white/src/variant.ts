/**
 * The ONE place where the palette, bolt parameters, strike schedule, flash
 * profile and ambient settings live. No colour literal and no timing number
 * appears anywhere else in the project — every other module reads from here.
 */

export type VariantName = 'white';

/** Inclusive numeric range, resolved with a seeded random. */
export interface Range {
	min: number;
	max: number;
}

export interface Palette {
	/** Near-black base of the frame. */
	background: string;
	/** Cloud haze in the upper third. */
	haze: string;
	/** Pass 1 — very wide atmospheric glow. */
	glowWide: string;
	/** Pass 2 — outer glow. */
	glowOuter: string;
	/** Pass 3 — mid channel (in the "white" variant this is the warm band). */
	channel: string;
	/** Pass 4 — the hot core. */
	core: string;
}

export interface BoltConfig {
	/**
	 * Signed travel direction: 1 travels down the frame, -1 travels up it.
	 * Every generated point is mapped through this sign, so path shape,
	 * branch angles and stroke taper all invert with it.
	 */
	strikeDirection: 1 | -1;
	/** How many simultaneous bolts an event fires. */
	count: Range;
	/** Normalised x of the bolt origin along the edge it starts from. */
	originX: Range;
	/** Normalised distance travelled, as a fraction of frame height. */
	travel: Range;
	/** Normalised sideways drift of the target point, fraction of frame width. */
	drift: Range;
	/** Levels of recursive midpoint displacement on the main channel. */
	depth: number;
	/** Level-0 displacement amplitude as a fraction of the travel distance. */
	displacementScale: number;
	/** Displacement amplitude multiplier per recursion level. */
	displacementFalloff: number;
	/** Recursion levels shallow enough to spawn a branch. */
	branchLevels: number;
	/** Seeded probability of a branch at an eligible midpoint. */
	branchProbability: number;
	/** Branch count kept per bolt after the probability pass. */
	branchCount: Range;
	/** Sub-branch count kept per branch. */
	subBranchCount: Range;
	/** Generations of branching (1 = forks only, 3 = forks of forks of forks). */
	branchDepth: number;
	/** Branch deflection from the parent direction, radians. */
	branchAngle: Range;
	/** Branch length as a fraction of the parent's remaining length. */
	branchLength: Range;
	/** 0 spreads branches evenly, 1 pushes them towards the far tip. */
	branchBias: number;
	/** Brightness multiplier applied per branch generation. */
	branchBrightnessFalloff: number;
	/** Width multiplier applied per branch generation. */
	branchWidthFalloff: number;
	/** Stroke widths at the origin, in 4K canvas pixels. */
	width: {wide: number; outer: number; channel: number; core: number};
	/** Width at the far tip as a fraction of the width at the origin. */
	tipWidth: number;
	/** Per-pass alpha before the peak-brightness multiplier. */
	alpha: {wide: number; outer: number; channel: number; core: number};
	/** shadowBlur per pass, in 4K canvas pixels. */
	blur: {wide: number; outer: number; channel: number; core: number};
	/** Extra additive bloom on the core. */
	bloom: {alpha: number; blur: number; width: number};
	/** Master brightness of one bolt. */
	peakBrightness: number;
	/** Frames a bolt within an event lags behind the flash it belongs to. */
	stagger: Range;
}

export interface ScheduleConfig {
	/** Strike events across the loop. */
	events: number;
	/** Return strokes per event. */
	flashesPerEvent: Range;
	/** Frames a single flash stays lit. */
	flashDuration: Range;
	/** Dark frames between flashes inside one burst. */
	flashGap: Range;
	/** Dark frames between events. */
	eventPause: Range;
	/** Per-flash brightness. */
	flashIntensity: Range;
	/** Dark frames before the first event. */
	headDark: number;
	/** Dark frames after the last event — keeps the loop point clean. */
	tailDark: number;
}

export interface AmbientConfig {
	/** Radius of the soft wash painted around a lit channel, 4K pixels. */
	glowRadius: number;
	/** Peak alpha of that wash. */
	glowAlpha: number;
	/** Frames the wash takes to decay after a flash. */
	glowDecayFrames: number;
	/** Points sampled along a channel when painting the wash. */
	glowSamples: number;
	/** Cloud bands in the upper third. */
	hazeBands: number;
	/** Base alpha of the haze. */
	hazeAlpha: number;
	/** Extra haze alpha at full flash brightness. */
	hazeLift: number;
	/** Haze drift across one loop, as a fraction of frame width. */
	hazeDrift: number;
	/** Fraction of frame height the haze occupies. */
	hazeHeight: number;
	/** How much haze colour is mixed into the top of the background gradient. */
	backgroundTopMix: number;
	/** Same, for the bottom of the background gradient. */
	backgroundBottomMix: number;
}

export interface FrameFlashConfig {
	/** Colour the whole frame lifts to. */
	color: string;
	/** Frames the lift is held at full strength. */
	holdFrames: number;
	/** Frames the lift takes to fall back to black. */
	decayFrames: number;
	/** Bursts whose brightest return stroke is dimmer than this do not lift. */
	threshold: number;
}

export interface FinishConfig {
	/** Vignette strength at the corners. */
	vignette: number;
	/** Grain alpha. */
	grainAlpha: number;
	/** Edge of the square noise tile, in noise cells. */
	grainTile: number;
	/** Canvas pixels per noise cell. Cells larger than a pixel keep the grain
	 * stable when the 4K frame is previewed at a smaller scale. */
	grainCell: number;
}

export interface VariantConfig {
	timing: {durationInFrames: number; fps: number; width: number; height: number};
	palette: Palette;
	bolt: BoltConfig;
	schedule: ScheduleConfig;
	ambient: AmbientConfig;
	/** null on variants that do not wash the whole frame. */
	frameFlash: FrameFlashConfig | null;
	finish: FinishConfig;
}

const TIMING = {durationInFrames: 300, fps: 30, width: 3840, height: 2160};

export const VARIANT_NAME: VariantName = 'white';

/**
 * v3 — a very close strike, travelling upward out of the top of frame.
 * One decisive channel, almost no forks, the highest peak brightness, a
 * whole-frame overexposure flash and a long afterglow.
 */
export const VARIANT: VariantConfig = {
	timing: TIMING,
	palette: {
		background: '#030303',
		haze: '#1A1A1E',
		glowWide: '#4A6A9F',
		glowOuter: '#A8C4E8',
		channel: '#FFF4D8',
		core: '#FFFFFF',
	},
	bolt: {
		strikeDirection: -1,
		count: {min: 1, max: 1},
		originX: {min: 0.44, max: 0.56},
		travel: {min: 1.02, max: 1.12},
		drift: {min: -0.08, max: 0.08},
		depth: 6,
		displacementScale: 0.07,
		displacementFalloff: 0.5,
		branchLevels: 2,
		branchProbability: 0.5,
		branchCount: {min: 1, max: 2},
		subBranchCount: {min: 0, max: 1},
		branchDepth: 2,
		branchAngle: {min: 0.26, max: 0.6},
		branchLength: {min: 0.3, max: 0.45},
		branchBias: 1,
		branchBrightnessFalloff: 0.45,
		branchWidthFalloff: 0.5,
		width: {wide: 520, outer: 190, channel: 34, core: 6},
		tipWidth: 0.34,
		alpha: {wide: 0.36, outer: 0.06, channel: 0.68, core: 1},
		blur: {wide: 260, outer: 130, channel: 48, core: 0},
		bloom: {alpha: 0.22, blur: 70, width: 12},
		peakBrightness: 1.35,
		stagger: {min: 0, max: 0},
	},
	schedule: {
		events: 2,
		flashesPerEvent: {min: 3, max: 4},
		flashDuration: {min: 2, max: 3},
		flashGap: {min: 1, max: 4},
		eventPause: {min: 80, max: 110},
		flashIntensity: {min: 0.5, max: 1},
		headDark: 25,
		tailDark: 34,
	},
	ambient: {
		glowRadius: 880,
		glowAlpha: 0.24,
		glowDecayFrames: 25,
		glowSamples: 26,
		hazeBands: 5,
		hazeAlpha: 0.16,
		hazeLift: 1.2,
		hazeDrift: 0.04,
		hazeHeight: 0.34,
		backgroundTopMix: 0.1,
		backgroundBottomMix: 0,
	},
	frameFlash: {
		color: '#2A2A2E',
		holdFrames: 3,
		decayFrames: 6,
		threshold: 0.5,
	},
	finish: {vignette: 0.2, grainAlpha: 0.04, grainTile: 512, grainCell: 2},
	};
