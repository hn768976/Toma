import React, {useLayoutEffect, useMemo} from 'react';
import {rgba} from '../lib/color';
import {CANVAS_H, CANVAS_W} from '../lib/space';
import {LOOP, useLoopFrame} from '../lib/timing';
import type {BackgroundMode, Palette} from '../variants';

type Props = {
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  palette: Palette;
  mode: BackgroundMode;
  seed: string;
};



const DOT_SPACING = 168;
const DOT_RADIUS = 3.5;

/**
 * The calm background: a sparse regular dot grid drifting by exactly one cell
 * per loop, which is what makes the drift wrap without a seam.
 */
const drawDots = (
  ctx: CanvasRenderingContext2D,
  color: string,
  frame: number,
) => {
  const t = frame / LOOP;
  const ox = (t * DOT_SPACING) % DOT_SPACING;
  const oy = (t * DOT_SPACING * 0.5) % DOT_SPACING;
  ctx.save();
  ctx.fillStyle = rgba(color, 0.18);
  ctx.beginPath();
  for (let y = oy - DOT_SPACING; y < CANVAS_H + DOT_SPACING; y += DOT_SPACING) {
    for (let x = ox - DOT_SPACING; x < CANVAS_W + DOT_SPACING; x += DOT_SPACING) {
      ctx.moveTo(x + DOT_RADIUS, y);
      ctx.arc(x, y, DOT_RADIUS, 0, Math.PI * 2);
    }
  }
  ctx.fill();
  ctx.restore();
};

/** Whatever the chosen background mode needs to have prepared once. */
type BackgroundData =
  | {kind: 'dots'}
  ;

/**
 * Takes the whole prop bag rather than the individual pieces so that pruning a
 * mode out never leaves an unused parameter behind.
 */
const buildBackground = (props: Props): BackgroundData => {
  if (props.mode === 'dots') return {kind: 'dots'};
  throw new Error(`unknown background mode: ${String(props.mode)}`);
};

export const BackgroundLayer: React.FC<Props> = (props) => {
  const {canvasRef, palette} = props;
  const frame = useLoopFrame();
  // Keyed on the fields rather than on `props` itself: the prop object is a
  // fresh identity every frame, and rebuilding 30 text tiles per frame is not.
  const data = useMemo(
    () => buildBackground(props),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [props.mode, props.seed, props.palette],
  );

  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
    ctx.fillStyle = palette.bgDeep;
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    // Two soft glows: upper-left and centre. Both breathe over the full loop.
    const pulse = 1 + 0.05 * Math.sin((2 * Math.PI * frame) / LOOP);
    const glows: [number, number, number, number][] = [
      [CANVAS_W * 0.16, CANVAS_H * 0.2, CANVAS_W * 0.46 * pulse, 0.55],
      [CANVAS_W * 0.5, CANVAS_H * 0.56, CANVAS_W * 0.4 * (2 - pulse), 0.4],
    ];
    ctx.globalCompositeOperation = 'lighter';
    for (const [gx, gy, gr, ga] of glows) {
      const g = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr);
      g.addColorStop(0, rgba(palette.bgGlow, ga));
      g.addColorStop(0.5, rgba(palette.bgGlow, ga * 0.28));
      g.addColorStop(1, rgba(palette.bgGlow, 0));
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    }
    ctx.globalCompositeOperation = 'source-over';

    if (data.kind === 'dots') drawDots(ctx, palette.secondary, frame);
  }, [canvasRef, palette, data, frame]);

  return null;
};
