import type {Silhouette, StrokeSpec} from './lib/mask';

export type Palette = {
  bgDeep: string;
  bgGlow: string;
  primary: string;
  white: string;
  secondary: string;
  accent: string;
};

export type BackgroundMode = 'dots';
export type SubjectMode = 'sphere';

export type VariantSpec = {
  palette: Palette;
  /** Authored in the 1920x1080 design space (see lib/space.ts). */
  silhouette: Silhouette;
  /** Interior lines that add particle density without widening the mask. */
  creases: StrokeSpec[];
  background: BackgroundMode;
  subject: SubjectMode;
};

export type VariantName = 'hands';

/**
 * The single source of truth for every colour and every shape in the piece.
 * Nothing outside this file may contain a hex literal or a path string.
 */
export const VARIANTS: Record<VariantName, VariantSpec> = {
  hands: {
    palette: {
      bgDeep: '#02120A',
      bgGlow: '#0C3D1E',
      primary: '#3FE87F',
      white: '#E8FFEF',
      secondary: '#2E9F6B',
      accent: '#C4FFD8',
    },
    // The subject is the sphere itself: a circle of radius 380 about the frame
    // centre, 70% of frame height. Running it through the same mask pipeline as
    // the other two variants is what gives it its limb density and its wrapping
    // grid — and for a sphere the grid is not a metaphor, the compressed
    // vertical bands are the latitude rings the orbiting particles ride along.
    silhouette: {
      fill: [
        'M 960 160 C 1170 160 1340 330 1340 540',
        'C 1340 750 1170 920 960 920 C 750 920 580 750 580 540',
        'C 580 330 750 160 960 160 Z',
      ].join(' '),
      strokes: [],
    },
    // A shell has no creases.
    creases: [],
    background: 'dots',
    subject: 'sphere',
  },
};
