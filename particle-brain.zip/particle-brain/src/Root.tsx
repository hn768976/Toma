import React from "react";
import { Composition } from "remotion";
import {
  ParticleBrain,
  particleBrainSchema,
  particleBrainDefaultProps,
} from "./particle-brain/ParticleBrain";
import {
  DURATION_IN_FRAMES,
  FPS,
  WIDTH,
  HEIGHT,
} from "./particle-brain/config";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="ParticleBrain"
        component={ParticleBrain}
        durationInFrames={DURATION_IN_FRAMES}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        schema={particleBrainSchema}
        defaultProps={particleBrainDefaultProps}
      />
      {/* The same composition, one frame longer. Rendering frame 600 of this
          and frame 0 of either and comparing them is how the seamless loop is
          verified; they are pixel-identical. Delete freely — nothing else
          references it. */}
      <Composition
        id="ParticleBrainLoopCheck"
        component={ParticleBrain}
        durationInFrames={DURATION_IN_FRAMES + 1}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        schema={particleBrainSchema}
        defaultProps={particleBrainDefaultProps}
      />
    </>
  );
};
