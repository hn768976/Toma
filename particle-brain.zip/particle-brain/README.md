# Particle Brain

A brain rendered as a field of quantised particles, with flow ribbons, a
scattered interface-glyph field and a particle-sampled "AI" title.

| | |
|---|---|
| **Composition id** | `ParticleBrain` |
| **Resolution** | **4K — 3840 × 2160** |
| **Duration** | 600 frames |
| **Frame rate** | 30 fps |
| **Length** | 20.0 seconds |
| **Loops** | Yes — seamlessly. Frame 600 is pixel-identical to frame 0. |
| **Audio** | None |

## Render at 4K

```bash
npm install
npx remotion render ParticleBrain out/particle-brain.mp4 \
  --codec=h264 --crf=12 --concurrency=8
```

`--concurrency` must not exceed your CPU core count; lower it if Remotion
refuses to start.

A 1080p preview (half scale, faster, smaller):

```bash
npx remotion render ParticleBrain out/particle-brain-preview.mp4 \
  --codec=h264 --crf=18 --scale=0.5 --concurrency=8
```

Interactive editing:

```bash
npm run dev      # opens Remotion Studio
```

## Colour variants

The composition takes a single `variant` prop. Every colour in the piece
lives in the exported `THEME` object in `src/particle-brain/theme.ts` —
there is no hex literal anywhere else in the project.

| variant | |
|---|---|
| `teal` | default — near-black teal ground, teal/white particles |
| `ice` | cold blue |
| `ember` | warm amber |

```bash
npx remotion render ParticleBrain out/brain-ice.mp4 \
  --props='{"variant":"ice"}' --codec=h264 --crf=12
```

## How it is built

The brain is **not drawn**. Its silhouette — an ovoid cerebrum split by a
longitudinal fissure into a near hemisphere and a far one seen in
three-quarter view, a cerebellum tucked beneath the posterior, and a
descending stem — is rasterised once into an offscreen canvas, and the
particles are rejection-sampled against those pixels. The gyri are
likewise never drawn: they are generated as irregular wandering guide
curves and used only to weight particle density, alongside the distance to
the outer edge. That dual weighting is what makes the folds legible.

The same technique makes the title: the letterforms are rasterised and
sampled, so the "AI" is visibly the same material as the subject.

Everything is built **once**, in `useMemo`, from stable string seeds.
Every frame is a pure function of `useCurrentFrame()` — no `Date.now()`,
no `requestAnimationFrame`, no CSS animation, no state. Renders are
therefore deterministic and reproducible.

Every periodic quantity (twinkle, drift orbit, churn, ribbon highlight
travel, glyph flicker, camera drift, grain seed) has a period that divides
600 exactly, which is what closes the loop.

### Layout

```
src/
  lib/                     reusable, subject-agnostic, palette-agnostic
    rng.ts                 seeded randomness
    loopMath.ts            periodic cycles that close exactly
    bezierPath.ts          Catmull-Rom paths + arc-length traversal
    taperedStroke.ts       variable-width strokes
    maskSampler.ts         draw a shape -> sample particles from its pixels
    particleField.ts       twinkle / orbit / churn / pulse, and the draw
    DrawCanvas.tsx         a canvas that redraws once per React render
    FlowRibbons.tsx        sweeping curves with travelling highlights
    UIGlyphField.tsx       scattered HUD marks
    finishPasses.tsx       BloomPass, VignettePass, GrainPass
  particle-brain/
    ParticleBrain.tsx      the composition; layer order lives here
    config.ts              every dial: counts, sizes, periods, pulses
    theme.ts               every colour
    brainShape.ts          the silhouette, fissures and gyral guide curves
    brainParticles.ts      sampling the brain; the signal pulses
    titleParticles.ts      sampling the "AI" letterforms
    fonts.ts               font loading, gated with delayRender()
    components/            BackgroundWash, BrainParticles, TitleText
```

### Verifying the loop

`ParticleBrainLoopCheck` is the same composition one frame longer. Render
frame 0 and frame 600 and compare them:

```bash
npx remotion still ParticleBrainLoopCheck out/f000.png --frame=0
npx remotion still ParticleBrainLoopCheck out/f600.png --frame=600
```

They are identical to the byte. Delete that composition from
`src/Root.tsx` if you do not want it in the list.

## Font

The title's letterforms are sampled from **Poppins SemiBold**, vendored at
`public/fonts/Poppins-SemiBold-latin.woff2` and registered through the
FontFace API behind `delayRender()`/`continueRender()`.

It is deliberately not fetched from a CDN at render time: the letterforms
are geometry here, not styling, so a render that fell back to a system
sans — or picked up a different release of the webfont — would produce a
different particle set. Shipping the exact face keeps the render identical
on every machine, and keeps the project renderable offline.

Poppins is licensed under the SIL Open Font License 1.1.

## Notes

- No real product iconography, no watermark, no audio.
- The glyph icons are generic line drawings (magnifier, document, home,
  chevron, crosshair).
