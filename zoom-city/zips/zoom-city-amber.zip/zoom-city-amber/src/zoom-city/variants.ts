/**
 * Every colour and every per-version parameter of the piece lives here.
 * Nothing outside this file contains a hex literal — the three versions are
 * the same component driven by three entries of VARIANTS.
 */

export type VariantName = "amber";

/** How the ground below the horizon is treated. */
export type FloorMode = "wet" | "dry" | "none";

export type Palette = {
  /** Near-black base the whole frame sits on. */
  backgroundDeep: string;
  /** Broad glow washed around the vanishing point. */
  backgroundWash: string;
  /** The hue most streaks take. */
  streakDominant: string;
  /** A neighbouring hue, on a large minority. */
  streakSecondary: string;
  /** The cool (or, in mono, the dim) accent, scattered. */
  streakAccent: string;
  /** The brightest minority — roughly 15% of the field. */
  streakWhite: string;
  /** The core of the flare at the vanishing point. */
  coreWhite: string;
  /** Tint mixed into the floor reflection. Unused when floor mode is "none". */
  floorTint: string;
  /** The band of light sitting on the horizon line. */
  horizonGlow: string;
};

export type Variant = {
  name: VariantName;
  palette: Palette;
  /** Colour slot weights; they are normalised, so they need not sum to 1. */
  colourWeights: {
    dominant: number;
    secondary: number;
    accent: number;
    white: number;
  };
  vanishingPoint: {
    /** Fraction of frame width. */
    x: number;
    /** Fraction of frame height — also the horizon line when there is a floor. */
    y: number;
  };
  streaks: {
    /** How many streaks live in the field at once. */
    count: number;
    /** Multiplier on every streak's width. */
    widthScale: number;
    /** Multiplier on every streak's alpha. */
    brightnessScale: number;
    /** Share that stay near the vanishing point — distant lights, not yet blurred. */
    shortFraction: number;
    /** Share that span most of the frame and carry the eye. */
    heroFraction: number;
    /**
     * How lumpy the angular distribution is. 0 is a perfectly even sunburst;
     * high values give dense fans separated by sparse sectors.
     */
    lumpiness: number;
    /**
     * How strongly angles are pulled away from straight down. Where a floor
     * clips the field at the horizon, streaks aimed downward would be thrown
     * away, so the versions with a floor spend them above it instead.
     */
    upwardBias: number;
  };
  floor: {
    mode: FloorMode;
    /** Opacity of the mirrored field below the horizon. */
    opacity: number;
    /** Vertical stretch applied to the reflection. 1 is a plain mirror. */
    smear: number;
    /** Blur radius of the reflection, in frame pixels. */
    blur: number;
    /** Multiplier on the brightness of the band sitting at the horizon. */
    horizonBand: number;
  };
  core: {
    /** Overall size multiplier of the flare. */
    scale: number;
    /** The wide flat horizontal streak through the core. */
    anamorphic: boolean;
  };
  bursts: {
    gapMin: number;
    gapMax: number;
    streakCountMin: number;
    streakCountMax: number;
    durationMin: number;
    durationMax: number;
  };
};

/** Used when a composition is rendered without a valid variant prop. */
export const DEFAULT_VARIANT: VariantName = "amber";

export const VARIANTS: Record<VariantName, Variant> = {
  /* ── v2: off-centre, sparser and heavier, dry floor ────────────────── */
  amber: {
    name: "amber",
    palette: {
      backgroundDeep: "#140A02",
      backgroundWash: "#4A2408",
      streakDominant: "#F5A03F",
      streakSecondary: "#E8763F",
      streakAccent: "#3FC4B8",
      streakWhite: "#FFF4E0",
      coreWhite: "#FFFFFF",
      floorTint: "#7A4A14",
      horizonGlow: "#FFD48F",
    },
    colourWeights: { dominant: 0.52, secondary: 0.18, accent: 0.15, white: 0.15 },
    vanishingPoint: { x: 0.34, y: 0.58 },
    streaks: {
      count: 500,
      widthScale: 1.75,
      brightnessScale: 1.25,
      shortFraction: 0.18,
      heroFraction: 0.08,
      lumpiness: 1.05,
      upwardBias: 0.85,
    },
    floor: { mode: "dry", opacity: 0.15, smear: 1, blur: 72, horizonBand: 1.5 },
    core: { scale: 1, anamorphic: true },
    bursts: {
      gapMin: 70,
      gapMax: 130,
      streakCountMin: 30,
      streakCountMax: 45,
      durationMin: 12,
      durationMax: 18,
    },
  },
};
