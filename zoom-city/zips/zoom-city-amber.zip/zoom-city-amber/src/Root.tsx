import React from "react";
import { Composition } from "remotion";
import { ZoomCity } from "./zoom-city/ZoomCity";
import { FPS, HEIGHT, LOOP_FRAMES, WIDTH } from "./zoom-city/geometry";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="ZoomCityAmber"
        component={ZoomCity}
        durationInFrames={LOOP_FRAMES}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        defaultProps={{ variant: "amber" as const }}
      />
    </>
  );
};
