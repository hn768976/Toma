# Zoom City — amber

A 4K, seamlessly looping "zoom-blur city" animation built in Remotion. The
frame is a radial motion blur: every element is drawn as a long tapered streak
running outward from a vanishing point, growing longer, wider and faster as it
goes, then dissolving near the frame edge and recycling to a new angle.

Vanishing point off-centre at 34% across and higher on the horizon, ~500 wider and brighter streaks, and a dry floor: the reflection is only a soft glow beneath a brighter horizon.

| | |
| --- | --- |
| Composition id | `ZoomCityAmber` |
| Resolution | 3840 × 2160 (4K UHD) |
| Duration | 300 frames |
| Frame rate | 30 fps (10.0 seconds) |
| Loops | Yes — frame 300 is pixel-identical to frame 0 |
| Audio | None |

## Run it

```bash
npm install
npm run dev          # Remotion Studio
```

## Render 4K

```bash
npx remotion render ZoomCityAmber out/zoomcity-amber.mp4 --codec=h264 --crf=12 --concurrency=8
```

A 1080p preview, which is much faster, is the same command with `--scale=0.5`.

`--concurrency` must not exceed the number of CPU cores on the machine, so
lower it on a smaller box.

## How it is put together

Every frame is a pure function of `useCurrentFrame()` — no `Date.now()`, no
`requestAnimationFrame`, no CSS animation and no component state, so rendering
is deterministic and frames can be produced out of order across workers. All
randomness comes from Remotion's `random()` with stable string seeds.

- `src/zoom-city/variants.ts` — the one place a colour or a per-version
  parameter is defined. No hex literal exists anywhere else in the project.
- `src/zoom-city/streaks.ts` — the streak model: seeded angle, inner radius,
  length and width; the exponential radius that makes speed proportional to
  radius; and the tapered, gradient-filled quads that make a streak read as
  motion blur rather than as a line.
- `src/zoom-city/angular.ts` — the uneven angular distribution, built as a
  seeded density and inverted through its CDF, so the field has dense fans and
  sparse sectors instead of an even sunburst.
- `src/zoom-city/bursts.ts` — the burst schedule. Gaps are normalised to tile
  the loop exactly and every envelope is evaluated on `frame % 300`, so the
  schedule closes.
- `src/zoom-city/components/` — the stacked canvas layers: `BackgroundWash`,
  `StreakField`, `FloorReflection`, `BloomPass`, `BurstLayer`, `CoreFlare` and
  `FilmFinish`.

The streak field is drawn once per frame into its own canvas, and the floor
reflection and the bloom pass both read that canvas back with `drawImage`
rather than redrawing the field. That is the main optimisation here.

### Verifying the loop

Temporarily raise `durationInFrames` to `LOOP_FRAMES + 1` in `src/Root.tsx`,
render stills at frame 0 and frame 300, and compare them — they hash
identically.
