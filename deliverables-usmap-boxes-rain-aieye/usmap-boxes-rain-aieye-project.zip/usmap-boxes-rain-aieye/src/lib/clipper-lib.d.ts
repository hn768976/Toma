declare module "clipper-lib";
