# Network Mesh — Plexus Green (v2)

A finer-grained mesh — more nodes, shorter edges — in a near-black terminal green, with short uppercase words dominating the label field.

| | |
|---|---|
| Composition id | `MeshPlexusGreen` |
| Resolution | **4K — 3840 x 2160** |
| Duration | 450 frames |
| Frame rate | 30 fps |
| Length | 15.0 s |
| Loop | Seamless — frame 450 is pixel-identical to frame 0 |

Every drift path, brightness pulse, flash, label reroll and light cycle has a
period that divides 450 frames, so the clip loops with no cut.

## Render at 4K

```
npm install
npx remotion render MeshPlexusGreen out/mesh-plexus-green.mp4 --codec=h264 --crf=12 --concurrency=8
```

Lower `--concurrency` if the machine has fewer cores than that; Remotion
rejects a value above the core count.

## 1080p preview

```
npx remotion render MeshPlexusGreen out/mesh-plexus-green-preview.mp4 --codec=h264 --crf=18 --scale=0.5 --concurrency=8
```

## Studio

```
npm run dev
```

## What is in here

All four versions share one mesh implementation. Density, facet mode, label
set and light mode are config values in `src/variants.ts`, which is also the
only file in the project containing a colour literal.

```
src/
  Root.tsx                    all four compositions, plus MeshLoopCheck
                              (451 frames) for verifying the loop
  NetworkMesh.tsx             the composition: one mesh, four variants
  variants.ts                 palettes + per-version configuration
  constants.ts                4K geometry and loop length
  components/
    BackgroundWash.tsx        base fill and drifting soft washes
    LabelField.tsx            edge-weighted drifting text field
    LightBloom.tsx            rising atmospheric glow
    DustMotes.tsx             upward-drifting motes
  vendor/                     vendored from the shared remotion-lib
    core/                     seeded random, colour, canvas helpers
    mesh/node-field.ts        seeded node field, drift, spatial-grid edges
    mesh/NodeMesh.tsx         nodes + edges, three-buffer depth of field, bloom
    mesh/FacetLayer.tsx       low-alpha triangulated facets
    light/AnamorphicFlare.tsx travelling streak with chromatic fringing
    atmosphere/BokehLayer.tsx defocused discs, behind and in front of the mesh
    atmosphere/PostFx.tsx     vignette and film grain
```

## Verifying the loop

`MeshLoopCheck` is the same component registered for 451 frames. Frame 450
renders identically to frame 0:

```
npx remotion still MeshLoopCheck out/f0.png   --frame=0   --props='{"variant":"plexusGreen"}'
npx remotion still MeshLoopCheck out/f450.png --frame=450 --props='{"variant":"plexusGreen"}'
```

All motion derives from `useCurrentFrame()` and all randomness from
Remotion's `random()` with fixed string seeds, so renders are deterministic
and frames can be produced in any order across workers.
