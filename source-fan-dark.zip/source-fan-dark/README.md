# Source Fan — Dark

A 4K motion graphic built with [Remotion](https://remotion.dev): five data
sources on the right edge throw a fan of very fine strands leftward across the
frame. The fans open at the nodes and then narrow, gathering the five streams
into one collected flow that dissolves into a dense field of flickering data
dots on the left.

It is the reversed counterpart of the blue variant — where that one broadcasts,
this one collects. Everything is drawn to 2D `<canvas>` layers. There is no 3D
and no Three.js.

## Composition

| | |
| --- | --- |
| Composition id | `SourceFanDark` |
| Resolution | 3840 × 2160 (4K UHD) |
| Duration | 600 frames |
| Frame rate | 30 fps (20.0 s) |
| Loops | Yes — frame 600 is pixel-identical to frame 0 |

Every pulse, undulation and flicker period is a divisor of 600 and the backdrop
character bands tile exactly over the 600 frames, so the clip is seamless.

## Render at 4K

```
npm install
npx remotion render SourceFanDark out/sourcefan-dark.mp4 --codec=h264 --crf=12 --concurrency=8
```

`--concurrency` must not exceed the number of cores on the machine; lower it if
Remotion rejects the value.

A 1080p preview is the same command with `--scale=0.5`:

```
npx remotion render SourceFanDark out/sourcefan-dark-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

Open the studio with `npm run dev`.

## How it is put together

- `src/source-fan/variants.ts` — the one `VARIANTS` object. Palette, source
  count and labels, the signed fan direction and the dot-field settings all live
  here; no hex literal or label string appears anywhere else in the project.
  `fanDirection: -1` is what reverses this variant: geometry is authored in a
  flow space that the signed direction maps onto screen x, so the nodes, the
  strands, the dot field and the backdrop drift all invert together. The
  converging shape is a separate, deliberate change to the spread profile.
- `src/source-fan/CodeBackdrop.tsx` — deep base, broad radial wash, and faint
  horizontal bands of illegible monospace characters drifting leftward with the
  strands, tiling exactly.
- `src/source-fan/StrandFan.tsx` — the strand fan. Geometry is generated once
  from seeded `random()` (`geometry.ts`) and only the undulation offset is
  applied per frame. Each strand is drawn twice: a wide low-alpha glow pass with
  `shadowBlur`, then a sharp 1–2.2px core whose colour desaturates from the node
  hue toward white and whose opacity falls to zero over its last third.
- `src/source-fan/DotField.tsx` — loose, irregularly spaced rows of small
  squares in the node hues plus white, flickering on seeded schedules.
- `src/source-fan/SourceNode.tsx` — one bright point with a soft halo and a
  small-caps label, pulsing ±12% on its own period.
- `src/source-fan/Finish.tsx` — vignette and fine grain.

All motion comes from `useCurrentFrame()`. There is no `Date.now()`, no
`requestAnimationFrame`, no CSS animation and no component state driving motion,
so every frame is a pure function of the frame number and renders are
deterministic. All randomness goes through Remotion's `random()` with stable
string seeds.

## The other variant

The same components render the original variant, registered in `src/Root.tsx`
as `SourceFanBlue` — three sources on the left edge, strands sweeping and
opening out to the right. See `source-fan-blue.zip`.
