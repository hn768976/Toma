/**
 * The single source of truth for everything that differs between the three
 * versions of the piece. Nothing outside this file may contain a colour
 * literal, a diagram-set name, a structure mode or a roll direction.
 */

export type VariantName = "green";

/** "corridor" = tilted grid planes. "wall" = one flat scrolling text surface. */
export type StructureMode = "corridor" | "wall";

/** "roll" = the composite rotates on a sine. "static" = the camera holds. */
export type CameraMode = "roll" | "static";

/** What the type layer is made of. */
export type TextLayerMode = "blocks" | "equations" | "wall";

/** Which vocabulary the small technical drawings are pulled from. */
export type DiagramSet = "molecules" | "circuits";

export type Palette = {
  /** Deepest background tone. */
  bgDeep: string;
  /** The lighter wash the background gradient reaches toward. */
  bgWash: string;
  /** Brightest structural colour: grid lines, or the text wall body. */
  structureMain: string;
  /** The same structure, far away. */
  structureDim: string;
  /** Body colour of code / equation / wall type. */
  textMain: string;
  /** Highlight colour for the occasional bright line. */
  textPale: string;
  /** Stroke colour of the technical diagrams. */
  diagram: string;
  /** The white-hot node dots. */
  nodeWhite: string;
  /** The tinted node dots. */
  nodeAccent: string;
  /** Very sparse contrast colour — a few tiny marks only. */
  accent: string;
};

export type Bucket = {
  key: string;
  /** Blur applied once to the whole buffer, in 4K pixels. */
  blur: number;
  /** Backing-store scale of the buffer. Heavily blurred buffers are half size. */
  res: number;
  /** Composited with "lighter" instead of "source-over". */
  additive?: boolean;
};

export type PlaneSpec = {
  key: string;
  /** Rotation of the plane's local axes, radians. */
  rot: number;
  /** Horizontal shear of the plane's local axes. */
  shear: number;
  /** Relative brightness of this plane's grid, so surfaces separate. */
  tone: number;
};

export type VariantConfig = {
  palette: Palette;
  structure: StructureMode;
  diagrams: DiagramSet;
  textLayer: TextLayerMode;
  camera: {
    mode: CameraMode;
    /** Signed. +1 rolls clockwise and drifts up-left, -1 mirrors both. */
    rollDirection: number;
    /** Amplitude of the roll in degrees. */
    rollDegrees: number;
    /** Amplitude of the ambient wander in pixels (used when mode is static). */
    wanderPx: number;
  };
  /** Negates every plane rotation and shear, mirroring the corridor. */
  planeMirror: number;
  /** Base plane angles, before planeMirror is applied. */
  planes: PlaneSpec[];
  /** Depth-of-field buffers, composited in array order. */
  buckets: Bucket[];
  /** Extra buffer that collects the bright elements for the bloom pass. */
  glow: Bucket;
  /** Multiplier on the drawn size of every diagram glyph. */
  diagramScale: number;
  /** How hard elements fade with depth. 1 is full corridor falloff. */
  depthDimming: number;
  /**
   * Population per plane on its wrap-around tile, before the tiling
   * replication that fills the plane. In "wall" mode the single front plane
   * is one tile wide, so these are the visible counts directly.
   */
  perPlane: {
    dots: number;
    glyphs: number;
    codeBlocks: number;
    equations: number;
  };
};

/** Two-way depth-of-field: the wall is flat and sharp, everything else floats. */
const WALL_BUCKETS: Bucket[] = [
  { key: "flat", blur: 0, res: 1 },
  { key: "near", blur: 20, res: 0.5 },
];

const GLOW_BUCKET: Bucket = { key: "glow", blur: 26, res: 0.5, additive: true };

/** This project ships one version. Its data is inlined here. */
export const VARIANT: VariantConfig = {
  palette: {
    bgDeep: "#010A04",
    bgWash: "#04200E",
    structureMain: "#2EB84F",
    structureDim: "#0F4A1E",
    textMain: "#2EB84F",
    textPale: "#6FFF8F",
    diagram: "#C4FFD4",
    nodeWhite: "#F0FFF4",
    nodeAccent: "#4FE87A",
    accent: "#E85FC4",
  },
  structure: "wall",
  diagrams: "molecules",
  textLayer: "wall",
  camera: {
    mode: "static",
    rollDirection: 0,
    rollDegrees: 0,
    wanderPx: 8,
  },
  planeMirror: 1,
  planes: [],
  buckets: WALL_BUCKETS,
  glow: GLOW_BUCKET,
  diagramScale: 2,
  depthDimming: 0.22,
  perPlane: { dots: 174, glyphs: 15, codeBlocks: 0, equations: 0 },
};

export const getVariant = (_name?: VariantName): VariantConfig => VARIANT;
