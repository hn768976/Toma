/**
 * The single source of truth for everything that differs between the three
 * versions of the piece. Nothing outside this file may contain a colour
 * literal, a diagram-set name, a structure mode or a roll direction.
 */

export type VariantName = "amber";

/** "corridor" = tilted grid planes. "wall" = one flat scrolling text surface. */
export type StructureMode = "corridor" | "wall";

/** "roll" = the composite rotates on a sine. "static" = the camera holds. */
export type CameraMode = "roll" | "static";

/** What the type layer is made of. */
export type TextLayerMode = "blocks" | "equations" | "wall";

/** Which vocabulary the small technical drawings are pulled from. */
export type DiagramSet = "molecules" | "circuits";

export type Palette = {
  /** Deepest background tone. */
  bgDeep: string;
  /** The lighter wash the background gradient reaches toward. */
  bgWash: string;
  /** Brightest structural colour: grid lines, or the text wall body. */
  structureMain: string;
  /** The same structure, far away. */
  structureDim: string;
  /** Body colour of code / equation / wall type. */
  textMain: string;
  /** Highlight colour for the occasional bright line. */
  textPale: string;
  /** Stroke colour of the technical diagrams. */
  diagram: string;
  /** The white-hot node dots. */
  nodeWhite: string;
  /** The tinted node dots. */
  nodeAccent: string;
  /** Very sparse contrast colour — a few tiny marks only. */
  accent: string;
};

export type Bucket = {
  key: string;
  /** Blur applied once to the whole buffer, in 4K pixels. */
  blur: number;
  /** Backing-store scale of the buffer. Heavily blurred buffers are half size. */
  res: number;
  /** Composited with "lighter" instead of "source-over". */
  additive?: boolean;
};

export type PlaneSpec = {
  key: string;
  /** Rotation of the plane's local axes, radians. */
  rot: number;
  /** Horizontal shear of the plane's local axes. */
  shear: number;
  /** Relative brightness of this plane's grid, so surfaces separate. */
  tone: number;
};

export type VariantConfig = {
  palette: Palette;
  structure: StructureMode;
  diagrams: DiagramSet;
  textLayer: TextLayerMode;
  camera: {
    mode: CameraMode;
    /** Signed. +1 rolls clockwise and drifts up-left, -1 mirrors both. */
    rollDirection: number;
    /** Amplitude of the roll in degrees. */
    rollDegrees: number;
    /** Amplitude of the ambient wander in pixels (used when mode is static). */
    wanderPx: number;
  };
  /** Negates every plane rotation and shear, mirroring the corridor. */
  planeMirror: number;
  /** Base plane angles, before planeMirror is applied. */
  planes: PlaneSpec[];
  /** Depth-of-field buffers, composited in array order. */
  buckets: Bucket[];
  /** Extra buffer that collects the bright elements for the bloom pass. */
  glow: Bucket;
  /** Multiplier on the drawn size of every diagram glyph. */
  diagramScale: number;
  /** How hard elements fade with depth. 1 is full corridor falloff. */
  depthDimming: number;
  /**
   * Population per plane on its wrap-around tile, before the tiling
   * replication that fills the plane. In "wall" mode the single front plane
   * is one tile wide, so these are the visible counts directly.
   */
  perPlane: {
    dots: number;
    glyphs: number;
    codeBlocks: number;
    equations: number;
  };
};

/** Plane angles for the corridor. v2 receives these with planeMirror -1. */
const CORRIDOR_PLANES: PlaneSpec[] = [
  { key: "ceiling", rot: -0.15, shear: 0.5, tone: 0.8 },
  { key: "right", rot: 0.4, shear: -0.64, tone: 1.0 },
  { key: "floor", rot: 0.13, shear: -0.46, tone: 1.08 },
  { key: "left", rot: -0.37, shear: 0.62, tone: 0.86 },
];

/** Three-way depth-of-field: far and near blur hard, the middle band is sharp. */
const CORRIDOR_BUCKETS: Bucket[] = [
  { key: "far", blur: 22, res: 0.5 },
  { key: "mid", blur: 2, res: 1 },
  { key: "near", blur: 26, res: 0.5 },
];

const GLOW_BUCKET: Bucket = { key: "glow", blur: 26, res: 0.5, additive: true };

/** This project ships one version. Its data is inlined here. */
export const VARIANT: VariantConfig = {
  palette: {
    bgDeep: "#1A0F02",
    bgWash: "#3D2408",
    structureMain: "#E8942E",
    structureDim: "#7A4A14",
    textMain: "#F5B84F",
    textPale: "#FFE8C0",
    diagram: "#FFF4E0",
    nodeWhite: "#FFFFFF",
    nodeAccent: "#FFC44F",
    accent: "#3FC4E8",
  },
  structure: "corridor",
  diagrams: "circuits",
  textLayer: "equations",
  camera: {
    mode: "roll",
    rollDirection: -1,
    rollDegrees: 4,
    wanderPx: 0,
  },
  planeMirror: -1,
  planes: CORRIDOR_PLANES,
  buckets: CORRIDOR_BUCKETS,
  glow: GLOW_BUCKET,
  diagramScale: 1,
  depthDimming: 1,
  perPlane: { dots: 78, glyphs: 14, codeBlocks: 8, equations: 9 },
};

export const getVariant = (_name?: VariantName): VariantConfig => VARIANT;
