/**
 * Note: when using the Node.JS APIs this config file does not apply.
 * All configuration options: https://remotion.dev/docs/config
 */
import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
Config.setChromiumOpenGlRenderer("angle");
// The piece has no audio, so no silent track is written.
Config.setMuted(true);
Config.setEnforceAudioTrack(false);
