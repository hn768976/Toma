# grid-corridor-teal

A teal molecular corridor: four tilted grid planes meeting at soft seams, scattered with invented code blocks and molecular diagrams. The camera rolls clockwise and the contents drift up-left.

| | |
| --- | --- |
| Composition id | `GridCorridorTeal` |
| Resolution | 3840 x 2160 (4K UHD) |
| Duration | 360 frames at 30 fps — 12.0 seconds |
| Loop | Seamless. Frame 0 and frame 360 are pixel-identical. |

This is a 4K composition. Everything in it is a pure function of
`useCurrentFrame()`, and all randomness comes from Remotion's `random()`
with stable string seeds, so renders are deterministic and repeatable.

## Install

```
npm install
```

## Preview

```
npx remotion studio
```

## Render at 4K

```
npx remotion render GridCorridorTeal out/corridor-teal.mp4 --codec=h264 --crf=12 --concurrency=8
```

A faster 1080p check, if you want one first:

```
npx remotion render GridCorridorTeal out/corridor-teal-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

## Notes

- 2D canvas only. No 3D, no WebGL, no CSS animation, no `requestAnimationFrame`.
- The monospace face is loaded through `@remotion/google-fonts`, gated with
  `delayRender()` / `continueRender()`. A copy of the same face is vendored in
  `public/fonts/` so a render host with no access to the font CDN still gets
  Roboto Mono rather than a substitute.
- Depth of field is done with offscreen buffers blurred once each, never per
  element — at 4K, per-element blurring is not viable.
