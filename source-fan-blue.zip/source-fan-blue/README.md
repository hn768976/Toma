# Source Fan — Blue

A 4K motion graphic built with [Remotion](https://remotion.dev): three data
sources on the left edge throw a fan of very fine strands rightward across the
frame, the three fans interleave into one combined flow, and the strands fade
out into a scattered field of flickering data dots on the right.

Everything is drawn to 2D `<canvas>` layers. There is no 3D and no Three.js.

## Composition

| | |
| --- | --- |
| Composition id | `SourceFanBlue` |
| Resolution | 3840 × 2160 (4K UHD) |
| Duration | 600 frames |
| Frame rate | 30 fps (20.0 s) |
| Loops | Yes — frame 600 is pixel-identical to frame 0 |

Every pulse, undulation and flicker period is a divisor of 600 and the backdrop
character bands tile exactly over the 600 frames, so the clip is seamless.

## Render at 4K

```
npm install
npx remotion render SourceFanBlue out/sourcefan-blue.mp4 --codec=h264 --crf=12 --concurrency=8
```

`--concurrency` must not exceed the number of cores on the machine; lower it if
Remotion rejects the value.

A 1080p preview is the same command with `--scale=0.5`:

```
npx remotion render SourceFanBlue out/sourcefan-blue-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

Open the studio with `npm run dev`.

## How it is put together

- `src/source-fan/variants.ts` — the one `VARIANTS` object. Palette, source
  count and labels, the signed fan direction and the dot-field settings all live
  here; no hex literal or label string appears anywhere else in the project.
- `src/source-fan/CodeBackdrop.tsx` — deep base, broad radial wash, and faint
  bands of illegible monospace characters that drift and tile exactly.
- `src/source-fan/StrandFan.tsx` — the strand fan. Geometry is generated once
  from seeded `random()` (`geometry.ts`) and only the undulation offset is
  applied per frame. Each strand is drawn twice: a wide low-alpha glow pass with
  `shadowBlur`, then a sharp 1–2.5px core whose colour desaturates from the node
  hue toward white and whose opacity falls to zero over its last third.
- `src/source-fan/DotField.tsx` — loose, irregularly spaced rows of small
  squares in the node hues plus white, flickering on seeded schedules.
- `src/source-fan/SourceNode.tsx` — one bright point with a soft halo and a
  small-caps label, pulsing ±12% on its own period.
- `src/source-fan/Finish.tsx` — vignette and fine grain.

All motion comes from `useCurrentFrame()`. There is no `Date.now()`, no
`requestAnimationFrame`, no CSS animation and no component state driving motion,
so every frame is a pure function of the frame number and renders are
deterministic. All randomness goes through Remotion's `random()` with stable
string seeds.

## The other variant

The same components render a second, reversed variant, registered in
`src/Root.tsx` as `SourceFanDark` — five sources on the right edge, strands
sweeping and converging leftward. See `source-fan-dark.zip`.
