/**
 * variants.ts — THE single source of truth for every per-version difference.
 *
 * Rule enforced across this project: no colour hex literal exists anywhere
 * else in `src/`. Every colour, every camera-path selection, every building
 * render mode and every post-processing setting is read from `VARIANTS`.
 *
 * Adding a fourth version therefore means adding one entry here (plus a
 * `<Composition>` in Root.tsx) — never touching scene, camera or post code.
 */

export type VariantName = 'mint';

/** Named camera-path modes. Each maps to a function in `camera-paths.ts`. */
export type CameraPathMode = 'orbit' | 'descend' | 'levelOrbit';

/** Named building render modes. Each maps to a branch in `Buildings.tsx`. */
export type BuildingRenderMode = 'wireframe' | 'windows' | 'blueprint';

export type Palette = {
	/** Scene clear colour. Also the colour distant geometry fades into. */
	background: string;
	/** Base colour of the ground dot grid at mid distance. */
	groundDot: string;
	/** Ground dots nearest the camera. */
	groundBright: string;
	/** Wireframe edge colour of the buildings. */
	buildingLine: string;
	/** Edge colour of the very tallest towers (height ramp target). */
	buildingGlow: string;
	/** Lit-window points (only used when buildingMode === 'windows'). */
	windowLit: string;
	/** Dimension lines / ticks (only used when annotations.enabled). */
	annotation: string;
	/** Horizon glow band. */
	haze: string;
	/**
	 * Opaque body colour of each building. Buildings are filled with this so
	 * that near wireframes correctly occlude far ones (hidden-line removal).
	 * Keep it very close to `background` so the fill reads as "empty".
	 */
	buildingFill: string;
	/** Colour the vignette pushes the corners toward. */
	vignette: string;
};

export type BloomSettings = {
	intensity: number;
	luminanceThreshold: number;
	luminanceSmoothing: number;
	mipmapBlur: boolean;
	radius: number;
};

export type PostSettings = {
	/** `null` = no Bloom pass is mounted at all (not "bloom at intensity 0"). */
	bloom: BloomSettings | null;
	vignette: {
		/** 0 = off. Positive = mix corners toward `palette.vignette`. */
		strength: number;
		/** Radius (0..1, normalised) at which the vignette starts. */
		offset: number;
	};
};

export type VariantConfig = {
	palette: Palette;
	cameraPath: CameraPathMode;
	buildingMode: BuildingRenderMode;
	/** Screen-space line width in px (LineMaterial, worldUnits=false). */
	lineWidth: number;
	/** Ramp edge brightness with building height (buildingLine -> buildingGlow). */
	heightRamp: boolean;
	/** Opacity of the wireframe edges. */
	lineOpacity: number;
	windows: {
		enabled: boolean;
		/**
		 * When true, each window has a seeded activation frame in
		 * onFrom..onTo and the city lights up during the shot. When false
		 * every window is lit from frame 0 and the layer is pure surface
		 * detail. The progressive switch-on is the emerald version's
		 * signature, so only it sets this.
		 */
		progressive: boolean;
		/** Frame range across which windows switch on, inclusive. */
		onFrom: number;
		onTo: number;
		/** Frames a single window takes to fade up. */
		fadeFrames: number;
		/** Fraction of the candidate window grid that is actually lit. */
		density: number;
		/** Window point size in WORLD units (attenuated with distance). */
		size: number;
		/** Overall brightness multiplier for the window layer. */
		brightness: number;
		/** Pitch of the candidate window grid on each face, world units. */
		colSpacing: number;
		rowSpacing: number;
	};
	annotations: {
		enabled: boolean;
		/** Number of dimension-line annotations. */
		count: number;
		/** Number of small ground tick marks. */
		tickCount: number;
		lineWidth: number;
	};
	ground: {
		/** Brightness multiplier for the whole dot grid. */
		intensity: number;
		/** Multiplier on the dot size, which is expressed in WORLD units. */
		dotSize: number;
	};
	/**
	 * Linear scene fog toward `palette.haze`. Wireframe edges fade into the
	 * haze with distance; the building fills opt out so occlusion stays clean.
	 */
	fog: {near: number; far: number};
	post: PostSettings;
	/** Alpha of the 2D film-grain layer over the canvas. */
	grainOpacity: number;
};

/*
 * This project is the single-version "mint" package. The full build
 * keys this object by 'mint' | 'emerald' | 'blueprint'; adding a version back
 * means adding an entry here plus a <Composition> in Root.tsx, and nothing
 * else — no scene, camera or post-processing code changes.
 */
export const VARIANTS: Record<VariantName, VariantConfig> = {
	/* ─────────────────────────── v1 — mint ─────────────────────────── */
	mint: {
		palette: {
			background: '#030B14',
			groundDot: '#10405E',
			groundBright: '#2A87B0',
			buildingLine: '#4FE3FF',
			buildingGlow: '#BFF6FF',
			windowLit: '#CFEEFF',
			annotation: '#2A87B0',
			haze: '#0A3350',
			buildingFill: '#051523',
			vignette: '#030B14',
		},
		cameraPath: 'orbit',
		buildingMode: 'wireframe',
		lineWidth: 1.6,
		heightRamp: true,
		lineOpacity: 0.95,
		windows: {
			// Surface detail, not an event: every window is lit from frame 0.
			// A coarser grid than emerald's so the rows still read as windows
			// at orbit distance rather than dissolving into speckle.
			enabled: true,
			progressive: false,
			onFrom: 60,
			onTo: 380,
			fadeFrames: 8,
			// Nearly filled: a sparse random subset of a grid reads as noise
			// at orbit distance, not as windows. Keeping most of the grid is
			// what makes the rows and columns legible.
			density: 0.82,
			size: 0.55,
			brightness: 0.9,
			colSpacing: 2.4,
			rowSpacing: 3,
		},
		annotations: {enabled: false, count: 0, tickCount: 0, lineWidth: 1},
		ground: {intensity: 1.9, dotSize: 1},
		fog: {near: 210, far: 620},
		post: {
			bloom: {
				intensity: 1.55,
				luminanceThreshold: 0.24,
				luminanceSmoothing: 0.32,
				mipmapBlur: true,
				radius: 0.82,
			},
			vignette: {strength: 0.8, offset: 0.28},
		},
		grainOpacity: 0.04,
	},
};
