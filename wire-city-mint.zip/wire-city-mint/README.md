# Wire City — "mint"

Glowing aqua-cyan wireframes on deep navy, with lit window detail on every building. The camera orbits the city at tower height, covering about a third of a full orbit while drifting slowly inward, with a slight handheld wobble on top.

## The composition

| | |
|---|---|
| **Composition id** | `WireCityMint` |
| **Resolution** | **4K — 3840 × 2160** |
| **Duration** | 450 frames |
| **Frame rate** | 30 fps |
| **Length** | 15.0 s |
| **Camera path mode** | `orbit` |
| **Building render mode** | `wireframe` |
| **Post-processing** | Bloom, intensity 1.55, luminanceThreshold 0.24 |
| **Lit windows** | always lit from frame 0 — surface detail, not an event |

One-shot: the camera travels and does not reset, so the first and last frames
differ by design. There is no audio, no text and no logo.

## Install

```bash
npm install
```

### The extra 3D dependencies

Beyond `remotion` / `@remotion/cli` / `react`, this project needs:

```bash
npm i @remotion/three three @react-three/fiber
npm i @react-three/postprocessing postprocessing
```

| Package | Why |
|---|---|
| `@remotion/three` | `<ThreeCanvas>` — disables react-three-fiber's internal render loop so frames advance on Remotion's clock instead of wall-clock time |
| `three` | the renderer, plus `examples/jsm/lines/*` for `Line2` / `LineSegments2` / `LineMaterial` |
| `@react-three/fiber` | React reconciler for three.js |
| `@react-three/postprocessing`, `postprocessing` | `<EffectComposer>`, `<Bloom>`, and the base `Effect` class the custom vignette extends |

## Render at 4K

```bash
npx remotion render WireCityMint out/wire-city-mint.mp4 \
  --codec=h264 --crf=18 --concurrency=8
```

No `--scale` flag: the composition is natively 3840 × 2160.

For a fast 1080p check, halve it:

```bash
npx remotion render WireCityMint out/wire-city-mint-preview.mp4 \
  --codec=h264 --crf=18 --scale=0.5 --concurrency=8
```

> `--concurrency` cannot exceed your core count — Remotion errors rather than
> clamping. Lower it if you see *"Maximum for --concurrency is N"*.

Open the studio with `npx remotion studio`.

## Palette

Every colour in the project comes from the single exported `VARIANTS` object
in `src/wire-city/variants.ts`. No colour hex literal exists anywhere else in
`src/`.

| role | hex | |
|---|---|---|
| background | `#030B14` | near-black navy |
| ground dot | `#10405E` |  |
| ground bright | `#2A87B0` | nearer dots |
| building line | `#4FE3FF` | the wireframe edges |
| building glow | `#BFF6FF` | the brightest towers |
| window lit | `#CFEEFF` | always-lit window detail |
| haze | `#0A3350` | the horizon glow |

## Layout

```
src/
  index.ts                     registerRoot
  Root.tsx                     the <Composition>
  wire-city/
    variants.ts                THE config — palette, camera mode, render mode, post
    camera-paths.ts            every camera move, as pure functions of the frame
    city-layout.ts             seeded generation of the city + its edge buffers
    WireCity.tsx               the composition: <ThreeCanvas> + scene + grain
    CameraRig.tsx              creates, installs and drives the camera
    Buildings.tsx              merged wireframe (1 draw call) + occlusion fills
    Ground.tsx                 the two dot lattices
    Haze.tsx                   horizon glow
    Post.tsx                   EffectComposer: bloom + vignette
    vignette-effect.ts         custom postprocessing Effect
    CanvasWarmup.tsx           holds delayRender() until the composer can draw
    Grain.tsx                  the only 2D layer
    three-helpers.ts           colour + drawing-buffer helpers
```

`camera-paths.ts` ships with all three named path modes even though this
package uses only `orbit`. That is deliberate:
`generateCity()` clears a corridor along the sampled ground tracks of every
path so the camera is never inside a building, which means dropping the unused
paths would change how many buildings get culled and this project would render
a subtly different city.

## Determinism

Every animated value derives from `useCurrentFrame()`. There is no
`useFrame(delta)` and no `THREE.Clock` anywhere — both are wall-clock based
and would produce different output on every render. All randomness is seeded
through Remotion's `random()`.

To check:

```bash
npx remotion still WireCityMint out/a.png --frame=200 --scale=0.25
npx remotion still WireCityMint out/b.png --frame=200 --scale=0.25
sha256sum out/a.png out/b.png   # identical
```

## Notes

`CAMERA-NOTES.md` in this directory records the camera positions, the lens,
each path function, the bloom settings, the material choices, and the
Remotion-specific gotchas hit while building this — several of which present
as a completely black frame.

## No GPU?

```ts
// remotion.config.ts
Config.setChromiumOpenGlRenderer('swangle');   // ANGLE over SwiftShader
```

Chromium ≥ 141 additionally refuses the software WebGL fallback unless it is
launched with `--enable-unsafe-swiftshader`. Remotion does not add that flag
for `swangle`, so wrap the browser binary in a shell script that appends it
and pass `--browser-executable=/path/to/wrapper`. On a machine with a real
GPU, use `Config.setChromiumOpenGlRenderer('angle')` instead — it is roughly
an order of magnitude faster for this scene.
