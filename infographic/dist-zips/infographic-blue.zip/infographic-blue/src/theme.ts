/**
 * The single source of truth for every colour, layout mode, counter range and
 * chart mix in the piece. No hex literal and no layout coordinate lives
 * anywhere else in the project.
 */

export type VariantName = "blue" | "warm" | "dark";

export type Palette = {
  /** The paper / screen ground. Fills the whole canvas; no page edge is visible. */
  background: string;
  /** Subtle tonal variation painted across the sheet. */
  paperShade: string;
  /** Darkest charts and headings. */
  inkDark: string;
  /** Primary chart colour. */
  inkPrimary: string;
  /** Secondary chart colour. */
  inkSecondary: string;
  /** Third chart colour (used for the third line series / third bar tone). */
  inkTertiary: string;
  /** Neutral bars and comparison elements. */
  inkGrey: string;
  textDark: string;
  textDim: string;
  counterFill: string;
  counterText: string;
};

export type Tilt = {
  /** Degrees. Negative rotates counter-clockwise on screen: the sheet recedes upper-RIGHT. */
  rotateDeg: number;
  /** x' = x + shear * y, applied before the rotation. Mirrored when the tilt reverses. */
  shear: number;
  /** Compression along the receding axis. 0.91 == the right side compresses ~9%. */
  scaleX: number;
  scaleY: number;
};

export type DepthConfig = {
  /**
   * Half-width of the sharp focal band, in sheet units, measured along the
   * recession axis (the sheet's x axis) out from the sheet's middle.
   */
  bandHalfWidth: number;
  /** Gaussian radius in canvas px applied to each of the three buffers. */
  nearBlur: number;
  midBlur: number;
  farBlur: number;
};

export type FinishConfig = {
  /** Alpha of the paper-shade tonal gradient. */
  paperShadeAlpha: number;
  /** Colour and alpha of the brightness lift at the sheet's upper-left. */
  lightLiftColor: string;
  lightLiftAlpha: number;
  vignetteColor: string;
  vignetteAlpha: number;
  grainAlpha: number;
  /** Horizontal scanlines every 5px. Dark variant only. */
  scanlines: boolean;
  scanlineColor: string;
  scanlineAlpha: number;
  /** Soft screen glow at the sheet's centre. Dark variant only. */
  screenGlowColor: string;
  screenGlowAlpha: number;
};

export type ChartStyle = {
  /** Tones cycled inside a single bar chart. Two for v1/v3, three for v2. */
  barTones: string[];
  /** One colour per line-chart series (always three available). */
  seriesTones: string[];
  /** Tones cycled by the pie wedges. */
  wedgeTones: string[];
  /** Alpha of the neutral comparison bar behind each value row. */
  neutralAlpha: number;
  /**
   * How the donut's unfilled remainder reads.
   * "track" paints a visible darker ring; "ghost" paints a very dim ring at
   * `donutTrackAlpha` of the fill colour, for the dark ground where there is
   * no "darker" to go to.
   */
  donutRemainder: "track" | "ghost";
  donutTrackColor: string;
  donutTrackAlpha: number;
  /** Text blocks drop to this opacity so they stay texture, not the brightest thing. */
  textBlockOpacity: number;
  /** Emissive glow radius for bars and lines. 0 everywhere except the dark variant. */
  glowBlur: number;
};

export type Variant = {
  name: VariantName;
  palette: Palette;
  /** Key into LAYOUTS. */
  layoutMode: string;
  /** Multiplies every chart's internal type and stroke sizes. */
  contentScale: number;
  counter: { start: number; end: number };
  /** Human-readable record of what the layout array contains. */
  chartMix: string;
  tilt: Tilt;
  depth: DepthConfig;
  finish: FinishConfig;
  chart: ChartStyle;
  /**
   * Sheet-space drift over the full duration. It runs along the sheet's y axis,
   * which is parallel to the focal band, so the sheet slides across the frame
   * without any panel changing depth bucket.
   */
  drift: { fromU: number; toU: number; fromV: number; toV: number };
};

export const VARIANTS: Record<string, Variant> = {
  blue: {
    name: "blue",
    palette: {
      background: "#E8EEF2",
      paperShade: "#D4DEE6",
      inkDark: "#1B3A6B",
      inkPrimary: "#2E6FD4",
      inkSecondary: "#4FA8E8",
      inkTertiary: "#1B3A6B",
      inkGrey: "#8A96A4",
      textDark: "#2A3542",
      textDim: "#7A8694",
      counterFill: "#1B3A6B",
      counterText: "#FFFFFF",
    },
    layoutMode: "dense",
    contentScale: 1,
    counter: { start: 1965, end: 2028 },
    chartMix:
      "6 donuts (3x2 grid), 2 bar, 3 line, 3 pie, 4 text, 3 value-row groups",
    tilt: { rotateDeg: -14, shear: -0.16, scaleX: 0.91, scaleY: 1 },
    depth: { bandHalfWidth: 800, nearBlur: 12, midBlur: 0, farBlur: 20 },
    finish: {
      paperShadeAlpha: 0.85,
      lightLiftColor: "#FFFFFF",
      lightLiftAlpha: 0.075,
      vignetteColor: "#C9A98A",
      vignetteAlpha: 0.08,
      grainAlpha: 0.03,
      scanlines: false,
      scanlineColor: "#000000",
      scanlineAlpha: 0,
      screenGlowColor: "#FFFFFF",
      screenGlowAlpha: 0,
    },
    chart: {
      barTones: ["#2E6FD4", "#4FA8E8"],
      seriesTones: ["#2E6FD4", "#4FA8E8", "#1B3A6B"],
      wedgeTones: ["#2E6FD4", "#4FA8E8", "#1B3A6B", "#8A96A4", "#2E6FD4"],
      neutralAlpha: 0.34,
      donutRemainder: "track",
      donutTrackColor: "#8A96A4",
      donutTrackAlpha: 0.34,
      textBlockOpacity: 1,
      glowBlur: 0,
    },
    drift: { fromU: 60, toU: -60, fromV: 290, toV: -290 },
  },
};

export const getVariant = (name: string): Variant => {
  const v = VARIANTS[name];
  if (!v) {
    throw new Error(`Unknown variant "${name}"`);
  }
  return v;
};
