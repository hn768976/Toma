# Infographic Sheet — v2 "warm" — editorial, sparse, rearranged

An editorial infographic sheet on a plane receding to the upper-left: nine large panels with wide gutters, a single row of three donuts, one line chart spanning the sheet, and a year counter climbing 1900 to 2000.

## What this is

| | |
| --- | --- |
| Composition id | `InfographicWarm` |
| Resolution | **4K, 3840 x 2160** |
| Duration | 450 frames |
| Frame rate | 30 fps (15.0 seconds) |
| Loops | **No.** Frames 0 and 450 differ by design — values climb once and hold. |

Frames 0-20 sit at zero: empty donuts, flat bars, undrawn lines. Frames 20-420
climb together off one shared timeline, so every chart on the sheet advances as
the year counter does — the sheet is one dataset moving through time, not a
collection of independent animations. Frames 420-450 hold at the final state.

## Install and run

```
npm install
npm run dev          # Remotion Studio
```

## Render at 4K

```
npx remotion render InfographicWarm out/infographic-warm.mp4 --codec=h264 --crf=14 --concurrency=8
```

Lower `--concurrency` if the machine has fewer cores than that; Remotion
refuses a value above the core count. For a fast 1080p check, add
`--scale=0.5`.

## How it is put together

- `src/theme.ts` — the single `VARIANTS` object: palette, layout mode,
  counter range, chart mix, tilt, depth and finish settings. No colour literal
  lives anywhere else.
- `src/layout.ts` — the panel layout as **data**: one entry per panel giving a
  chart type, a position and size in sheet coordinates, and a stable seed. The
  renderer walks the array, so a different arrangement is a different array and
  needs no new drawing code. This project ships the `sparse` layout.
- `src/plane.ts` — the single affine transform for the whole sheet, and the
  depth bucketing.
- `src/components/` — `SheetPlane` plus `DonutChart`, `BarChart`,
  `LineChart`, `PieChart`, `TextBlock`, `ValueRow` and `YearCounter`.

Everything is drawn to one `<canvas>` at a 3840x2160 backing store. Depth of
field uses three offscreen buffers — near, mid and far — each blurred once on
its way to the main canvas, never per panel.

## Determinism

Every value is a pure function of the frame number: motion comes from
`useCurrentFrame()` with `interpolate()` and `spring()`, and all chart data
from Remotion's `random()` with stable string seeds. There is no
`Date.now()`, no `requestAnimationFrame`, no CSS animation and no component
state, so repeated renders are byte-identical.

The typeface (Inter, latin subset) is bundled in `public/fonts/` and loaded
behind `delayRender()`/`continueRender()`, so a render never captures a frame
with a fallback face and never needs the network. Canvas 2D has no
`font-feature-settings`, so tabular figures are produced in code — every digit
is laid out on a fixed advance, which is what stops the climbing percentages
jittering.

## Content

All copy is invented filler. There is no real text, no logos, no watermark and
no audio.
