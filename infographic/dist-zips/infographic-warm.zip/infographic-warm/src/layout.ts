/**
 * The panel layout is DATA. Every entry gives a chart type, a position and
 * size in sheet coordinates, and a stable seed. The renderer walks the array
 * and needs no knowledge of any particular arrangement, so a new layout mode
 * is a new array and nothing else.
 *
 * Sheet coordinates: the origin is the sheet's centre, +x runs along the
 * plane's receding axis, +y runs across it (down on screen). The sheet is much
 * larger than the frame in both directions, so no page edge is ever visible.
 *
 * One consequence of the tilt is worth knowing when editing these numbers: the
 * frame crops the sheet as a PARALLELOGRAM, not a rectangle. As x increases the
 * visible band of y slides by the stagger slope -b/d of the plane matrix
 * (about +0.22 for the -14 degree tilt, -0.17 for the +11 degree one). "dense"
 * answers this by staggering whole columns down that slope, so almost every
 * panel lands inside the crop. "sparse" instead keeps true sheet rows spanning
 * the full width, which is what lets one line chart run right across the sheet;
 * its rows therefore ride up and down with the tilt and crop at the frame edges.
 */

export type PanelKind =
  | "donut"
  | "bar"
  | "line"
  | "pie"
  | "text"
  | "valueRows"
  | "counter";

export type PanelSpec = {
  id: string;
  kind: PanelKind;
  /** Top-left corner in sheet coordinates. */
  x: number;
  y: number;
  w: number;
  h: number;
  /** Stable string seed. Every value on the panel derives from it. */
  seed: string;
};


/**
 * "sparse" — a genuinely different arrangement, not v1 scaled up. 9 panels
 * instead of 21, each far larger, with gutters four to five times v1's so the
 * paper itself becomes an element rather than a background glimpsed between
 * panels. The 3x2 donut grid becomes a single row of three large donuts, and
 * one line chart spans most of the sheet's width as the dominant element.
 *
 * Panels are placed individually against the crop rather than in a column grid:
 * each sits inside the visible band for its own x, and the wide ones are left
 * to run off the frame edges, which is what makes the tilt read.
 */
const sparse: PanelSpec[] = [
  // The counter moves to the sheet's upper-left in this mode.
  { id: "yc", kind: "counter", x: -2150, y: -400, w: 820, h: 200, seed: "year" },
  { id: "s1", kind: "text", x: -2150, y: -140, w: 820, h: 780, seed: "s1-text" },
  { id: "s6", kind: "bar", x: -2150, y: 720, w: 820, h: 560, seed: "s6-bar" },

  // The single row of three large donuts.
  { id: "s2", kind: "donut", x: -1180, y: -620, w: 880, h: 820, seed: "donut-1" },
  { id: "s3", kind: "donut", x: -140, y: -620, w: 880, h: 820, seed: "donut-2" },
  { id: "s4", kind: "donut", x: 900, y: -620, w: 880, h: 820, seed: "donut-3" },

  // The dominant element, spanning most of the sheet's width.
  { id: "s5", kind: "line", x: -1180, y: 260, w: 3200, h: 620, seed: "s5-line" },

  { id: "s7", kind: "pie", x: 900, y: -1500, w: 800, h: 800, seed: "s7-pie" },
  { id: "s9", kind: "text", x: 1800, y: -1450, w: 900, h: 700, seed: "s9-text" },
  { id: "s8", kind: "bar", x: -1180, y: 940, w: 1500, h: 420, seed: "s8-bar" },
];

export const LAYOUTS: Record<string, PanelSpec[]> = {
  sparse,
};

export const getLayout = (mode: string): PanelSpec[] => {
  const l = LAYOUTS[mode];
  if (!l) {
    throw new Error(`Unknown layout mode "${mode}"`);
  }
  return l;
};
