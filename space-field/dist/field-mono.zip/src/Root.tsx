import React from "react";
import { Composition } from "remotion";
import { SpaceField } from "./SpaceField";
import { VARIANTS } from "./variants";

/**
 * FieldMono — 4K (3840x2160), 390 frames at 30fps, seamless.
 */
export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="FieldMono"
      component={SpaceField}
      durationInFrames={VARIANTS.fieldMono.loopLength}
      fps={30}
      width={3840}
      height={2160}
      defaultProps={{ variant: "fieldMono" as const }}
    />
  );
};
