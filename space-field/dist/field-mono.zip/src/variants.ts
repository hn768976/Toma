/**
 * The one place this version is described.
 *
 * It is one configuration of a particle system that runs in two modes:
 * "streak" flies particles radially outward from a core, "point" holds them
 * as stars in a slowly drifting field. This version runs in "point" mode.
 * Everything that shapes it — palette, density, core, dust, timing — is a
 * value below. No hex literal appears anywhere else in the project.
 *
 * Every period below divides the loop length and every Lissajous frequency is
 * an integer, so the composition loops seamlessly.
 */

export type ParticleMode = "streak" | "point";

export type VariantId = "fieldMono";

/** A weighted colour choice, as a hex string. */
export type ColorWeight = { readonly hex: string; readonly weight: number };

/** One slice of the brightness distribution: `share` of particles in `range`. */
export type BrightnessTier = {
  readonly share: number;
  readonly range: readonly [number, number];
};

/** A diagonal band used both to cluster dust and to bias star density. */
export type BandConfig = {
  /** Degrees, measured clockwise from the +x axis in screen space. */
  readonly angleDeg: number;
  /** Perpendicular half-width, as a fraction of the frame diagonal. */
  readonly width: number;
  /** Perpendicular offset of the band centre from the frame centre. */
  readonly offset: number;
};

export type CoreConfig = {
  /** Position as a fraction of the frame. */
  readonly x: number;
  readonly y: number;
  /** Radius of the hot centre, as a fraction of frame height. */
  readonly radius: number;
  /** The intensely bright centre. */
  readonly hot: string;
  /** The ring around the centre — amber on warpBlue, teal on warpAmber. */
  readonly ring: string;
  readonly ringStrength: number;
  /** Outermost halo, a much wider and fainter wash. */
  readonly halo: string;
  readonly haloStrength: number;
  /** Radius/intensity pulse, +/- amount on a sine. */
  readonly pulseAmp: number;
  /** Frames. Must divide the loop length. */
  readonly pulsePeriod: number;
};

export type StreakConfig = {
  /** Starting radius, fraction of the frame diagonal. */
  readonly rStart: number;
  /** Radius at which a particle has certainly left the frame. */
  readonly rEnd: number;
  /** Streak length per unit of speed (speed is measured in px/frame). */
  readonly lengthScale: number;
  /** Hard cap on streak length, fraction of the frame diagonal. */
  readonly maxLength: number;
  /** Whole traversals completed per loop. Integers only. */
  readonly cycles: readonly number[];
  readonly cycleWeights: readonly number[];
};

export type DriftConfig = {
  /** Amplitude of the whole-field drift in px at 4K. */
  readonly fieldAmp: number;
  /** Amplitude of each particle's own tiny closed path, px at 4K. */
  readonly particleAmp: number;
};

export type DustConfig = {
  readonly count: number;
  /** Per-blob alpha range before the global gain. */
  readonly alpha: readonly [number, number];
  /** Blob radius range, fraction of frame width. */
  readonly radius: readonly [number, number];
  /** Radius breathing, +/- fraction. */
  readonly breathAmp: number;
  readonly colors: readonly ColorWeight[];
  /** Global multiplier on blob alpha. */
  readonly gain: number;
  /** Blur radius applied at 1/8 resolution. */
  readonly blur: number;
  /** When set, blobs cluster along this diagonal band. */
  readonly band: BandConfig | null;
  /** Number of density knots used when there is no band. */
  readonly knots: number;
  /** Spread of a knot, fraction of frame width. */
  readonly knotSpread: number;
  /** Share of blobs placed freely rather than on a knot or the band. */
  readonly scatterShare: number;
};

export type BurstConfig = {
  readonly intervalRange: readonly [number, number];
  readonly durationRange: readonly [number, number];
  readonly countRange: readonly [number, number];
  readonly gain: number;
};

export type FlareConfig = {
  /** Number of short bright twinkles per loop. */
  readonly perLoop: number;
  readonly durationRange: readonly [number, number];
  readonly gain: number;
};

export type SpikeConfig = {
  readonly count: number;
  /** Size range of the spiked stars, px at 4K. */
  readonly size: readonly [number, number];
  /** Spike arm length, px at 4K. */
  readonly length: readonly [number, number];
  readonly alpha: number;
};

export type BloomConfig = {
  /** Particles brighter than this contribute to the bloom. */
  readonly threshold: number;
  /** Blur radius in full-resolution px. */
  readonly radius: number;
  readonly strength: number;
};

export type Variant = {
  readonly id: VariantId;
  /** Composition id it is registered under. */
  readonly compositionId: string;
  readonly family: "warp" | "field";
  readonly loopLength: number;
  readonly fps: number;
  readonly mode: ParticleMode;

  readonly backgroundDeep: string;
  readonly backgroundWash: string;
  /** Placement and strength of the background wash gradient. */
  readonly wash: {
    readonly x: number;
    readonly y: number;
    readonly radius: number;
    readonly alpha: number;
  };

  readonly density: number;
  readonly size: readonly [number, number];
  /** Higher biases harder toward the small end. */
  readonly sizeBias: number;
  readonly brightness: readonly BrightnessTier[];
  readonly colors: readonly ColorWeight[];
  readonly twinkle: {
    readonly amp: number;
    /** Frames. Each must divide the loop length. */
    readonly periods: readonly number[];
  };
  /** Biases star placement toward a band, as fieldBlue's galactic plane does. */
  readonly starBand: (BandConfig & { readonly floor: number }) | null;

  readonly core: CoreConfig | null;
  readonly streak: StreakConfig | null;
  readonly drift: DriftConfig | null;
  readonly dust: DustConfig | null;
  readonly bursts: BurstConfig | null;
  readonly flares: FlareConfig | null;
  readonly spikes: SpikeConfig | null;

  readonly bloom: BloomConfig;
  readonly vignette: number;
  readonly grain: number;
};

const FIELD_LOOP = 390; // divisors: 1 2 3 5 6 10 13 15 26 30 39 65 78 130 195 390
const FPS = 30;

const FIELD_MONO = {
  backgroundDeep: "#000000",
  backgroundWash: "#0A0A0C",
  particleWhite: "#FFFFFF",
  particlePale: "#D0D4DA",
  particleMid: "#7A8088",
  particleDim: "#383C42",
} as const;

export const VARIANTS: Record<VariantId, Variant> = {
  fieldMono: {
    id: "fieldMono",
    compositionId: "FieldMono",
    family: "field",
    loopLength: FIELD_LOOP,
    fps: FPS,
    mode: "point",

    backgroundDeep: FIELD_MONO.backgroundDeep,
    backgroundWash: FIELD_MONO.backgroundWash,
    wash: { x: 0.5, y: 0.5, radius: 1, alpha: 0.5 },

    density: 22000,
    size: [2, 6],
    sizeBias: 3.4,
    // A long tail of very dim stars, but on a pure black ground the dim end
    // of the palette and the dim end of this range multiply: pushed much
    // lower than this the 88% stop being faint and simply stop existing.
    brightness: [
      { share: 0.88, range: [0.15, 0.34] },
      { share: 0.09, range: [0.32, 0.6] },
      { share: 0.03, range: [0.6, 1] },
    ],
    colors: [
      { hex: FIELD_MONO.particleDim, weight: 0.55 },
      { hex: FIELD_MONO.particleMid, weight: 0.28 },
      { hex: FIELD_MONO.particlePale, weight: 0.12 },
      { hex: FIELD_MONO.particleWhite, weight: 0.05 },
    ],
    // Twinkle is the only motion left here, so it carries a little more.
    twinkle: { amp: 0.18, periods: [26, 30, 39, 65, 78] },
    starBand: null,

    core: null,
    streak: null,
    drift: { fieldAmp: 4, particleAmp: 0.8 },
    dust: null,
    bursts: null,
    flares: { perLoop: 16, durationRange: [3, 5], gain: 2.6 },
    spikes: {
      count: 25,
      size: [7.5, 11],
      length: [55, 115],
      alpha: 0.5,
    },

    bloom: { threshold: 0.45, radius: 24, strength: 0.8 },
    vignette: 0.22,
    grain: 0.04,
  },
};

export const VARIANT_IDS = Object.keys(VARIANTS) as VariantId[];
