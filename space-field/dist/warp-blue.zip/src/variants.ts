/**
 * The one place this version is described.
 *
 * It is one configuration of a particle system that runs in two modes:
 * "streak" flies particles radially outward from a core, "point" holds them
 * as stars in a slowly drifting field. This version runs in "streak" mode.
 * Everything that shapes it — palette, density, core, dust, timing — is a
 * value below. No hex literal appears anywhere else in the project.
 *
 * Every period below divides the loop length and every Lissajous frequency is
 * an integer, so the composition loops seamlessly.
 */

export type ParticleMode = "streak" | "point";

export type VariantId = "warpBlue";

/** A weighted colour choice, as a hex string. */
export type ColorWeight = { readonly hex: string; readonly weight: number };

/** One slice of the brightness distribution: `share` of particles in `range`. */
export type BrightnessTier = {
  readonly share: number;
  readonly range: readonly [number, number];
};

/** A diagonal band used both to cluster dust and to bias star density. */
export type BandConfig = {
  /** Degrees, measured clockwise from the +x axis in screen space. */
  readonly angleDeg: number;
  /** Perpendicular half-width, as a fraction of the frame diagonal. */
  readonly width: number;
  /** Perpendicular offset of the band centre from the frame centre. */
  readonly offset: number;
};

export type CoreConfig = {
  /** Position as a fraction of the frame. */
  readonly x: number;
  readonly y: number;
  /** Radius of the hot centre, as a fraction of frame height. */
  readonly radius: number;
  /** The intensely bright centre. */
  readonly hot: string;
  /** The ring around the centre — amber on warpBlue, teal on warpAmber. */
  readonly ring: string;
  readonly ringStrength: number;
  /** Outermost halo, a much wider and fainter wash. */
  readonly halo: string;
  readonly haloStrength: number;
  /** Radius/intensity pulse, +/- amount on a sine. */
  readonly pulseAmp: number;
  /** Frames. Must divide the loop length. */
  readonly pulsePeriod: number;
};

export type StreakConfig = {
  /** Starting radius, fraction of the frame diagonal. */
  readonly rStart: number;
  /** Radius at which a particle has certainly left the frame. */
  readonly rEnd: number;
  /** Streak length per unit of speed (speed is measured in px/frame). */
  readonly lengthScale: number;
  /** Hard cap on streak length, fraction of the frame diagonal. */
  readonly maxLength: number;
  /** Whole traversals completed per loop. Integers only. */
  readonly cycles: readonly number[];
  readonly cycleWeights: readonly number[];
};

export type DriftConfig = {
  /** Amplitude of the whole-field drift in px at 4K. */
  readonly fieldAmp: number;
  /** Amplitude of each particle's own tiny closed path, px at 4K. */
  readonly particleAmp: number;
};

export type DustConfig = {
  readonly count: number;
  /** Per-blob alpha range before the global gain. */
  readonly alpha: readonly [number, number];
  /** Blob radius range, fraction of frame width. */
  readonly radius: readonly [number, number];
  /** Radius breathing, +/- fraction. */
  readonly breathAmp: number;
  readonly colors: readonly ColorWeight[];
  /** Global multiplier on blob alpha. */
  readonly gain: number;
  /** Blur radius applied at 1/8 resolution. */
  readonly blur: number;
  /** When set, blobs cluster along this diagonal band. */
  readonly band: BandConfig | null;
  /** Number of density knots used when there is no band. */
  readonly knots: number;
  /** Spread of a knot, fraction of frame width. */
  readonly knotSpread: number;
  /** Share of blobs placed freely rather than on a knot or the band. */
  readonly scatterShare: number;
};

export type BurstConfig = {
  readonly intervalRange: readonly [number, number];
  readonly durationRange: readonly [number, number];
  readonly countRange: readonly [number, number];
  readonly gain: number;
};

export type FlareConfig = {
  /** Number of short bright twinkles per loop. */
  readonly perLoop: number;
  readonly durationRange: readonly [number, number];
  readonly gain: number;
};

export type SpikeConfig = {
  readonly count: number;
  /** Size range of the spiked stars, px at 4K. */
  readonly size: readonly [number, number];
  /** Spike arm length, px at 4K. */
  readonly length: readonly [number, number];
  readonly alpha: number;
};

export type BloomConfig = {
  /** Particles brighter than this contribute to the bloom. */
  readonly threshold: number;
  /** Blur radius in full-resolution px. */
  readonly radius: number;
  readonly strength: number;
};

export type Variant = {
  readonly id: VariantId;
  /** Composition id it is registered under. */
  readonly compositionId: string;
  readonly family: "warp" | "field";
  readonly loopLength: number;
  readonly fps: number;
  readonly mode: ParticleMode;

  readonly backgroundDeep: string;
  readonly backgroundWash: string;
  /** Placement and strength of the background wash gradient. */
  readonly wash: {
    readonly x: number;
    readonly y: number;
    readonly radius: number;
    readonly alpha: number;
  };

  readonly density: number;
  readonly size: readonly [number, number];
  /** Higher biases harder toward the small end. */
  readonly sizeBias: number;
  readonly brightness: readonly BrightnessTier[];
  readonly colors: readonly ColorWeight[];
  readonly twinkle: {
    readonly amp: number;
    /** Frames. Each must divide the loop length. */
    readonly periods: readonly number[];
  };
  /** Biases star placement toward a band, as fieldBlue's galactic plane does. */
  readonly starBand: (BandConfig & { readonly floor: number }) | null;

  readonly core: CoreConfig | null;
  readonly streak: StreakConfig | null;
  readonly drift: DriftConfig | null;
  readonly dust: DustConfig | null;
  readonly bursts: BurstConfig | null;
  readonly flares: FlareConfig | null;
  readonly spikes: SpikeConfig | null;

  readonly bloom: BloomConfig;
  readonly vignette: number;
  readonly grain: number;
};

const WARP_LOOP = 168; // divisors: 1 2 3 4 6 7 8 12 14 21 24 28 42 56 84 168
const FPS = 30;

const BLUE = {
  backgroundDeep: "#01060F",
  backgroundWash: "#06254A",
  particleBlue: "#4FA8E8",
  particleCyan: "#7FD4F5",
  particlePale: "#C8E8FF",
  particleWhite: "#FFFFFF",
  coreWhite: "#FFF8E8",
  coreAmber: "#F5A03F",
  dustBlue: "#1A4A8A",
} as const;

export const VARIANTS: Record<VariantId, Variant> = {
  warpBlue: {
    id: "warpBlue",
    compositionId: "WarpBlue",
    family: "warp",
    loopLength: WARP_LOOP,
    fps: FPS,
    mode: "streak",

    backgroundDeep: BLUE.backgroundDeep,
    backgroundWash: BLUE.backgroundWash,
    wash: { x: 0.4, y: 0.42, radius: 0.85, alpha: 0.3 },

    density: 5000,
    size: [2, 7.5],
    sizeBias: 2.4,
    brightness: [
      { share: 0.62, range: [0.1, 0.32] },
      { share: 0.28, range: [0.32, 0.62] },
      { share: 0.1, range: [0.62, 1] },
    ],
    colors: [
      { hex: BLUE.particleBlue, weight: 0.6 },
      { hex: BLUE.particleCyan, weight: 0.22 },
      { hex: BLUE.particlePale, weight: 0.13 },
      { hex: BLUE.particleWhite, weight: 0.05 },
    ],
    twinkle: { amp: 0.12, periods: [24, 28, 42, 56, 84] },
    starBand: null,

    core: {
      x: 0.4,
      y: 0.42,
      radius: 0.042,
      hot: BLUE.coreWhite,
      ring: BLUE.coreAmber,
      ringStrength: 1,
      halo: BLUE.particleBlue,
      haloStrength: 0.5,
      pulseAmp: 0.14,
      pulsePeriod: 84,
    },
    streak: {
      rStart: 0.013,
      rEnd: 0.95,
      lengthScale: 2.6,
      maxLength: 0.2,
      cycles: [2, 3, 4],
      cycleWeights: [0.35, 0.4, 0.25],
    },
    drift: null,
    dust: {
      count: 30,
      alpha: [0.045, 0.095],
      radius: [0.07, 0.24],
      breathAmp: 0.12,
      colors: [
        { hex: BLUE.dustBlue, weight: 0.62 },
        { hex: BLUE.particleBlue, weight: 0.2 },
        { hex: BLUE.backgroundWash, weight: 0.18 },
      ],
      gain: 1.7,
      blur: 7,
      band: null,
      knots: 6,
      knotSpread: 0.22,
      scatterShare: 0.3,
    },
    bursts: null,
    flares: null,
    spikes: null,

    bloom: { threshold: 0.58, radius: 30, strength: 0.85 },
    vignette: 0.22,
    grain: 0.04,
  },
};

export const VARIANT_IDS = Object.keys(VARIANTS) as VariantId[];
