import React from "react";
import { Composition } from "remotion";
import { SpaceField } from "./SpaceField";
import { VARIANTS } from "./variants";

/**
 * WarpBlue — 4K (3840x2160), 168 frames at 30fps, seamless.
 */
export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="WarpBlue"
      component={SpaceField}
      durationInFrames={VARIANTS.warpBlue.loopLength}
      fps={30}
      width={3840}
      height={2160}
      defaultProps={{ variant: "warpBlue" as const }}
    />
  );
};
