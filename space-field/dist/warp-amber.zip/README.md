# WarpAmber

The blue version inverted: a cool teal ring around a white core, placed on the opposite side of the frame, in a warm field. About 2500 larger, brighter particles on shorter streaks, with heavy dust that carries as much of the frame as the particles do.

## The piece

| | |
| --- | --- |
| Composition id | `WarpAmber` |
| Resolution | 4K — 3840 x 2160 |
| Duration | 168 frames (5.6s) |
| Frame rate | 30 fps |
| Loops | Yes — seamlessly. The last frame hands back to the first with no cut. |

It belongs to the **warp family** of a set of six. The warp family (a core
with particles streaking radially away from it) runs 5.6s; the field family
(stars holding station in a drifting field) runs 13.0s. This one is a
warp version, so it runs 5.6s.

There is no text, no logo, no watermark and no audio.

## Rendering it

```sh
npm install
npx remotion render WarpAmber out/warp-amber.mp4 --codec=h264 --crf=12 --concurrency=8
```

That renders at full 4K. Lower `--concurrency` if the machine has fewer than
eight cores — Remotion refuses a value above the core count. For a quick look,
add `--scale=0.5` for a 1080p version.

To open it in the Remotion studio and scrub through:

```sh
npm run dev
```

## How it is put together

Everything is drawn to 2D canvases — no 3D and no WebGL. Every layer is a pure
function of the frame number: no `Date.now()`, no `requestAnimationFrame`, no
CSS animation and no component state, which is what makes the render
deterministic and the loop exact. All randomness comes from Remotion's
`random()` with fixed string seeds, so the same frame always draws the same way.

| File | What it holds |
| --- | --- |
| `src/variants.ts` | The whole configuration of this version, and the only place a colour is written down. |
| `src/particles.ts` | The particle system: positions, sizes, brightnesses, colours, twinkle periods, dust blobs and timed events. Built once and reused every frame. |
| `src/SpaceField.tsx` | Stacks the layers. |
| `src/components/` | One component per layer: background wash, dust clouds, particles, core flare, and the vignette and grain finish. |

The dust layer is computed at 1/8 resolution and upscaled, since it is all soft
gradient; the particles are always drawn at full resolution.
