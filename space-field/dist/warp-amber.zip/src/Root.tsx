import React from "react";
import { Composition } from "remotion";
import { SpaceField } from "./SpaceField";
import { VARIANTS } from "./variants";

/**
 * WarpAmber — 4K (3840x2160), 168 frames at 30fps, seamless.
 */
export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="WarpAmber"
      component={SpaceField}
      durationInFrames={VARIANTS.warpAmber.loopLength}
      fps={30}
      width={3840}
      height={2160}
      defaultProps={{ variant: "warpAmber" as const }}
    />
  );
};
