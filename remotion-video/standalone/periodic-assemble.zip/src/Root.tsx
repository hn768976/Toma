import { Composition } from "remotion";
import { PeriodicTable } from "./periodic/PeriodicTable";
import {
  DURATION_IN_FRAMES,
  FPS,
  FRAME_HEIGHT,
  FRAME_WIDTH,
} from "./periodic/layout";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="PeriodicAssemble"
      component={PeriodicTable}
      durationInFrames={DURATION_IN_FRAMES}
      fps={FPS}
      width={FRAME_WIDTH}
      height={FRAME_HEIGHT}
      defaultProps={{ variant: "assemble" as const }}
    />
  );
};
