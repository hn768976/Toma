# Periodic Assemble

118 element cells scatter in from off-frame in a seeded random order and settle into the standard periodic table. Every cell is the same blue: the shape of the table is the subject, not its chemistry.

Frames 150-300 hold the assembled table: cells breathe on a seeded sine, a few brighten each second, and the whole table drifts +/-10px. There is no category highlighting.

## The composition

| | |
| --- | --- |
| Composition id | `PeriodicAssemble` |
| Resolution | **3840 x 2160 (4K UHD)** |
| Duration | 300 frames = 10.0 s |
| Frame rate | 30 fps |
| Audio | none |

**This animation does not loop.** Frame 0 is an empty frame and frame 300 is the
finished table - that is by design, so the clip has a beginning and an end and
must not be cut back to its start.

## Render at 4K

```bash
npm install
npx remotion render PeriodicAssemble out/periodic-assemble.mp4 --codec=h264 --crf=12 --concurrency=8
```

Lower `--concurrency` if the machine has fewer cores than the value given;
Remotion refuses a concurrency above the available core count. For a fast 1080p
check, add `--scale=0.5`.

Preview interactively with `npm run dev` (Remotion Studio).

## How it is built

2D only - inline SVG in a `viewBox="0 0 3840 2160"`, no 3D and no Three.js.

Every value is a pure function of `useCurrentFrame()` combined with
`interpolate()` and `spring()`, and all randomness goes through Remotion's
`random()` with stable string seeds. Nothing reads the clock, uses
`requestAnimationFrame`, animates in CSS or keeps React state, so a render is
deterministic and any frame can be produced in isolation.

```
src/
  Root.tsx                    registers the single composition
  periodic/
    elements.ts               all 118 elements: symbol, number, name, group,
                              period, category
    layout.ts                 standard periodic table geometry and frame size
    variants.ts               the only place a colour literal appears: palette,
                              cell colour rule, arrival mode, highlight behaviour
    motion.ts                 seeded arrival schedule, breathing, brighten pass,
                              ambient drift, highlight intensity
    ElementCell.tsx           one cell: halo, fill, border, number, symbol
    TableGrid.tsx             all 118 cells, split into a body and an ink layer
    HighlightPass.tsx         the additive glow pass over emphasised cells
    PeriodicTable.tsx         defs, bloom, vignette, grain
    fonts.ts                  Poppins 400/700, gated with delayRender()
public/
  fonts/                      the two Poppins faces, served locally
```

## Layout

The arrangement is the standard one: hydrogen at group 1 and helium at group 18
with the wide gap between them, groups 1-2 then a gap then groups 13-18 for
periods 2 and 3, all 18 groups filled for periods 4-7, La and Ac in the main
block at period 6/7 group 3, and the lanthanides (Ce-Lu) and actinides (Th-Lr)
in two separate rows below the main block, offset right with a visible gap
above them.

## Fonts

Poppins (SIL Open Font License 1.1) is served from `public/fonts` rather than
fetched from a CDN, so a render never depends on network access.
`delayRender()` holds the renderer until both weights are ready.
