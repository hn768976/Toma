import { existsSync } from "node:fs";
import path from "node:path";
import { Config } from "@remotion/cli/config";

Config.setRspack(true);
Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);

// `@lib` resolves to the vendored copy of the shared component library in
// ./src/lib. NOTE: __dirname inside a Remotion config points at
// @remotion/cli's own directory, so project-relative paths must be anchored
// on process.cwd() instead.
const VENDORED_LIB_SRC = path.resolve(process.cwd(), "src/lib");
const LIB_SRC = path.resolve(process.cwd(), "../remotion-lib/src");

Config.overrideBundlerConfig((config) => ({
  ...config,
  resolve: {
    ...config.resolve,
    alias: {
      ...config.resolve?.alias,
      "@lib": existsSync(VENDORED_LIB_SRC) ? VENDORED_LIB_SRC : LIB_SRC,
    },
  },
}));
