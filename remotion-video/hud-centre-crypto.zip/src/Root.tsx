import { Composition } from "remotion";
import { HudCentre, hudCentreSchema } from "./hud-centre/HudCentre";
import { DURATION, FPS } from "./hud-centre/timing";
import { FRAME_H, FRAME_W } from "./hud-centre/layout";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="HudCentreCrypto"
      component={HudCentre}
      durationInFrames={DURATION}
      fps={FPS}
      width={FRAME_W}
      height={FRAME_H}
      schema={hudCentreSchema}
      defaultProps={{ variant: "crypto" as const }}
    />
  );
};
