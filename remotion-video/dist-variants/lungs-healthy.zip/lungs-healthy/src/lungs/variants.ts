/**
 * The single source of truth for this version's palette, breath rhythm,
 * particle behaviour and tree density. No hex literal lives anywhere else in
 * the piece.
 */

export type LungVariantName = "healthy";

export type Palette = {
  background: string;
  lungFill: string;
  lungShadow: string;
  treeDark: string;
  trachea: string;
  particlePale: string;
  particleBright: string;
};

export type BreathCatch = {
  /** Which breath of the loop stutters (0-indexed). */
  breath: number;
  /** Frame within that cycle where the inhale pauses. */
  at: number;
  /** How many frames it pauses for. */
  frames: number;
};

export type Breath = {
  /** Must divide evenly into the 420-frame loop. */
  cycleFrames: number;
  scaleX: number;
  scaleY: number;
  /** Fraction of the cycle spent inhaling. */
  inhale: number;
  /** Fraction of the cycle held at the top. */
  hold: number;
  catches: BreathCatch[];
};

export type Particles = {
  count: number;
  behaviour: "circulating" | "sluggish";
  /** How strongly particles are pulled toward the branch tips (0..1). */
  tipBias: number;
  /** How strongly particles collapse toward the hilum / trachea (0..1). */
  hilumPull: number;
  /** Radius of the drift path, in 4K units. */
  driftRadius: number;
  /** Extra outward travel carried by the breath, in 4K units. */
  breathTravel: number;
  minSize: number;
  maxSize: number;
  /** Fraction of specks drawn in the brighter colour. */
  brightShare: number;
  baseOpacity: number;
};

export type Tree = {
  depth: number;
  rootLength: number;
  rootWidth: number;
  lengthFactor: number;
  widthFactor: number;
  /** Terminal branches never get thinner than this. */
  minWidth: number;
  /** Dark thickened constriction nodes at branch junctions, per lobe. */
  nodeCount: number;
  nodeMinRadius: number;
  nodeMaxRadius: number;
};

export type LungVariant = {
  name: LungVariantName;
  palette: Palette;
  breath: Breath;
  particles: Particles;
  tree: Tree;
};

/**
 * This project ships a single variant, so its data is inlined here rather than
 * looked up out of a shared record.
 */
export const VARIANT: LungVariant = {
  name: "healthy",
  palette: {
    background: "#000000",
    lungFill: "#B03A3A",
    lungShadow: "#8A2C2C",
    treeDark: "#3D1414",
    trachea: "#6B1F1F",
    particlePale: "#E8C4C4",
    particleBright: "#FFF0F0",
  },
  breath: {
    cycleFrames: 140,
    scaleX: 1.09,
    scaleY: 1.04,
    inhale: 0.4,
    hold: 0.1,
    catches: [],
  },
  particles: {
    count: 120,
    behaviour: "circulating",
    tipBias: 0.68,
    hilumPull: 0,
    driftRadius: 26,
    breathTravel: 34,
    minSize: 5,
    maxSize: 14,
    brightShare: 0.28,
    baseOpacity: 0.78,
  },
  tree: {
    depth: 7,
    rootLength: 192,
    rootWidth: 46,
    lengthFactor: 0.81,
    widthFactor: 0.65,
    minWidth: 4,
    nodeCount: 0,
    nodeMinRadius: 0,
    nodeMaxRadius: 0,
  },
};
