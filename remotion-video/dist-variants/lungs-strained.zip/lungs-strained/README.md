# Breathing Lungs — strained

A flat-vector, 2D breathing-lungs animation built in Remotion. Shallow, rapid, obstructed breathing: seven quick breaths across the loop with a stutter on two of them, barely any expansion, a sparse five-generation tree with thickened terminal airways and constriction nodes, and sluggish specks that never reach the periphery.

## The composition

| | |
| --- | --- |
| Composition id | `LungsStrained` |
| Resolution | **3840 × 2160 (4K)** |
| Duration | 420 frames |
| Frame rate | 30 fps |
| Length | 14.0 seconds |
| Loops | Yes — frame 0 and frame 420 are pixel-identical, so the file can be played back seamlessly on repeat |

Every frame is a pure function of `useCurrentFrame()`, and all randomness runs
through Remotion's seeded `random()`, so renders are deterministic: the same
frame always produces the same pixels.

## Render it at 4K

```bash
npm install
npx remotion render LungsStrained out/lungs-strained.mp4 --codec=h264 --crf=14 --concurrency=8
```

`--concurrency` must not exceed the number of CPU cores on the machine; lower
it if the renderer complains.

## Preview it

```bash
npm run dev
```

## Layout

```
src/
  Root.tsx                  registers the single composition
  index.ts                  entry point
  lungs/
    variants.ts             palette, breath rhythm, particles, tree density
    anatomy.ts              lobe outlines, trachea, geometry helpers
    breath.ts               the breath curve and its transform
    tree.ts                 recursive bronchial tree + particle scattering
    Lungs.tsx               composes the scene
    LungBody.tsx            one lobe: fill plus inner-edge shadow
    BronchialTree.tsx       the airway tree
    ParticleField.tsx       the drifting specks
    Trachea.tsx             the fixed trachea and primary bronchi
```
