import { Composition } from "remotion";
import { FPS, FRAME_HEIGHT, FRAME_WIDTH, LOOP_FRAMES } from "./lungs/anatomy";
import { Lungs } from "./lungs/Lungs";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="LungsStrained"
      component={Lungs}
      durationInFrames={LOOP_FRAMES}
      fps={FPS}
      width={FRAME_WIDTH}
      height={FRAME_HEIGHT}
    />
  );
};
