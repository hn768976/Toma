import { Composition } from "remotion";
import { CryptoHud } from "./crypto-hud/CryptoHud";
import {
  CANVAS_H,
  CANVAS_W,
  DURATION,
  FPS,
} from "./crypto-hud/layout";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="CryptoHudBlue"
      component={CryptoHud}
      durationInFrames={DURATION}
      fps={FPS}
      width={CANVAS_W}
      height={CANVAS_H}
    />
  );
};
