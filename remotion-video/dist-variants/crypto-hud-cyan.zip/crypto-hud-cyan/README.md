# Crypto Symbol HUD — Cyan (Bitcoin)

A glowing Bitcoin mark inside six continuously ticked, counter-rotating
ring bands, over a sparse field of mixed-hue bokeh.

## The composition

| | |
| --- | --- |
| Composition id | `CryptoHudCyan` |
| Resolution | **3840 x 2160 (4K UHD)** |
| Duration | 900 frames |
| Frame rate | 30 fps |
| Length | 30.0 seconds |
| Loop | Seamless — frame 900 is pixel-identical to frame 0 |

Every ring band completes a whole number of turns across the 900 frames, every
bokeh disc travels a closed path, and the glow pulse and scan-band texture both
wrap, so the clip can be looped end to end with no visible seam.

## Render at 4K

```bash
npm install
npx remotion render CryptoHudCyan out/crypto-hud-cyan.mp4 --codec=h264 --crf=12 --concurrency=8
```

Lower `--concurrency` if your machine has fewer cores than the value you pass;
Remotion rejects a concurrency higher than the available CPU count.

For a faster 1080p check, add `--scale=0.5`. Note that the canvas backing store
stays 3840 x 2160 regardless of `--scale`, so a half-scale render costs about
the same per frame as a full one.

## Preview in the studio

```bash
npm run dev
```

## How it is built

Everything is drawn to a single 2D canvas — no 3D, no WebGL, no Three.js.

- `src/crypto-hud/variants.ts` — the one place any colour, ring band or
  behaviour switch is defined. No hex literal lives anywhere else.
- `src/crypto-hud/SymbolGlyph.tsx` — the mark, drawn as a path (not a font
  glyph), carrying a drifting scan-band texture and a chromatic fringe made of
  three offset copies composited with `lighter`.
- `src/crypto-hud/RingBand.tsx` — each band's ticks, dashes and blocks are
  stamped to a sprite once and blitted with a rotation transform, so nothing is
  re-stroked per frame. Bands alternate direction.
- `src/crypto-hud/BokehField.tsx` — soft discs at three depths in mixed hues,
  with a subset drawn in front of the symbol so they partially occlude it.
- `src/crypto-hud/CryptoHud.tsx` — buckets everything into three depth buffers
  and blurs each exactly once. Bloom is baked into the sprites at mount rather
  than blurred per frame.

All motion comes from `useCurrentFrame()` and all randomness from Remotion's
`random()` with stable string seeds, so renders are deterministic and every
frame is a pure function of its frame number.

No audio and no watermark.

The Bitcoin symbol is a community mark in general commercial use, not a
corporate trademark.

`SymbolGlyph` still branches on `symbolType`, and `src/crypto-hud/glyph.ts`
also carries a generic, invented hexagonal token mark that belongs to no
existing project. Switching `symbolType` to `"generic"` in `variants.ts`
swaps this composition over to it.
