import { BREACH } from "./breach";
import type { Variant } from "./types";

export * from "./types";

export type VariantKey = "breach";

/**
 * This project ships one version. Its palette, centre glyph path, glyph
 * integrity mode, panel density, panel behaviour and sweep mode all live in
 * ./breach.ts — nothing else in the project carries a hex value or a
 * glyph shape.
 */
export const VARIANTS: Record<VariantKey, Variant> = {
  breach: BREACH,
};
