import { Composition } from "remotion";
import { ShieldHud } from "./shield-hud/ShieldHud";
import {
  DURATION_IN_FRAMES,
  FPS,
  HEIGHT,
  WIDTH,
} from "./shield-hud/constants";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="ShieldHudBlue"
      component={ShieldHud}
      durationInFrames={DURATION_IN_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={{ variant: "blue" as const }}
    />
  );
};
