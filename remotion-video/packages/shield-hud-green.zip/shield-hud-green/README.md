# Neon shield HUD — v2 "green" — guard shield with an inner keyhole, denser panels

A guard shield in near-black green — flat across a wide top, tapering to a narrow tip — carrying a small keyhole inside it, with amber accents, four busy readout columns, a scrolling log strip and a three-circuit sweep.

| | |
| --- | --- |
| Composition id | `ShieldHudGreen` |
| Resolution | 3840 x 2160 (4K UHD) |
| Duration | 330 frames — 11.0 seconds |
| Frame rate | 30 fps |
| Loop | Seamless: frame 330 is pixel-identical to frame 0 |

## Running it

```bash
npm install
npm run dev        # Remotion Studio
```

## Rendering at 4K

```bash
npx remotion render ShieldHudGreen out/shield-green.mp4 --codec=h264 --crf=12 --concurrency=8
```

The composition is 4K, so this renders 3840x2160 with no scaling. For a
quicker 1080p check, add `--scale=0.5`.

## How it is put together

Everything is drawn to a single 3840x2160 canvas through a ref, once per
React render — no requestAnimationFrame, no component state, no CSS
animation. Every value is a pure function of `useCurrentFrame()`, and all
randomness comes from Remotion's `random()` with stable string seeds, so
renders are deterministic and the loop closes exactly.

- `src/shield-hud/variants/` — the version's palette, glyph path, integrity
  mode, panel density, panel behaviour and sweep mode.
- `src/shield-hud/components/` — `BackgroundLayer`, `ReadoutColumn`,
  `AccentBar`, `BracketMarks`, `LogStrip`, `CentreGlyph`, `SweepHead`.
- `src/shield-hud/ShieldHud.tsx` — clears the depth buffers, then composites
  them with one blur each: three depth buckets, the accent bloom, and the
  glyph's own bloom over the sharp copy.

The readout font is IBM Plex Mono, loaded through `@remotion/google-fonts`
and gated with `delayRender()` / `continueRender()`, so no frame is captured
before the face is available. Rendering therefore needs network access to
Google Fonts on first run.
