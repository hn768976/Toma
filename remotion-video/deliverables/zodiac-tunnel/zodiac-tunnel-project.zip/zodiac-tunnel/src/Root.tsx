import "./index.css";
import "./load-fonts";
import { Composition } from "remotion";
import {
  ZodiacTunnel,
  zodiacTunnelSchema,
  zodiacTunnelDefaults,
} from "./zodiac-tunnel/ZodiacTunnel";
import {
  BASE_WIDTH,
  BASE_HEIGHT,
  DURATION_IN_FRAMES,
  FPS,
} from "./zodiac-tunnel/constants";

// Both versions are authored at 4K. Deliverable previews come out of
// `--scale=0.5` (1920x1080); pass `--scale=1` for the full-resolution
// master. See README.md.
export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="ZodiacTunnelChalk"
        component={ZodiacTunnel}
        durationInFrames={DURATION_IN_FRAMES}
        fps={FPS}
        width={BASE_WIDTH * 2}
        height={BASE_HEIGHT * 2}
        schema={zodiacTunnelSchema}
        defaultProps={{ ...zodiacTunnelDefaults, theme: "chalk" as const }}
      />
      <Composition
        id="ZodiacTunnelGold"
        component={ZodiacTunnel}
        durationInFrames={DURATION_IN_FRAMES}
        fps={FPS}
        width={BASE_WIDTH * 2}
        height={BASE_HEIGHT * 2}
        schema={zodiacTunnelSchema}
        defaultProps={{ ...zodiacTunnelDefaults, theme: "gold" as const }}
      />
      {/*
        One frame longer than the loop, purely so frame 450 can be
        rendered and diffed against frame 0. See "Verifying the loop" in
        README.md.
      */}
      <Composition
        id="ZodiacTunnelLoopTest"
        component={ZodiacTunnel}
        durationInFrames={DURATION_IN_FRAMES + 1}
        fps={FPS}
        width={BASE_WIDTH * 2}
        height={BASE_HEIGHT * 2}
        schema={zodiacTunnelSchema}
        defaultProps={{ ...zodiacTunnelDefaults, theme: "chalk" as const }}
      />
    </>
  );
};
