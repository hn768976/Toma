# HUD Centre — wifi

A 4K "HUD dashboard" motion graphic built in Remotion. 2D canvas only — no 3D,
no Three.js.

| | |
|---|---|
| **Composition id** | `HudCentreWifi` |
| **Resolution** | **4K — 3840 x 2160** |
| **Duration** | 450 frames = **15.0 s** |
| **Frame rate** | 30 fps |
| **Loops** | Yes — seamlessly. Frame 450 is pixel-identical to frame 0, and every periodic motion uses a period that divides 450, so the motion is continuous across the cut. |
| **Centre element** | a wifi symbol: three concentric arcs pulsing outward above a filled dot |
| **ID label** | `BC-344` |

## Render at 4K

```console
npm i
npx remotion render HudCentreWifi out/hud-centre-wifi.mp4 --codec=h264 --crf=12 --concurrency=8
```

`--concurrency` must not exceed your CPU core count; drop it if unsure.

## Preview

```console
npx remotion studio
```

## How it is put together

The surrounding dashboard is a single component, `<Dashboard>`, that takes no
variant at all — it cannot see which version it is in, which is what
guarantees the panels are identical across the wifi, crypto and radar builds.
Only three values differ between versions, and they all live in one
`VARIANTS` object in `src/hud-centre/variants.ts`: the centre element type,
its accent colour, and the ID label.

Everything is drawn to `<canvas>` through a ref, once per React render, driven
entirely by `useCurrentFrame()`. There is no `requestAnimationFrame`, no
component state, no `Date.now()`, and all randomness goes through Remotion's
`random()` with stable string seeds — so a frame is a pure function of its
frame number and `npx remotion render` is deterministic and parallel-safe.

Each panel's static chrome (border, corner ticks, label strip, grids, axis
text) is rasterised once into an offscreen canvas and blitted; only values,
bars, arcs, the sweep and the centre element redraw per frame.

Typefaces (Barlow Condensed and Roboto Mono) are self-hosted from `public/fonts`
and gated behind `delayRender()`/`continueRender()`, so rendering never depends
on a network fetch. All numbers are set in the monospace face — Canvas2D
ignores `font-variant-numeric`, so a monospaced face is the only way to get
genuinely tabular figures.

`src/lib` is a vendored copy of the shared `remotion-lib`
component library, so this project is standalone and runnable with no
dependency on the library checkout.


No real logos, no watermark, no audio.
