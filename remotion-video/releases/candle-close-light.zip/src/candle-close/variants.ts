import type { SeriesParams } from "./series";

// Every colour and every series characteristic in this family lives here,
// keyed by variant name. The component reads nothing but this object, so a
// new look is a new key rather than a new component.

export type Palette = {
  backgroundDeep: string;
  backgroundWash: string;
  gridLine: string;
  candleUp: string;
  candleDown: string;
  labelPale: string;
  labelBright: string;
};

export type LabelConfig = {
  count: number;
  minSize: number; // px at 4K
  maxSize: number;
  minOpacity: number;
  maxOpacity: number;
  // Scales the radii of the closed drift paths. Lower = slower, since the
  // periods themselves are fixed by the loop.
  driftScale: number;
};

export type Treatment = {
  // Fraction of the frame height the tile's full high-to-low range fills.
  // A trending series spends most of its range on the trend, so it needs a
  // taller plot to keep the individual candles large.
  plotFill: number;
  // Additive glow in each candle's own colour. Wrong on a light ground, so
  // the light variant swaps it for a soft drop shadow instead.
  glow: boolean;
  shadow: boolean;
  // Blurred candles are lifted toward the background colour by this much at
  // full blur, so defocus softens toward the ground rather than muddying it.
  dofLift: number;
  // On a light ground the corners lighten instead of darkening.
  vignetteLighten: boolean;
  vignetteStrength: number;
  backgroundWashOpacity: number;
  gridOpacity: number;
};

export type Variant = {
  palette: Palette;
  series: SeriesParams;
  labels: LabelConfig;
  treatment: Treatment;
};

export const VARIANT_NAMES = ["monoLight"] as const;
export type VariantName = (typeof VARIANT_NAMES)[number];

export const VARIANTS: Record<VariantName, Variant> = {
  // Light mode, and an inversion rather than a recolour: no glow, labels go
  // darker than the ground, defocus softens toward white and the vignette
  // lightens the corners. A sharp decline — short steep drops, weak failed
  // rallies, one near-vertical capitulation two-thirds through — which on a
  // pale ground reads as a financial-press graphic.
  monoLight: {
    palette: {
      backgroundDeep: "#F2F4F7",
      backgroundWash: "#E4E9F0",
      gridLine: "#D0D8E2",
      candleUp: "#2E7A4A",
      candleDown: "#C43A4A",
      labelPale: "#B8C2CE",
      labelBright: "#8A98A8",
    },
    series: {
      seed: 33907,
      volatility: 2.3,
      runLength: 3,
      trendBias: -0.35,
      pullbackDamp: 0.6,
      // Rallies are weak: they fail after a candle or two.
      pullbackRunScale: 0.4,
      wickFrequency: 0.3,
      wickScale: 1,
      baseWickScale: 0.3,
      // Two thirds through the tile, a single near-vertical drop.
      shocks: [{ index: 20, magnitude: 4.6 }],
    },
    labels: {
      count: 34,
      minSize: 24,
      maxSize: 90,
      // Dark text on pale reads much stronger than pale on dark, so these
      // sit far lower than the dark variants'.
      minOpacity: 0.05,
      maxOpacity: 0.1,
      driftScale: 1,
    },
    treatment: {
      plotFill: 0.88,
      glow: false,
      shadow: true,
      dofLift: 0.55,
      vignetteLighten: true,
      vignetteStrength: 0.1,
      backgroundWashOpacity: 1,
      gridOpacity: 1,
    },
  },
};
