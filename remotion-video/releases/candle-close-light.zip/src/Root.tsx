import { Composition } from "remotion";
import { CandleClose, candleCloseSchema } from "./candle-close/CandleClose";
import {
  BASE_WIDTH,
  BASE_HEIGHT,
  DURATION_IN_FRAMES,
  FPS,
} from "./candle-close/constants";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="CandleCloseLight"
      component={CandleClose}
      durationInFrames={DURATION_IN_FRAMES}
      fps={FPS}
      width={BASE_WIDTH}
      height={BASE_HEIGHT}
      schema={candleCloseSchema}
      defaultProps={{ variant: "monoLight" as const }}
    />
  );
};
