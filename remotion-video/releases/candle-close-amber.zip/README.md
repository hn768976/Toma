# Candle Close — amberDark

Near-black brown ground, amber and burnt-sienna candles, a steady climb with short shallow pullbacks.

A tight, frontal candlestick close-up: about 30 large candles scrolling right
to left over a textured backdrop of faint grid lines and dim price quotes
drifting behind them. No order-book ladder, no volume bars, no camera tilt —
candles and background only.

## The composition

| | |
| --- | --- |
| Composition id | `CandleCloseAmber` |
| Resolution | 4K — 3840 x 2160 |
| Duration | 390 frames |
| Frame rate | 30 fps |
| Length | 13.0 seconds |
| Loops | Yes — frame 390 is pixel-identical to frame 0, so it tiles seamlessly |

The loop is exact rather than approximate. The price series is periodic over
30 candles and the scroll advances by exactly one period (one frame width)
across the 390 frames, so the chart, the grid, the drifting quotes and the
ambient camera drift all return to their starting state together.

## Render at 4K

```
npm install
npx remotion render CandleCloseAmber out/candle-close-amber.mp4 --codec=h264 --crf=12 --concurrency=8
```

`npm run render` is the same command. For a faster 1080p preview, add
`--scale=0.5`.

## Preview in the studio

```
npm install
npm run dev
```

## Layout of the source

| File | What it holds |
| --- | --- |
| `src/candle-close/variants.ts` | The palette, series character, label config and treatment flags for this variant. Every colour and every number that gives the variant its look lives here. |
| `src/candle-close/series.ts` | The parameterised OHLC generator: trend bias, run length, volatility, wick frequency, pullback depth and shocks. |
| `src/candle-close/labels.ts` | The drifting numeric quotes behind the candles. |
| `src/candle-close/constants.ts` | Timing and geometry, all authored at 4K. |
| `src/candle-close/CandleClose.tsx` | The component: backdrop, labels, glow or shadow, candles, depth of field, vignette. |

Nothing is random at render time — every value comes from a seeded PRNG keyed
on the candle or label index, so frames rendered out of order across workers
always agree.
