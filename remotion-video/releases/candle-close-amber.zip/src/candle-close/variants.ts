import type { SeriesParams } from "./series";

// Every colour and every series characteristic in this family lives here,
// keyed by variant name. The component reads nothing but this object, so a
// new look is a new key rather than a new component.

export type Palette = {
  backgroundDeep: string;
  backgroundWash: string;
  gridLine: string;
  candleUp: string;
  candleDown: string;
  labelPale: string;
  labelBright: string;
};

export type LabelConfig = {
  count: number;
  minSize: number; // px at 4K
  maxSize: number;
  minOpacity: number;
  maxOpacity: number;
  // Scales the radii of the closed drift paths. Lower = slower, since the
  // periods themselves are fixed by the loop.
  driftScale: number;
};

export type Treatment = {
  // Fraction of the frame height the tile's full high-to-low range fills.
  // A trending series spends most of its range on the trend, so it needs a
  // taller plot to keep the individual candles large.
  plotFill: number;
  // Additive glow in each candle's own colour. Wrong on a light ground, so
  // the light variant swaps it for a soft drop shadow instead.
  glow: boolean;
  shadow: boolean;
  // Blurred candles are lifted toward the background colour by this much at
  // full blur, so defocus softens toward the ground rather than muddying it.
  dofLift: number;
  // On a light ground the corners lighten instead of darkening.
  vignetteLighten: boolean;
  vignetteStrength: number;
  backgroundWashOpacity: number;
  gridOpacity: number;
};

export type Variant = {
  palette: Palette;
  series: SeriesParams;
  labels: LabelConfig;
  treatment: Treatment;
};

export const VARIANT_NAMES = ["amberDark"] as const;
export type VariantName = (typeof VARIANT_NAMES)[number];

export const VARIANTS: Record<VariantName, Variant> = {
  // A steady climb: long up-runs, short shallow pullbacks, fewer and shorter
  // wicks. Warm throughout — up/down is carried by brightness (amber vs
  // sienna) more than by hue, a subtler contrast that suits the calmer read.
  amberDark: {
    palette: {
      backgroundDeep: "#140A02",
      backgroundWash: "#3A2008",
      gridLine: "#4A2E10",
      candleUp: "#FFC44F",
      candleDown: "#C4553A",
      labelPale: "#8A6A3F",
      labelBright: "#E8C48F",
    },
    series: {
      seed: 71822,
      volatility: 2.2,
      runLength: 3.6,
      trendBias: 0.35,
      pullbackDamp: 0.6,
      pullbackRunScale: 0.5,
      wickFrequency: 0.16,
      wickScale: 0.55,
      baseWickScale: 0.22,
      shocks: [],
    },
    // Half of neonBlue's count and slower drift: the warm palette carries
    // less contrast, so a busy backdrop muddies it.
    labels: {
      count: 17,
      minSize: 24,
      maxSize: 90,
      minOpacity: 0.08,
      maxOpacity: 0.32,
      driftScale: 0.45,
    },
    treatment: {
      plotFill: 0.9,
      glow: true,
      shadow: false,
      dofLift: 0.2,
      vignetteLighten: false,
      vignetteStrength: 0.5,
      backgroundWashOpacity: 0.8,
      gridOpacity: 0.5,
    },
  },
};
