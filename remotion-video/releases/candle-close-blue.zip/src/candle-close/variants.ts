import type { SeriesParams } from "./series";

// Every colour and every series characteristic in this family lives here,
// keyed by variant name. The component reads nothing but this object, so a
// new look is a new key rather than a new component.

export type Palette = {
  backgroundDeep: string;
  backgroundWash: string;
  gridLine: string;
  candleUp: string;
  candleDown: string;
  labelPale: string;
  labelBright: string;
};

export type LabelConfig = {
  count: number;
  minSize: number; // px at 4K
  maxSize: number;
  minOpacity: number;
  maxOpacity: number;
  // Scales the radii of the closed drift paths. Lower = slower, since the
  // periods themselves are fixed by the loop.
  driftScale: number;
};

export type Treatment = {
  // Fraction of the frame height the tile's full high-to-low range fills.
  // A trending series spends most of its range on the trend, so it needs a
  // taller plot to keep the individual candles large.
  plotFill: number;
  // Additive glow in each candle's own colour. Wrong on a light ground, so
  // the light variant swaps it for a soft drop shadow instead.
  glow: boolean;
  shadow: boolean;
  // Blurred candles are lifted toward the background colour by this much at
  // full blur, so defocus softens toward the ground rather than muddying it.
  dofLift: number;
  // On a light ground the corners lighten instead of darkening.
  vignetteLighten: boolean;
  vignetteStrength: number;
  backgroundWashOpacity: number;
  gridOpacity: number;
};

export type Variant = {
  palette: Palette;
  series: SeriesParams;
  labels: LabelConfig;
  treatment: Treatment;
};

export const VARIANT_NAMES = ["neonBlue"] as const;
export type VariantName = (typeof VARIANT_NAMES)[number];

export const VARIANTS: Record<VariantName, Variant> = {
  // Volatile and range-bound: no overall direction, frequent reversals, long
  // wicks. The eye reads individual candles rather than a trend.
  neonBlue: {
    palette: {
      backgroundDeep: "#0A1230",
      backgroundWash: "#16255E",
      gridLine: "#1E3566",
      candleUp: "#3FE8F5",
      candleDown: "#F5486B",
      labelPale: "#6F8FD4",
      labelBright: "#A8C4F0",
    },
    series: {
      seed: 20514,
      volatility: 3.1,
      runLength: 1.8,
      trendBias: 0,
      pullbackDamp: 1,
      pullbackRunScale: 1,
      // Range-bound: pinned to zero net so it never wanders vertically.
      netTarget: 0,
      wickFrequency: 0.62,
      wickScale: 2.1,
      baseWickScale: 0.42,
      shocks: [],
    },
    labels: {
      count: 34,
      minSize: 24,
      maxSize: 90,
      minOpacity: 0.08,
      maxOpacity: 0.35,
      driftScale: 1,
    },
    treatment: {
      plotFill: 0.72,
      glow: true,
      shadow: false,
      dofLift: 0.18,
      vignetteLighten: false,
      vignetteStrength: 0.55,
      backgroundWashOpacity: 0.85,
      gridOpacity: 0.55,
    },
  },
};
