# Newspaper Clippings — "finance"

A 4K, seamlessly looping wall of torn newspaper clippings, built in Remotion.

## The composition

| | |
|---|---|
| Composition id | `ClippingsFinance` |
| Resolution | **3840 × 2160 (4K UHD)** |
| Duration | 420 frames |
| Frame rate | 30 fps |
| Length | 14.0 seconds |
| Loops | Yes — frame 420 is pixel-identical to frame 0 |

The loop is exact, not crossfaded. The clippings are laid out on a repeating
lattice and the layer translates by exactly one lattice vector over the 420
frames, so the last frame hands over to the first with no seam. The wall behind
them runs on its own half-length lattice, which drifts it at half the speed for
a hint of parallax while still closing on the same frame.

## All text is fictional

**Every headline, every line of body text and every byline in this piece is
invented.** No real newspaper, masthead, publication, journalist or article is
reproduced or referenced. The body copy is generated filler built from neutral
syllables — it has the rhythm and colour of set prose at the size it is seen,
but it says nothing and is not anybody's writing. Bylines are generic desk
names ("Staff Correspondent", "Markets Desk").

## Rendering

Install once:

```bash
npm install
```

Render at full 4K:

```bash
npx remotion render ClippingsFinance out/clippings-finance.mp4 --codec=h264 --crf=12 --concurrency=8
```

A faster 1080p preview:

```bash
npx remotion render ClippingsFinance out/clippings-finance-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

`--concurrency` must not exceed your CPU core count; lower it if Remotion
objects.

Open the studio with `npm run dev`.

## What is in this variant

Market crisis and finance headlines on a dark slate wall (#2A2C30 / #3A3D42 / #1A1C20),
with clippings on cream, cool grey and a salmon-tinted financial stock. The whole wall drifts leftward and slightly up.

Three clippings carry a small printed line chart — a descending trace on a
faint grid, set in the same ink as the text, with no accent colour. Two more
carry a coarse halftone-dot panel standing in for a printed photograph.

Both compositions — `ClippingsFire` and `ClippingsFinance` — are registered
in this project. They share a single `VARIANTS` object that holds every
palette, headline set and drift direction, so both are present here and this
README describes `ClippingsFinance`.

## Fonts

Headlines are set in Playfair Display 900, body text in PT Serif. The font
files are vendored into `public/fonts` and loaded through `FontFace` behind
`delayRender()`/`continueRender()`, so a render never waits on the network and
is reproducible offline. Their identity and source URLs come from
`@remotion/google-fonts`; `node scripts/fetch-fonts.mjs` re-mirrors them if the
upstream version moves.

## Layout of the source

```
src/
  Root.tsx                 composition registration
  clippings/
    variants.ts            THE palette / headline / drift table — the only
                           file in the project containing a hex literal or a
                           headline string
    constants.ts           geometry, lattice vectors, loop length
    layout.ts              where the fourteen clippings sit in one lattice block
    Clipping.ts            bakes one clipping into an offscreen canvas
    WallTexture.ts         the brushed, panelled wall
    Chart.ts               the printed line chart
    text.ts                byline treatment
    fonts.ts               font loading, gated with delayRender()
    Clippings.tsx          the composition: tiling, drift, per-frame blit
  lib/                     vendored from a shared library (remotion-lib);
                           deterministic, palette-agnostic canvas building
                           blocks — torn edges, noise fields, paper texture,
                           justified filler columns, halftone, grain, vignette
```

Each clipping is drawn **once** into its own offscreen canvas — tear path,
paper texture, headline and body text and all — and then blitted with a
transform every frame. Regenerating tear paths and re-laying-out justified text
per frame at 4K would make the render unusable; this one optimisation is what
makes it practical.

All motion is a pure function of `useCurrentFrame()`. There is no
`requestAnimationFrame`, no `Date.now()`, no CSS animation and no component
state driving anything, so frames can be rendered out of order across workers
and still agree. All randomness runs through Remotion's `random()` with stable
string seeds.
