import { Composition } from "remotion";
import { Clippings } from "./clippings/Clippings";
import {
  DURATION_IN_FRAMES,
  FPS,
  HEIGHT,
  WIDTH,
} from "./clippings/constants";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="ClippingsFire"
        component={Clippings}
        durationInFrames={DURATION_IN_FRAMES}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        defaultProps={{ variant: "fire" as const }}
      />
      <Composition
        id="ClippingsFinance"
        component={Clippings}
        durationInFrames={DURATION_IN_FRAMES}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        defaultProps={{ variant: "finance" as const }}
      />
    </>
  );
};
