# Jet HUD — Blue (v1)

`JetHudBlue` is this package's headline composition: the solid,
flat-shaded aircraft on a dense cool-navy interface, travelling lower-left to
upper-right.

## What it is

A generic delta-canard fighter crossing a tilted heads-up display, drawn
entirely as 2D canvas vector work. No 3D, no Three.js, no model files.

**The aircraft is an invented design.** It carries no national insignia, no
roundel, no squadron marking and no tail code, and it is not a depiction of
any particular aircraft — only of the delta-canard silhouette family. Every
label, readout and line of code-like text on the interface is fictional and
generated from invented token pools: no real designations, no real
coordinates, no real code.

## Compositions

| id | Description |
| --- | --- |
| `JetHudBlue` | v1 — cool navy palette, solid flat-shaded aircraft, travelling lower-left to upper-right, dense HUD receding to the upper-right. |
| `JetHudAmber` | v2 — warm amber palette, the same aircraft rendered as a glowing wireframe, travelling upper-right to lower-left, sparse HUD receding to the upper-left. |

Both are **3840x2160 (4K)**, **30 fps**, **390 frames = 13.0 s**, and both
**loop seamlessly** — frame 390 is bit-identical to frame 0.

Two further compositions are development tools, not deliverables:
`JetHudLoopCheck` (JetHudBlue plus one frame, so frame 390 can be rendered and
compared to frame 0) and `JetSpriteQA` (the aircraft sprite alone, unblurred).

## Rendering

Install once, then render at full 4K:

```sh
npm install
npx remotion render JetHudBlue out/jet-hud-blue.mp4 --codec=h264 --crf=12 --concurrency=8
```

`--concurrency` should not exceed your CPU core count; drop it if unsure.
A faster 1080p preview:

```sh
npx remotion render JetHudBlue out/jet-hud-blue-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

Interactive preview: `npm run dev`.

Verify the loop closes:

```sh
npx remotion still JetHudLoopCheck out/f0.png   --frame=0
npx remotion still JetHudLoopCheck out/f390.png --frame=390
md5sum out/f0.png out/f390.png     # identical
```

Add `--props='{"variant":"amber"}'` to check the other variant.

## How it is built

Everything is drawn into one 3840x2160 `<canvas>`. Each layer is a React
component that paints in a layout effect, and React's effect ordering —
children before parents, siblings in order — *is* the compositing order:

```
BackgroundGrid   clears every surface, lays the background and the grid
DataStrip x2     top and bottom readout strips
SidePanel xN     the panel banks
PlaneMarks       centre reticle, crosshairs, brackets, dashed rules
TiltedPlane      composites the three depth-of-field bands
FlightPath       contrail, exhaust bloom, then the aircraft
PostFx           bloom, vignette, scanlines, grain
```

The aircraft is a **later sibling** of `<TiltedPlane>`, not a child: it flies
in front of the plane, frontally and untilted, and is the one layer exempt
from depth of field. That separation is the point of the piece — share the
plane's transform and the aircraft becomes a decal on an interface instead of
an object above one.

### Determinism

Nothing reads a clock, holds state or schedules a frame. Every pixel is a pure
function of `useCurrentFrame()`, and all randomness goes through Remotion's
`random()` with stable string seeds. `npx remotion render` distributes frames
across workers out of order; anything else would flicker.

### Loop closure

Reroll and flash cadences use bucket sizes that divide 390 exactly; periodic
motion is expressed as `sin`/`cos` of the loop phase; the grid, strips and code
column tile at exactly the distance the plane drifts over the loop. The
aircraft's traverse starts and ends fully off-canvas, and its contrail — which
trails behind it and so is still in frame after the airframe has left — fades
out over a window that begins once the body is off-canvas.

The anchored panels are the one thing that cannot drift monotonically and
still land back on frame 0, because they do not tile. They carry a small
closed sway instead.

### Structure

```
src/jet-hud/
  variants.ts      the ONE place any hex, flight direction, tilt or density lives
  jet-geometry.ts  the airframe as flat path data - shared by both renderers
  JetShape.tsx     two renderers over that one geometry: solid and wireframe
  FlightPath.tsx   arc, bank, scale, contrail, exhaust
  hud-layout.ts    panel placement, authored as SCREEN anchors
  ...
src/lib/           vendored from a shared library - see src/lib/README.md
```

`variants.ts` holds both palettes, both jet render modes, the signed flight
direction, both plane tilts and both panel densities. If you want to recolour
or re-time either version, it is the only file you need.

### Typefaces

Barlow Condensed and Roboto Mono are self-hosted in `public/fonts` rather than
fetched from a CDN at render time, and the load is gated behind
`delayRender()`. A render that reaches out to a font CDN can fail, or worse,
silently substitute a fallback face into the first frames and make them differ
from the rest of the loop. See `public/fonts/README.md` for licences.

No audio, no watermark.
