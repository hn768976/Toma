import { Composition } from "remotion";
import { JetHud } from "./jet-hud/JetHud";
import { JetSpriteQA } from "./jet-hud/JetSpriteQA";
import {
  DURATION_IN_FRAMES,
  FPS,
  HEIGHT,
  WIDTH,
} from "./jet-hud/constants";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="JetHudBlue"
        component={JetHud}
        durationInFrames={DURATION_IN_FRAMES}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        defaultProps={{ variant: "blue" as const }}
      />
      <Composition
        id="JetHudAmber"
        component={JetHud}
        durationInFrames={DURATION_IN_FRAMES}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        defaultProps={{ variant: "amber" as const }}
      />

      {/*
        Two development compositions, not deliverables.

        JetHudLoopCheck is JetHudBlue with one extra frame, so that frame 390
        can be rendered and compared against frame 0 to prove the loop closes.
        Pass --props='{"variant":"amber"}' to check the other one.

        JetSpriteQA draws the aircraft sprite alone, unblurred and untilted,
        which is the only sane way to judge the airframe's silhouette and its
        four tonal steps.
      */}
      <Composition
        id="JetHudLoopCheck"
        component={JetHud}
        durationInFrames={DURATION_IN_FRAMES + 1}
        fps={FPS}
        width={WIDTH}
        height={HEIGHT}
        defaultProps={{ variant: "blue" as const }}
      />
      <Composition
        id="JetSpriteQA"
        component={JetSpriteQA}
        durationInFrames={1}
        fps={FPS}
        width={1600}
        height={1600}
        defaultProps={{ variant: "blue" as const }}
      />
    </>
  );
};
