import { FlagDef } from "./shared";

// 1:2, red pales each 1/4 of the fly, white square centre with the
// stylised 11-point maple leaf (1964 design sheet). Grid 4800 x 2400,
// leaf path is drawn on a 2x grid centred on (0,0), so it is placed with
// translate(2400 1200) scale(0.5): ~77% of the white square wide, ~84% tall.
const RED = "#D52B1E";
const LEAF =
  "m-90 2030 45-863a95 95 0 0 0-111-98l-859 151 116-320a65 65 0 0 0-20-73l-941-762 212-99a65 65 0 0 0 34-79l-186-572 542 115a65 65 0 0 0 73-38l105-247 423 454a65 65 0 0 0 111-57l-204-1052 327 189a65 65 0 0 0 91-27l332-652 332 652a65 65 0 0 0 91 27l327-189-204 1052a65 65 0 0 0 111 57l423-454 105 247a65 65 0 0 0 73 38l542-115-186 572a65 65 0 0 0 34 79l212 99-941 762a65 65 0 0 0-20 73l116 320-859-151a95 95 0 0 0-111 98l45 863z";

export const CanadaFlag: FlagDef = {
  width: 4800,
  height: 2400,
  draw: () => (
    <>
      <rect width={4800} height={2400} fill={RED} />
      <rect x={1200} width={2400} height={2400} fill="#FFFFFF" />
      <path transform="translate(2400 1200) scale(0.5)" d={LEAF} fill={RED} />
    </>
  ),
};
