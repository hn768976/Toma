# Access Denied — 4K terminal alert

A 4K "access denied" terminal alert, built in Remotion as a 2D canvas
composition. No 3D, no Three.js, no audio, no real logos or real text — every
line on screen is invented for this piece.

## The composition

| | |
| --- | --- |
| Composition id | `AccessDenied` |
| Resolution | 3840 × 2160 (4K UHD) |
| Duration | 300 frames |
| Frame rate | 30 fps (10.0 s) |
| Loops | **Yes** — frame 0 and frame 300 are pixel-identical, so it can be cut as a seamless loop. |

## Render

Install once, then render at full 4K:

```bash
npm install
npx remotion render AccessDenied out/access-denied.mp4 --codec=h264 --crf=12 --concurrency=8
```

A faster 1080p preview (same framing, half the pixels):

```bash
npx remotion render AccessDenied out/access-denied-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

`--concurrency` must not exceed the number of CPU cores available.

Open the studio to scrub frame by frame:

```bash
npm run dev
```

## How it is put together

Five layers composite into a single 3840 × 2160 canvas, in this order:

1. **`TextLayer`** — a dense monospace page (three columns, sixty rows) laid
   out once into an offscreen buffer and blitted with a translation each frame.
   The block is exactly one frame tall and scrolls by `(frame / 300) × blockHeight`,
   so it tiles against itself. Runs of lines are periodically replaced by garbled
   character runs.
2. **`ColourWash`** — the frame is recoloured to the dominant hue with its
   luminance preserved, then flooded, so the page survives only as darker and
   lighter striations. Carries CRT banding, an upper-third lift and vertical streaks.
3. **`Banner`** — a hard-edged black bar with heavy italic caps, wide tracking,
   a persistent chromatic fringe and a slight bloom.
4. **`TearPass`** — horizontal slices of the composited frame displaced
   sideways, some with their colour channels pulled apart, some dropped to a flat
   block, some replaced by a duplicate of the text layer from a different offset.
5. **`ScanlinePass`** — scanlines, vignette and grain.

Everything the layers do is driven by a **single instability curve** in
`src/variants.ts`: a function of frame returning 0–1 that scales tear frequency,
slice displacement, chromatic offset, wash opacity and banner jitter together.
Here it holds high (0.65–1.0) on an irregular oscillation whose period divides
evenly into 300 — the system is already failing when the clip opens and still
failing when it ends.

## Determinism

Every frame is a pure function of `useCurrentFrame()`. There is no
`Date.now()`, no `requestAnimationFrame`, no CSS animation and no state that
survives a frame; all randomness comes from Remotion's seeded `random()`.
Frames can be rendered in any order, on any machine, and come out identical.

Fonts are vendored into `public/fonts/` and loaded through
`@remotion/google-fonts`, gated with `delayRender()`/`continueRender()`, so a
render never touches the network.
