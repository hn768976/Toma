
/**
 * The one and only place in this project where a colour value, a banner string
 * or a glitch schedule is written down. Every layer reads what it needs from
 * here, so the two versions differ by data alone and not by branching code.
 */

export type Palette = {
  washMain: string;
  washDeep: string;
  textBg: string;
  textDark: string;
  textLight: string;
  bannerBlack: string;
  bannerWhite: string;
  fringeA: string;
  fringeB: string;
};

export type TextLayerMode = 'corrupt' | 'restoring';

export type GlitchProfile = {
  /** Frames to wait before the next tear cluster, before jitter, at a given instability. */
  tearInterval: (instability: number) => number;
  /** Slices displaced at once, low and high ends of the instability range. */
  sliceCount: [number, number];
  /** Slice band height in px. */
  sliceHeight: [number, number];
  /** Sideways displacement in px at full instability. */
  sliceShift: [number, number];
  /** Chromatic separation in px at full instability. */
  chromatic: number;
  /** Flat wash opacity at zero and full instability. */
  washAlpha: [number, number];
  /** Striation texture strength at zero and full instability. */
  striation: [number, number];
  /** How far the flood is pulled back toward the deep tone, 0..1. */
  deepen: number;
  /** Banner shift in px at full instability. */
  bannerJitter: number;
};

export type TextLayerBehaviour = {
  mode: TextLayerMode;
  /** Rough spacing between corruption events, in frames. */
  eventSpacing: number;
  /** Corrupted run length in lines. */
  lines: [number, number];
  /** How long a corrupted run persists, in frames. */
  duration: [number, number];
  /** In 'restoring' mode, the frame by which no corruption remains. */
  clearedBy: number;
};

export type VariantConfig = {
  name: string;
  palette: Palette;
  banner: string;
  glitch: GlitchProfile;
  text: TextLayerBehaviour;
  /** Single curve, 0..1, driving tears, displacement, fringe, wash and jitter together. */
  instability: (frame: number) => number;
  /** Whole-frame brightness lift, 0..1. Used for the closing confirmation beat. */
  pulse: (frame: number) => number;
  /** Whether frame 0 and frame 300 are pixel-identical. */
  loops: boolean;
};

export type VariantName = 'granted';

const ramp = (x: number, a: number, b: number, from: number, to: number): number => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  const eased = t * t * (3 - 2 * t);
  return from + (to - from) * eased;
};

// Opens exactly as unstable as the denied cut, then resolves. Not a loop.
const resolvingCurve = (frame: number): number => {
  if (frame < 45) return 1;
  if (frame < 150) return ramp(frame, 45, 150, 1, 0.45);
  if (frame < 240) return ramp(frame, 150, 240, 0.45, 0.08);
  if (frame < 252) return ramp(frame, 240, 252, 0.08, 0);
  return 0;
};

// A single soft lift across the whole frame over the closing 25 frames.
const confirmPulse = (frame: number): number => {
  if (frame < 275) return 0;
  return Math.sin(((frame - 275) / 25) * Math.PI);
};

const granted: VariantConfig = {
  name: 'granted',
  palette: {
    washMain: '#18C43A',
    washDeep: '#0A7A22',
    textBg: '#0A7A22',
    textDark: '#064A16',
    textLight: '#80FFA0',
    bannerBlack: '#000000',
    bannerWhite: '#FFFFFF',
    fringeA: '#E040A0',
    fringeB: '#E0A020',
  },
  banner: 'ACCESS GRANTED',
  glitch: {
    // Long gaps once the frame settles: isolated tears rather than clusters.
    tearInterval: (i) => 8 + (1 - i) * 70,
    sliceCount: [4, 14],
    sliceHeight: [8, 90],
    sliceShift: [20, 260],
    chromatic: 13,
    // The green sits darker and less saturated than the red — a green at the
    // red's intensity reads as toxic rather than as approval.
    washAlpha: [0.4, 0.55],
    striation: [0.14, 0.36],
    // Green carries far more luminance than red at the same saturation, so the
    // flood is pulled back toward the deep tone. Without this the approval
    // colour reads as acid rather than as approval.
    deepen: 0.32,
    bannerJitter: 6,
  },
  text: {
    mode: 'restoring',
    eventSpacing: 40,
    lines: [8, 15],
    duration: [20, 30],
    clearedBy: 200,
  },
  instability: resolvingCurve,
  pulse: confirmPulse,
  loops: false,
};

// This project ships one version. The variant data is inlined here rather
// than selected out of a shared two-key object.
export const VARIANT: VariantConfig = granted;

export const getVariant = (_name: VariantName): VariantConfig => VARIANT;
