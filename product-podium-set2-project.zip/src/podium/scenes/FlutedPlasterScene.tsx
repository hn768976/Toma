/**
 * Look 3 — Fluted Plaster.
 *
 * A soft warm-white studio: wall and floor in the same pale plaster, the
 * seam barely there, an out-of-focus foliage shadow across both, and very
 * low contrast throughout.
 *
 * Two geometry variants share every one of those decisions — the single
 * fluted cylinder and the classical column pair differ only in the plinth
 * they put in the light. That is the cheapest second thumbnail in the set.
 */
import { useMemo } from "react";
import { studioEnvironment } from "../environment";
import { plasterNormal } from "../textures";
import { Canopy } from "../Canopy";
import { ContactAO } from "../ContactAO";
import { Column, Disc, FlutedCylinder } from "../plinths/Plinths";
import { WallFloor } from "./Stage";
import type { FlutedPlasterParams } from "../types";

export const FlutedPlasterScene: React.FC<{ params: FlutedPlasterParams }> = ({
  params: p,
}) => {
  const env = useMemo(
    () =>
      studioEnvironment({
        intensity: 0.56,
        top: [0.94, 0.94, 0.94],
        horizon: [0.65, 0.65, 0.65],
        bottom: [0.36, 0.36, 0.36],
      }),
    [],
  );

  const normalMap = useMemo(() => plasterNormal(11, 1.1), []);

  // Matte white plaster with a faint tooth — not a clean shiny white.
  const plaster = (
    <meshStandardMaterial
      color={p.plaster}
      roughness={0.92}
      metalness={0}
      normalMap={normalMap}
      normalScale={[0.42, 0.42] as unknown as never}
      envMapIntensity={0.85}
    />
  );

  return (
    <>
      <primitive object={env} attach="environment" />
      {/* Low contrast: a broad soft fill under the keyed canopy light. */}
      {/* Low contrast overall, but the key still has to carry the flutes:
          a plinth lit only by fill reads as a plain cylinder. */}
      <hemisphereLight args={["#ffffff", "#ded9d3", 0.56]} />
      <ambientLight intensity={0.06} color="#fdfcfb" />

      <WallFloor
        wall={p.wall}
        floor={p.floor}
        wallDistance={p.wallDistance}
        roughness={0.94}
        normalStrength={0.26}
        seed={11}
      />

      {/* A soft raking key from the front left. The canopy light is aimed
          at the wall to place the gobo, which leaves it grazing the plinth;
          without this the flutes get no directional shading at all and the
          plinth reads as a plain cylinder. */}
      <spotLight
        position={[-5.5, 4.2, 6.5]}
        angle={0.6}
        penumbra={1}
        decay={2}
        intensity={280}
        color="#fdfdfc"
      />

      <Canopy config={p.foliage} />

      {p.plinth === "cylinder" ? (
        <>
          <ContactAO radius={1.36} spread={1.55} strength={0.6} />
          {/* A plain base plate under the shaft. The reference crops its
              base away; with the whole plinth in frame the bare fluted
              silhouette flares like draped fabric, and a classical plinth
              has a plate there anyway. */}
          <Disc radius={1.36} height={0.07} bevel={0.008} material={plaster} />
          <FlutedCylinder
            position={[0, 0.07, 0]}
            radius={1.3}
            height={1.3}
            flutes={14}
            fluteDepth={0.11}
            fluteSharpness={2.4}
            capRadius={1.34}
            capHeight={0.055}
            material={plaster}
          />
        </>
      ) : (
        <>
          {/* Shorter, front-left. */}
          <ContactAO radius={0.44} spread={2.6} strength={0.5} position={[-1.0, 0, 0.75]} />
          <ContactAO radius={0.44} spread={2.6} strength={0.5} position={[1.15, 0, -0.55]} />
          <Column
            height={1.4}
            shaftRadius={0.33}
            plateRadius={0.44}
            baseHeight={0.1}
            capitalHeight={0.11}
            flutes={20}
            fluteDepth={0.03}
            taper={0.94}
            position={[-1.0, 0, 0.75]}
            material={plaster}
          />
          {/* Taller, set back to the right. */}
          <Column
            height={1.43}
            shaftRadius={0.33}
            plateRadius={0.44}
            baseHeight={0.1}
            capitalHeight={0.11}
            flutes={20}
            fluteDepth={0.03}
            taper={0.94}
            position={[1.15, 0, -0.55]}
            material={plaster}
          />
        </>
      )}
    </>
  );
};
