# Crypto Code Flythrough — Teal

A 4K "crypto code flythrough": fictional JavaScript fragments streaming past a
moving camera under heavy motion blur, built in Remotion with
`@remotion/three`.

Horizontal lateral stream, right to left, with tumbling coins and a camera travelling forward through the field.

## The composition

| | |
|---|---|
| composition id | `CryptoFlyTeal` |
| resolution | **3840 x 2160 (4K UHD)** |
| duration | 270 frames |
| frame rate | 30 fps (9.0 seconds) |
| loops | yes — frame 270 is pixel-identical to frame 0 |
| audio | none |

The loop is seamless: every animated value is a pure function of
`(frame % 270) / 270`, and every element completes a whole number of screen
traversals over the 270 frames. It can be cut back to back indefinitely.

## Install and run

    npm install
    npm run dev          # opens Remotion Studio

## Render

4K, the delivery render:

    npx remotion render CryptoFlyTeal out/crypto-fly-teal.mp4 --codec=h264 --crf=12 --concurrency=4

A faster 1080p preview:

    npx remotion render CryptoFlyTeal out/crypto-fly-teal-preview.mp4 --codec=h264 --crf=18 --scale=0.5 --concurrency=4

Keep the concurrency low. This is a WebGL scene with a post-processing chain,
and each worker holds its own GPU context and its own copy of the shared
textures — 3D uses far more memory per worker than a 2D composition does.

## Extra dependencies

On top of a stock Remotion project this uses:

| package | why |
|---|---|
| `@remotion/three` | `<ThreeCanvas>`, which disables react-three-fiber's internal render loop so frames advance on Remotion's clock instead of wall time |
| `three` | the renderer |
| `@react-three/fiber` | React reconciler for three.js |
| `@react-three/drei` | `<PerspectiveCamera>` |
| `@react-three/postprocessing` + `postprocessing` | depth of field, bloom and vignette |

## Layout

    src/variants.ts        palette, stream axis, flow direction, coin count,
                           plane density and camera mode — the single source
                           of truth, and the only place a colour is written
    src/field.ts           depth bands, traversal maths, element placement
    src/code-fragments.ts  the fictional crypto JavaScript
    src/textures.ts        shared canvas textures (sharp and pre-smeared)
    src/scene/             camera rig, code field, coins, accents, effects
    src/CodeFlythrough.tsx the composition
    CAMERA-NOTES.md        camera setup, motion blur approach, DoF and bloom
                           settings, and the problems hit on the way

All code shown in the animation is invented for this piece. It is not taken
from any real library, SDK or exchange API, and there are no real logos.
