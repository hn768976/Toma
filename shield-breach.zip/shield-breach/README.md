# Shield Status HUD — BREACH

A 4K "shield status HUD" built entirely on a 2D `<canvas>` with Remotion.
No 3D, no Three.js, no WebGL — one affine-transformed plane, three offscreen
depth buffers, and a heavy condensed sans over a field of fictional code.

## The composition

| | |
| --- | --- |
| Composition id | `ShieldBreach` |
| Resolution | **3840 x 2160 (4K UHD)** |
| Duration | 900 frames |
| Frame rate | 30 fps (30.0 seconds) |
| Loops? | **No** — this version is a one-shot. Data cards go dark permanently and code panels corrupt as the piece progresses, so frame 900 differs from frame 0 by design. Do not loop it. |

## Render

Install once:

```sh
npm install
```

Full 4K render:

```sh
npx remotion render ShieldBreach out/shield-breach.mp4 --codec=h264 --crf=12 --concurrency=8
```

A quick 1080p preview (same composition, captured at half scale):

```sh
npx remotion render ShieldBreach out/shield-breach-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

Interactive preview:

```sh
npm run dev
```

## How it is put together

* **One tilted plane.** A single `ctx.setTransform()` rotates by -16 degrees and
  shears so the right side compresses about 8%. Parallel lines stay parallel —
  it is deliberately not a perspective projection. The plane's local y axis is
  the depth proxy: lower-left is near, upper-right is far.
* **Depth of field.** Elements are bucketed into three offscreen buffers — near,
  mid and far — and each buffer is blurred exactly once with
  `ctx.filter = 'blur(Npx)'` on the way in. Per-element blurring would be
  unusably slow at 4K. Near and far render at half resolution; the focal band
  around the shield renders full size and sharp.
* **Deterministic by construction.** Every value is a pure function of
  `useCurrentFrame()`. No `Date.now()`, no `requestAnimationFrame`, no CSS
  animation, no component state. All randomness goes through Remotion's
  `random()` with stable string seeds.
* **Prerendered texture.** Each code panel and data card is laid out once into a
  small offscreen canvas and then blitted with transforms. Only the rerolling
  values are drawn per frame.
* **Fictional content.** All the code in the panels is invented — made-up
  function names, variables and comments. Nothing is reproduced from any real
  library and there are no copyright headers, logos or watermarks. No audio.

## Fonts

IBM Plex Mono and Barlow Condensed, both under the SIL Open Font License, are
self-hosted from `public/fonts` rather than fetched at render time. Loading is
gated with `delayRender()`/`continueRender()`, so no frame is ever captured
against a fallback face and the project renders with no network access.

## Layout

```
src/
  index.ts                 registerRoot
  Root.tsx                 registers ShieldBreach only
  shield/
    ShieldStatus.tsx       VARIANTS, the five components, the frame pipeline
    plane.ts               the plane transform, depth buckets, buffers
    shieldPath.ts          the shield outline, sampled with arc lengths
    layout.ts              the seeded surround: panels, cards, rows, points
    fonts.ts               font loading, gated with delayRender
public/fonts/              the two self-hosted woff2 faces
```
