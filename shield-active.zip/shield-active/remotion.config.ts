/**
 * Note: when using the Node.JS APIs, this config file does not apply.
 * Pass the options directly to the APIs instead.
 *
 * All configuration options: https://remotion.dev/docs/config
 */

import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
// The piece has no audio; this keeps a silent track out of the output.
Config.setMuted(true);
