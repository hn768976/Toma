import { Composition } from "remotion";
import { ShieldStatus } from "./shield/ShieldStatus";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="ShieldActive"
      component={ShieldStatus}
      durationInFrames={900}
      fps={30}
      width={3840}
      height={2160}
      defaultProps={{ variant: "active" as const }}
    />
  );
};
