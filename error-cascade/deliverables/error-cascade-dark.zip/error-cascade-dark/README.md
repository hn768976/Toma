# Error Dialog Cascade — v2 "dark"

Dark dialogs with a red-orange title bar and an amber error icon, on a near-black field. Arrives in waves rather than as a ramp: each burst lands as its own cluster, and the silences between them are the point.

## The composition

| | |
| --- | --- |
| Composition id | `ErrorCascadeDark` |
| Resolution | 3840 x 2160 (4K UHD) |
| Duration | 600 frames @ 30 fps = 20.0 s |
| Loops? | **No.** Frame 0 and frame 599 differ entirely by design — dialogs accumulate and nothing ever closes or fades. |
| Audio | None. |

## Render

Install once, then render:

```bash
npm install
npx remotion render ErrorCascadeDark out/error-cascade-dark.mp4 --codec=h264 --crf=14 --concurrency=8
```

That is the full 4K render. `--concurrency` must not exceed the machine's CPU
core count; lower it if Remotion refuses to start.

A quick 1080p check, which renders in a fraction of the time:

```bash
npx remotion render ErrorCascadeDark out/dark-preview.mp4 --codec=h264 --crf=18 --scale=0.5
```

Or open the editor:

```bash
npm run dev
```

## The spawn curve

- `0-45`     empty
- `45-75`    burst — 40 dialogs, then silence
- `75-140`   nothing; the pile just sits there
- `140-175`  burst — 70 dialogs
- `175-230`  nothing
- `230-265`  burst — 130 dialogs
- `265-300`  nothing
- `300-420`  bursts every ~20 frames, each larger, the gaps shortening
- `420-560`  continuous flood, no gaps
- `560-600`  hold — the frame is covered

The curve is data, not code: `src/config.ts` describes it as a list of
segments and `src/spawn-curve.ts` resolves it into `spawnsAtFrame(frame)`.
Reshaping the piece means editing the segment list and nothing else.

## Layout

```
src/
  index.ts          registerRoot
  Root.tsx          the composition registration
  ErrorCascade.tsx  the composition component
  config.ts         VARIANTS — palette, dialog style, spawn curve, messages.
                    The only file in the project containing a colour literal.
  spawn-curve.ts    segments -> per-frame spawn counts -> the dialog schedule
  dialogs.ts        seeded placement and rotation for every dialog
  fonts.ts          the UI sans, gated with delayRender()/continueRender()
  grain.ts          the ~2% grain overlay
  components/
    SpawnLayer.tsx  the canvas, and the per-frame blit loop
    Dialog.tsx      the dialog sprite, drawn once into an offscreen canvas
    TitleBar.tsx    title bar, label and close glyph
    ErrorIcon.tsx   the round error icon
public/fonts/       the UI sans, vendored so a render never needs the network
```

## Notes

- **Deterministic.** Every value on screen is a pure function of
  `useCurrentFrame()`. All randomness goes through Remotion's `random()` with
  stable string seeds — no `Math.random()`, no `Date.now()`, no
  `requestAnimationFrame`, no CSS animation, no component state. Seeking
  straight to frame 437 produces the same image as playing up to it, byte for
  byte, so `npx remotion render` is reproducible.
- **One sprite, many blits.** The dialog is drawn once into a small offscreen
  canvas and `drawImage`d per instance under a translate/rotate/scale.
  Redrawing the border, title bar, icon and text for hundreds of dialogs per
  frame at 4K would not render in reasonable time.
- **Generic dialog.** Square corners, a thin flat border, a flat solid title
  bar, a bare close glyph and an invented error icon. It is deliberately not a
  reproduction of any real operating system's window chrome.
- **The font is vendored.** `public/fonts/` holds the UI sans and
  `src/fonts.ts` registers it through the FontFace API behind
  `delayRender()`. Fetching it from a font CDN at render time would make the
  render fail behind a proxy or on a machine with no egress.
